import ass_vendor_setup  # noqa — _vendor/ dizinini path'e ekler
import os
import re
import traceback
import requests
import json
from colorama import Fore, Style
from tqdm import tqdm
import difflib


class SubtitleTranslationError(RuntimeError):
    """
    Subtitle çevirisi zorunlu iken başarısız olduğunda fırlatılır.

    HStream İndirici fail-safe mekanizması:
    Herhangi bir altyazı dosyası çevrilemediyse tüm batch durdurulur.
    Bu exception otomatik indirici.py'nin ana döngüsü tarafından
    yakalanmalı ve işlemi anlık olarak sonlandırmalıdır.
    """
    pass


# ── rapidfuzz: Hızlı ve doğru string similarity (difflib'den 10-100x hızlı) ─
try:
    from rapidfuzz import fuzz as _rfuzz, distance as _rdistance, process as _rfuzz_process
    _RAPIDFUZZ_OK = True
except ImportError:
    _rfuzz_process = None
    _RAPIDFUZZ_OK = False
import time

# [ASS Line Filter] ass_tag_parser tabanli guclu satir filtresi
# Kaynak: github.com/bubblesub/ass_tag_parser (MIT Lisansi)
try:
    from ass_line_filter import (
        is_drawing_line           as _alf_is_draw,
        is_karaoke_line           as _alf_is_kara,
        style_should_skip         as _alf_style_skip,
        timestamp_fix_safe_rescue as _alf_ts_safe,
    )
    _ALF_OK = True
except ImportError:
    _ALF_OK = False
    import re as _re_alf
    _alf_is_draw  = lambda t: bool(_re_alf.search(r'\\p[1-9]', t))
    _alf_is_kara  = lambda t: bool(_re_alf.search(r'\\[kK][fot]?\d', t))
    _alf_style_skip = lambda s: bool(_re_alf.search(
        r'(?i)\b(?:rom(?:aji)?|jpn?|kara(?:oke)?|ruby|furigana|ins\s*-\s*jp)\b', s))
    _alf_ts_safe  = lambda ev: (
        not _alf_is_draw(ev.get('text', ''))
        and not _alf_is_kara(ev.get('text', ''))
        and not _alf_style_skip(ev.get('style', ''))
    )


# ASS Tag Extraction Motoru — libass + Aegisub kaynaklı tam spec implementasyonu
try:
    from ass_tag_extractor import (
        extract_ass_tags as _ass_extract,
        restore_ass_tags as _ass_restore,
        strip_all_ass_tags,
        classify_block as _classify_ass_block,
        is_drawing_line,
        ASS_VALID_TAGS,
        split_into_segments as _seg_split,
        rejoin_from_segments as _seg_rejoin,
        merge_text_segments_for_batch as _seg_merge,
        split_translated_batch as _seg_split_result,
    )
    _ASS_EXTRACTOR_AVAILABLE = True
except ImportError:
    _ASS_EXTRACTOR_AVAILABLE = False
    strip_all_ass_tags = None

# [YENİ] ASS Kalite Dogrulama Motoru — CPS/CPL/effect/actor
try:
    from subtitle_validator import (
        validate_event   as _validate_event,
        validate_all     as _validate_all,
        validate_event_with_translation as _validate_event_with_tr,
        validate_color_preservation as _validate_color_preservation,
        summarize_validation as _summarize_validation,
        has_scroll_effect as _has_scroll_effect,
        _ass_time_to_ms,
    )
    _VALIDATOR_AVAILABLE = True
except ImportError:
    _VALIDATOR_AVAILABLE = False
    def _has_scroll_effect(e): return False
    def _validate_all(evs, **kw): return []
    def _validate_event_with_tr(ev, tr_text, **kw): return None
    def _validate_color_preservation(orig, tr): return {'ok': True, 'missing': [], 'extra': []}
    def _summarize_validation(r): return {}
    def _ass_time_to_ms(t): return 0

# [YENİ] ASS Tag Kütüphanesi — ass_tag_parser v2.4.1 tabanlı tam spec implementasyonu
# Kaynak: bubblesub/ass_tag_parser + Aegisub tag referansı
try:
    from ass_tag_library import (
        analyze          as _atl_analyze,
        strip_tags       as _atl_strip,
        is_draw_event    as _atl_is_draw,
        is_karaoke_event as _atl_is_kara,
        is_animated_event as _atl_is_anim,
        has_translatable_text as _atl_has_text,
        should_skip_translation as _atl_should_skip,
        extract_text_atp as _atl_extract,
        strip_animation_tags as _atl_strip_anim,
        is_fullline_karaoke as _atl_is_fullline,
        is_letter_by_letter_karaoke as _atl_is_letter,
        get_tag_summary  as _atl_tag_summary,
        library_info     as _atl_library_info,
    )
    _ATL_AVAILABLE = True
except ImportError:
    _ATL_AVAILABLE = False

# [YENİ] ASS Tag Referans Modülü — libass/ass_parse.c + Aegisub kaynaklı
# Tam override tag listesi, çizim modu, vektör clip, karaoke, effect alanı
try:
    from ass_tag_reference import (
        is_drawing_line           as _atr_is_draw,
        is_vector_clip_junk       as _atr_is_clip_junk,
        should_skip_by_effect     as _atr_skip_effect,
        classify_line_translatability as _atr_classify,
        protect_special_chars     as _atr_protect,
        restore_special_chars     as _atr_restore,
    )
    _ATR_AVAILABLE = True
except ImportError:
    _ATR_AVAILABLE = False
    def _atr_is_draw(t):         return bool(re.search(r'\\p[1-9]\b', t))
    def _atr_is_clip_junk(t):    return (False, '')
    def _atr_skip_effect(e):     return (False, '')
    def _atr_classify(t, s=''):  return ('translate', 'fallback')
    def _atr_protect(t):         return t
    def _atr_restore(t):         return t

# [YENİ] Romaji Dedektor — 4 katmanlı Japonca/İngilizce ayırıcı
try:
    from romaji_detector import (
        classify_kara_group        as _rom_classify_group,
        classify_full_line         as _rom_classify_line,
        style_is_definitely_romaji as _rom_style_is_jp,
        style_is_definitely_english as _rom_style_is_eng,
        is_romaji                  as _rom_is_romaji,
        score_romaji               as _rom_score,
        split_mixed_line           as _rom_split_mixed,
        join_mixed_segments        as _rom_join_mixed,
    )
    _ROMAJI_DETECTOR_OK = True
except ImportError:
    _ROMAJI_DETECTOR_OK = False
    def _rom_classify_group(syls, style='', merged=''): return ('uncertain', 0.5, 'no_detector')
    def _rom_classify_line(text, style=''): return ('uncertain', 0.5, 'no_detector')
    def _rom_style_is_jp(s): return bool(re.search(r'(?:^|[^a-zA-Z])(?:JP|JPN|ROM|ROMAJI|RO)(?:[^a-zA-Z]|$)', s, re.IGNORECASE))
    def _rom_style_is_eng(s): return bool(re.search(r'(?:^|[^a-zA-Z])(?:EN|ENG)(?:[^a-zA-Z]|$)', s, re.IGNORECASE))
    def _rom_is_romaji(syls, t=0.65): return False
    def _rom_score(syls): return 0.5
    def _rom_split_mixed(text, style=''): return [('english', text)]
    def _rom_join_mixed(segs, tr): return tr

# [YENİ] Adaptif Pattern Öğrenici — her dosya sonunda öğrenilen pattern'leri kalıcı kaydet
try:
    from ass_skip_learner import pipeline_end_save as _learner_save
    _LEARNER_OK = True
except ImportError:
    _LEARNER_OK = False
    def _learner_save(): pass

# [YENİ] Content Detector — stil adına bakmadan içerik tabanlı tespit
try:
    from content_detector import (
        classify_event           as _cd_classify_event,
        classify_text            as _cd_classify_text,
        classify_style           as _cd_classify_style,
        is_song_event_by_content as _cd_is_song,
        is_karaoke_syllable      as _cd_is_kara_syllable,
        score_text_romaji        as _cd_score_romaji,
    )
    _CONTENT_DETECTOR_OK = True
except ImportError:
    _CONTENT_DETECTOR_OK = False
    def _cd_classify_event(*a, **kw): return ('uncertain', 0.4, 'no_cd')
    def _cd_classify_text(t, **kw): return ('unknown', 0.4, 'no_cd')
    def _cd_classify_style(s): return ('generic', 0.3, 'no_cd')
    def _cd_is_song(*a, **kw): return (False, 0, 'no_cd')
    def _cd_is_kara_syllable(t, d=0): return (False, 'no_cd')
    def _cd_score_romaji(t): return (0.5, 'no_cd')

from utils import log_error, extract_episode_number, auto_split_line, should_merge_lines, save_as_srt, save_as_vtt, is_garbage_line

try:
    from translator import SubtitleTranslator
except ImportError:
    print("translator.py bulunamadı! Çeviri özellikleri devre dışı.")
    SubtitleTranslator = None

try:
    from settings import load_translation_cache, save_translation_cache
except ImportError:
    # Fallback: Define dummy functions if not available
    def load_translation_cache(): return {}
    def save_translation_cache(cache): pass

# Validation helpers
try:
    from subtitle_position_helpers import validate_and_fix_position_tags, normalize_alignment_tags
except ImportError:
    # Fallback: Define dummy functions if not available
    def validate_and_fix_position_tags(text): return text
    def normalize_alignment_tags(text): return text

# [YENİ] Çeviri Doğrulama Motoru — verify_translation() entegrasyonu
try:
    from translation_verifier import verify_translation as _verify_translation, TranslationResult as _TranslationResult
    _VERIFIER_AVAILABLE = True
except ImportError:
    _VERIFIER_AVAILABLE = False
    def _verify_translation(src, cand, **kw):
        class _FakeResult:
            is_valid = True; score = 1.0; reason = 'verifier_offline'; signals = {}
        return _FakeResult()

# [YENİ] srt_equalizer — CPS aşımı otomatik satır bölme desteği
try:
    import srt_equalizer as _srt_eq
    _SRT_EQUALIZER_OK = True
except ImportError:
    _SRT_EQUALIZER_OK = False

# ============================================
# TEKİLLEŞTİRME (DEDUPLICATION) YARDIMCI FONKSİYON
# ============================================
_DEDUP_TAG_RE = re.compile(r'\{[^}]*\}')

def _get_dedup_key(event):
    """
    Bir event'in tekillestime anahtarini dondurur.
    ASS tag bloklari (__T0__ placeholder'lar ve {\\...} tag'leri) temizlenerek
    sadece saf metin karsilastirmasi yapilir.

    [FIX] tag'leri de temizle — farkli renk/pos/clip ile ayni metni gosteren
    satirlar (animasyon gradient katmanlari) artik ayni key'e dustugu icin
    DEDUP broadcast dogru calisir.
    """
    text = event.get("text", "")
    # Placeholder tag'leri kaldir (__T0__, __T1__ vb.)
    text = re.sub(r'__T\d+__', '', text)
    # ASS override tag bloklarini temizle {\\pos(...)\\blur...}
    text = _DEDUP_TAG_RE.sub('', text)
    # ASS ozel satir karakterlerini normalize et
    text = text.replace('\\N', ' ').replace('\\n', ' ').replace('\\h', ' ')
    base_key = text.strip().lower()
    return base_key


# ============================================
# TERMBASE UYUM KONTROLÜ
# ============================================
# Karakterler (characters) hariç — lokasyon, yetenek, organizasyon, terim
# kategorilerindeki EN→TR eşlemesi olan terimlerin çeviride doğru
# kullanılıp kullanılmadığını kontrol eder.
_TB_SKIP_CATS = frozenset({"characters"})   # bu kategoriler MUAF

def _check_termbase_compliance(src_text: str, tr_text: str, tb_lookup: dict) -> tuple:
    """
    Kaynak metindeki termbase terimlerinin çeviride doğru kullanılıp
    kullanılmadığını kontrol eder.

    Parametreler:
        src_text  : AI'ye gönderilen orijinal (İngilizce) metin
        tr_text   : AI'den gelen Türkçe çeviri
        tb_lookup : {en_lower: (tr, cat)} şeklinde flat sözlük
                    (karakterler dahil DEĞİL — _TB_SKIP_CATS muaf tutulur)

    Döndürür:
        (ok: bool, missed: list[tuple[en_original, tr_expected]])
        ok=True  → tüm zorunlu terimler doğru çevrilmiş
        ok=False → en az bir terim çeviride yanlış/eksik
    """
    if not tb_lookup or not src_text or not tr_text:
        return True, []

    src_lower = src_text.lower()
    tr_lower  = tr_text.lower()

    # Çok yaygın veya çok kısa İngilizce tek kelimeleri kontrol etme (false-positive önlemek için)
    _common_words = {"time", "day", "night", "world", "hand", "side", "head", "mind", "life", "part", "place", "work", "back", "year", "week", "say", "go", "get", "make", "know", "see", "come", "think", "look", "want", "give", "use", "find"}

    missed = []
    for en_key, (tr_val, cat) in tb_lookup.items():
        # Muaf kategoriler
        if cat in _TB_SKIP_CATS:
            continue
        # Türkçe karşılığı yoksa veya EN ile aynıysa kontrol etme
        if not tr_val or tr_val.lower() == en_key:
            continue
        # Çok kısa veya yaygın tek kelimeleri ele
        if len(en_key) <= 4 or en_key in _common_words:
            continue

        # Kaynak metinde bu İngilizce terim geçiyor mu?
        # Tam kelime eşleşmesi (word boundary) — kısa terimler yanlış tetiklemesin
        import re as _re_tb
        _pat = r'(?<![a-zA-Z])' + _re_tb.escape(en_key) + r'(?![a-zA-Z])'
        if not _re_tb.search(_pat, src_lower):
            continue
        # Çeviride Türkçe karşılığı var mı? (Ek biçimleri serbest bırakıldı)
        _tr_pat = r'(?<![a-zA-ZÇĞİÖŞÜçğışöüa-z])' + _re_tb.escape(tr_val.lower())
        if not _re_tb.search(_tr_pat, tr_lower):
            missed.append((en_key, tr_val))

    return (len(missed) == 0), missed


def _build_tb_lookup_from_prefs(prefs: dict) -> dict:
    """
    prefs['_tb_lookup'] varsa direkt döndürür.
    Yoksa prefs['_tb_data'] (cat→{en:tr}) yapısından flat sözlük üretir.
    Döndürür: {en_lower: (tr_val, category)} dict
    """
    # Önce hazır flat lookup'u dene
    _existing = prefs.get("_tb_lookup_flat")
    if _existing and isinstance(_existing, dict):
        return _existing

    tb_data = prefs.get("_tb_data", {})
    if not tb_data:
        return {}

    flat = {}
    for cat, mapping in tb_data.items():
        if cat in _TB_SKIP_CATS:
            continue
        if not isinstance(mapping, dict):
            continue
        for en, tr in mapping.items():
            if en and tr:
                flat[en.lower()] = (tr, cat)

    # Cache'e yaz — her satırda yeniden üretme
    prefs["_tb_lookup_flat"] = flat
    return flat




# ============================================
# ANIMASYON FRAME COLLAPSE
# ============================================
def collapse_animation_frames(events):
    """
    Ardisik, ayni temiz metne sahip Signs animasyon karelerini
    tek bir event'e birlestir.

    Ornek:
      Frame 1: 0:09:23.00->0:09:23.04  pos(1075,183) "Do you know what time"
      Frame 2: 0:09:23.04->0:09:23.08  pos(1075,184) "Do you know what time"
      ...25 kare...
      -> BIRLESTIRILMIS: 0:09:23.00->0:09:26.04  "Do you know what time"  (tek API cagrisi)

    Kural:
      - Sadece is_sign=True olan eventler
      - Ardisik (index olarak komsu) ve ayni temiz metin
      - Farkli timing = farkli sahneler → birlestirilmez
        (iki kare arasi bosluk > 500ms ise yeni sahne)
      - Birlestirilen event: ilk karenin ASS tagleri + start, son karenin end
      - Birlestirilen eventler 'collapsed_count' ile isaretlenir

    Returns: yeni events listesi (birlestirilmis + birlestirilmemis)
    """
    if not events:
        return events

    # ASS time -> ms cevirici
    def _t2ms(ts):
        try:
            h, m, rest = ts.strip().split(':')
            s, cs = rest.split('.')
            return int(h)*3600000 + int(m)*60000 + int(s)*1000 + int(cs)*10
        except Exception:
            return 0

    def _ms2t(ms):
        h  = ms // 3600000; ms %= 3600000
        m  = ms // 60000;   ms %= 60000
        s  = ms // 1000;    cs = (ms % 1000) // 10
        return f"{h}:{m:02d}:{s:02d}.{cs:02d}"

    TAG_RE_LOCAL = re.compile(r'\{[^}]*\}')
    def _clean(t):
        return TAG_RE_LOCAL.sub('', t).strip().lower()

    MAX_GAP_MS = 500  # iki kare arasi max bosluk (ms)

    result = []
    i = 0
    collapsed_total = 0

    while i < len(events):
        ev = events[i]

        # Sadece Signs efentleri collapse edilir
        if not ev.get('is_sign'):
            result.append(ev)
            i += 1
            continue

        # Bu karenin temiz metni
        base_clean = _clean(ev.get('text', ''))
        if not base_clean:
            result.append(ev)
            i += 1
            continue

        # Ayni temiz metne sahip ardisik kareleri topla
        group = [ev]
        j = i + 1
        while j < len(events):
            nev = events[j]
            if not nev.get('is_sign'):
                break
            n_clean = _clean(nev.get('text', ''))
            if n_clean != base_clean:
                break
            # Zaman boslugu kontrolu
            prev_end_ms   = _t2ms(group[-1].get('end', group[-1].get('parts', ['','',''])[2] if group[-1].get('parts') else '0:00:00.00'))
            next_start_ms = _t2ms(nev.get('start', nev.get('parts', ['','',''])[1] if nev.get('parts') else '0:00:00.00'))
            if next_start_ms - prev_end_ms > MAX_GAP_MS:
                break  # Bosluk cok buyuk = yeni sahne
            group.append(nev)
            j += 1

        if len(group) == 1:
            # Tek kare, collapse gerekmez
            result.append(ev)
            i += 1
            continue

        # COLLAPSE: ilk karenin start, son karenin end
        first = group[0]
        last  = group[-1]
        first_start = first.get('start', first.get('parts', ['','',''])[1] if first.get('parts') else '')
        last_end    = last.get('end',   last.get('parts',  ['','','',''])[2] if last.get('parts') else '')

        # [FIX KRİTİK] deepcopy yerine first dict'ini DOĞRUDAN güncelle.
        # deepcopy ile merged yeni bir obje olur → structured_events'teki first (İngilizce)
        # güncellenmez → rescue İngilizce görür ve yeniden çevirir (2500+ false rescue).
        # Orijinal objeyi güncelleyince batch yazımı doğrudan structured_events'e yansır.
        first['start']  = first_start
        first['end']    = last_end
        first['collapsed_count'] = len(group)
        first['_collapsed_group'] = group  # broadcast için sakla

        # parts listesindeki start/end de güncelle
        if first.get('parts') and len(first['parts']) >= 3:
            first['parts'][1] = first_start
            first['parts'][2] = last_end

        result.append(first)
        collapsed_total += len(group) - 1  # kaçını atlayacağız
        i = j  # j'ye atla (grubun sonu)


    if collapsed_total > 0:
        print(f"   [FrameCollapse] {collapsed_total} animasyon karesi "
              f"{sum(1 for e in result if e.get('collapsed_count', 0) > 1)} gruba birlestirildi")

    return result



def _string_similarity(s1: str, s2: str) -> float:
    """
    Hızlı string benzerliği.
    rapidfuzz kuruluysa token_set_ratio kullanır (kelime sırası bağımsız),
    yoksa difflib.SequenceMatcher'a düşer.
    """
    if not s1 and not s2:
        return 1.0
    if not s1 or not s2:
        return 0.0
    if _RAPIDFUZZ_OK:
        return _rfuzz.token_set_ratio(s1, s2) / 100.0
    # difflib fallback (özyineleme kaldırıldı!)
    return difflib.SequenceMatcher(None, s1, s2).ratio()

def broadcast_collapsed_frames(events):
    """
    collapse_animation_frames() ile birlestirilen event'lerin cevirisini
    tum orijinal karelere yayar.

    Yayim kurali:
      - Birlestirilen event'in cevrilmis metni alinir (tag'ler siyrilmis)
      - Her orijinal kareye KENDI ASS tag'leri + cevrilmis metin yazilir
      - Birlestirilen event YERINE tum orijinal kareler listeye eklenir
        (animasyon efekti korunur; sadece metin Turkce olur)
    """
    if not any(e.get('collapsed_count', 0) > 1 for e in events):
        return events  # Hicbir collapse yok, hizlica don

    TAG_RE_L = re.compile(r'\{[^}]*\}')
    BRACKET_P = re.compile(r'\{[^}]*\}')

    result = []
    broadcast_count = 0

    for ev in events:
        if ev.get('collapsed_count', 0) <= 1:
            result.append(ev)
            continue

        # Birlestirilen event'in cevrilmis metnini al
        translated_full = ev.get('text', ev.get('parts', [''] * 10)[9] if ev.get('parts') else '')
        # Sadece saf ceviri metnini al (tagleri siyir)
        translated_clean = BRACKET_P.sub('', translated_full).strip()
        translated_clean = re.sub(r'__T\d+__', '', translated_clean).strip()

        if not translated_clean:
            # Ceviri bos geldiyse orijinal grubun ilk karesini yaz, gerisi atla
            result.append(ev)
            continue

        # Orijinal karelere ceviriyi yay
        group = ev.get('_collapsed_group', [ev])
        for frame in group:
            frame_copy = dict(frame)
            # Kareye ozgu ASS tag'lerini al
            frame_tags = frame.get('tags', [])
            frame_tag_map = frame.get('tag_map', {})

            if frame_tag_map:
                final_text = restore_tags_from_placeholders(translated_clean, frame_tag_map)
            elif frame_tags:
                final_text = restore_tags(translated_clean, frame_tags)
            else:
                final_text = translated_clean

            frame_copy['text'] = final_text
            if frame_copy.get('parts') and len(frame_copy['parts']) >= 10:
                frame_copy['parts'][9] = final_text
            # [FIX1] _pysubs2_ev dogrudan guncelle (tag blogu koru)
            _bc_ev_ref = frame.get('_pysubs2_ev')
            if _bc_ev_ref is not None:
                _orig_bc_text = _bc_ev_ref.text or ''
                _bc_tag_block = re.search(r'^((?:\{[^}]*\})+)', _orig_bc_text)
                if _bc_tag_block and final_text and not final_text.startswith('{'):
                    _bc_ev_ref.text = _bc_tag_block.group(1) + final_text
                else:
                    _bc_ev_ref.text = final_text
            # Collapse isaretini kaldir (broadcast edildi)
            frame_copy.pop('collapsed_count', None)
            frame_copy.pop('_collapsed_group', None)
            result.append(frame_copy)
            broadcast_count += 1

    if broadcast_count > 0:
        print(f"   [FrameCollapse] {broadcast_count} kareye ceviri yayildi")

    return result

def create_byte_based_batches(events, max_bytes, max_lines=None):
    """
    Subtitle Edit yaklaşımı: Satır sayısı yerine byte sayısına göre batch oluştur.
    Bu, uzun satırlar olduğunda API rate limit'e çarpmayı önler.

    Args:
        events:    İşlenecek event listesi
        max_bytes: Batch başına maksimum byte sayısı (örn: 2000)
        max_lines: Batch başına maksimum satır sayısı (UI'dan gelir, örn: 10)
                   None = sınırsız (sadece byte limitine bak)

    Returns:
        Batch'lere bölünmüş event listesi
    """
    batches = []
    current_batch = []
    current_bytes = 0

    for event in events:
        text = event.get("text", "")
        # UTF-8 byte sayısını hesapla
        text_bytes = len(text.encode('utf-8'))

        # Byte limiti VEYA satır sayısı limiti aşılıyorsa → yeni batch başlat
        byte_full = (current_bytes + text_bytes > max_bytes) and current_batch
        line_full = (max_lines is not None and len(current_batch) >= max_lines)

        if (byte_full or line_full) and current_batch:
            batches.append(current_batch)
            current_batch = []
            current_bytes = 0

        current_batch.append(event)
        current_bytes += text_bytes

    if current_batch:
        batches.append(current_batch)

    return batches

# ============================================
# SUBTITLE CLEANING KEYWORDS
# ============================================
# Regex Patterns (Repeated here or imported if safe, sticking to local definitions for safety in processing loop)
JP_CHARS = r'\u3000-\u303F\u3040-\u309F\u30A0-\u30FF\uFF00-\uFFEF\u4E00-\u9FAF\u3400-\u4DBF'

# [COPYRIGHT SKIP] Telif hakki bildirimleri hicbir zaman ceviriye gitmemeli
_COPYRIGHT_SKIP_RE = re.compile(
    r'(?i)(?:'
    r'\xa9|\u00a9|copyright|\(c\)\s*\d|production\s+committee|'
    r'all\s+rights\s+reserved|shueisha|kodansha|aniplex|'
    r'crunchyroll|funimation|sentai\s+filmworks'
    r')', re.IGNORECASE
)

DRAWING_PATTERN = re.compile(r'\\p[1-9]')
POSITION_PATTERN = re.compile(r'\\(pos|move|org|clip|iclip|fad|fade|an[1-9]|bord|xbord|ybord|shad|xshad|yshad|blur|fsp|fs\d)')
BRACKET_PATTERN = re.compile(r'\{.*?\}')
HTML_TAG_PATTERN = re.compile(r'<[^>]+>')
JP_PATTERN_NORMAL = re.compile(r'\([^)]*[' + JP_CHARS + r']+[^\)]*\)')
JP_PATTERN_FULL = re.compile(r'（[^）]*[' + JP_CHARS + r']+[^\）]*）')
JP_CHAR_REMOVER = re.compile(r'[' + JP_CHARS + r']+')

# DELETE_KEYWORDS: Kesinlikle silinecek gereksiz işaretler
DELETE_KEYWORDS = []
# SONG_KEYWORDS: Silinmeyecek ama ÇEVRİLMEYECEK (Korunacak) stiller
# Fansub gruplarının kullandığı tüm şarkı/romaji stil adı kalıpları
SONG_KEYWORDS = [
    # ── Standart OP / ED ────────────────────────────────────────────────────
    'op', 'ed', 'song', 'opening', 'ending', 'insert',
    'oped', 'inssong', 'insong',
    'opsong', 'edsong',
    'lyric', 'lyrics',

    # ── NCOP / NCED (No Credits Opening/Ending) ─────────────────────────────
    # Creditless versiyonlar — yine de sarki sozu icerir!
    'ncop', 'nced', 'nc',
    'cleanop', 'cleaned', 'creditless',
    'clean',

    # ── Karaoke temelli stil adları (K-OP, K-ED, Kara-OP) ───────────────────
    # Bazı gruplar KFX icin ozel stil kullanır
    # 'kara' ve 'karaoke' halihazırda SKIP listesinde
    # Ama Karaoke_EN gibi EN suffix’li versiyonlar translate olmali

    # ── Intro / Outro / Preview ──────────────────────────────────────────
    'intro', 'outro',
    'preview',

    # ── Vokâl / Şarkıcı stilleri ──────────────────────────────────────────
    # Duo, Choir, Singer vb. grup sarkilarinda kullanilir
    'sing', 'vocal', 'vocals',
    'singer',          # Main Singer, Sub Singer
    'chorus',          # Koro / Nakarat bolumu
    'choir',           # Koro
    'duo',             # Iki sarkici
    'group',           # Grup sarkilari
    'harmony',         # Uyum sesi
    'backing',         # Arka plan vokali

    # ── Tema / İmaj Şarkıları ────────────────────────────────────────────────
    'theme',
    'image', 'imagesong', 'imageop', 'imageed',

    # ── Özel Sahneler ─────────────────────────────────────────────────────
    # Bazi gruplar flashback veya preview sahnelerindeki sarkilar icin kullanir
    # Bunlar icerik analizi ile denetlenmeli

    # ── Full / Special / Version varyantları ────────────────────────────────
    'full',
    'special',
    'version',
    'remix',
    'acoustic',
    'short',

    # ── Şarkı bölümleri ─────────────────────────────────────────────────────
    'chorus',
    'verse',
    'refrain',
    'bridge',

    # ── BGM / Müzik ─────────────────────────────────────────────────────
    'bgm',
    'music',

    # ── Japonca / Karaoke stil etiketleri (bunlar standalone degil, ınert olarak SKIP)
    # NOT: jp, rom, jpn, romaji buradan KALDIRILDI
    # Bunlar STYLE_SUFFIX_SKIP listesinde zaten var;
    # segment bazlı eslesmede 'Default - JP' gibi diyalog stilleri yanlis
    # sarki sayiliyordu. Dil etiketi SADECE sarki keyword'u varken anlam tasir.
    'kara', 'karaoke',

    # ── GJM fansub grubu ozel stilleri ───────────────────────────────
    'insjp', 'insrom', 'inskana', 'insmem', 'inskai',
    'insen', 'inseng',
    'ins',   # Kisa ins prefix (InsSong, InsEN vb.) segment kontrolu ile
]

# ==============================================================
# STİL ADI SONEK SİSTEMİ
# Stil adının soneki çeviri davranışını belirler.
# Ayraç ne olursa olsun yakalanır: ED-ROM, ED_ROM, ED ROM, EDROM
# ==============================================================
# Ekran üzü yazı stilleri: kısa ve literal çeviri
_SIGN_STYLE_NAMES = {
    # Temel sign/ekran yazısı stilleri
    "signs", "sign", "caption", "typeset",
    "detail", "note", "onscreen", "on-screen",
    "location", "overlay", "label", "banner", "board",
    # NOT: 'title' kaldirildi — SAO/genel animelerde 'title' stili
    # cevirilmesi gereken ekran metni icerir (Kara Kilic Ustasi vb.)
    # NOT: 'prev'/'next' kaldirildi — bunlar gradient frame stilleri,
    # is_tag_heavy_fx + clip detection tarafindan zaten yakalanir
    # Bölüm başlığı / geçiş kartları — spesifik formlar
    "eyecatch", "eye-catch",
    "ep-title", "episode-title", "episode", "eptitle", "episodetitle",
    "titlecard",   # Tam form — kesinlikle sign karti
    "intertitle",  # Araya giren baslik karti
    "card", "namecard", "name-card",
    # Genel ekran metni türleri
    "announcement", "subtitle-sign",
    # NOT: 'flashback', 'screen', 'text', 'info' kaldirildi —
    # flashback diyalog cevirilmeli; screen/text/info cok generic
}

STYLE_SUFFIX_SKIP = {
    # Japonca / Romaji / Karaoke — cevirme
    'ROM', 'ROMAJI', 'ROMANIZED', 'ROMANIZATION',
    'JPN', 'JP', 'JAP', 'JAPANESE', 'JPNESE',
    'KANA', 'KANJI',
    'CHN', 'CN', 'ZH', 'CHI', 'CHINESE',
    'KOR', 'KR', 'KOREAN',
    'KARA', 'KARAOKE', 'KAR',
    # NOT: 'LYRICS'/'LYRIC' buradan kaldirildi — Lyric/Lyrics-EN gibi Ingilizce sarki stili olabilir
    'CREDIT', 'CREDITS', 'CREDIT2', 'STAFF', 'CAST',
    'NOTE', 'TL', 'TLNOTE', 'TRNOTE', 'EDNOTE',
    'BGM', 'MUSIC',
    'MEM', 'MEMORY',
    'FURIGANA', 'RUBY',
    # GJM ozel skip stilleri
    'INSJP', 'INSROM', 'INSKANA', 'INSMEM', 'INSKAI',
    # Karaoke_JP, Song_JP gibi JP suffix kombinasyonlar
    'KAI',  # GJM InsKai (Kanji)
}

STYLE_SUFFIX_FORCE_TRANSLATE = {
    'ENG', 'EN', 'ENGLISH',
    'ALT', 'ALTDIAL',
    'TRANS', 'TRANSLATION',
    # GJM/Fansub Insert English
    'INSEN', 'INSENG',
    # NCOP/NCED creditless Ingilizce
    'NC',
    # Full/Clean versiyonları
    'FULL', 'CLEAN', 'CREDITLESS',
    # Varyant versiyonlar (OP Remix EN, ED Acoustic EN)
    'REMIX', 'ACOUSTIC',
}

def is_sign_style_name(style_name: str) -> bool:
    """
    İsim üzerinden Sign/ekran üzü yazısı stilini tespit eder.
    Diyalog satirı değildir: lokasyon, başlık, pano vb.
    """
    s = style_name.lower().strip()
    s_clean = s.replace('-', '').replace('_', '').replace(' ', '')
    # Tam eşleşme
    if s_clean in _SIGN_STYLE_NAMES or s_clean in {n.replace('-','').replace('_','') for n in _SIGN_STYLE_NAMES}:
        return True
    # Önekle başlayan: "signs-en", "signs-styled", "signtl", "signboard"
    if s_clean.startswith('sign'):
        return True
    # Anahtar kelime içeriyor
    for kw in ('typeset', 'caption', 'onscreen', 'label', 'banner', 'board', 'overlay'):
        if kw in s_clean:
            return True
    return False


def get_style_suffix_behavior(style_name):
    """
    Stil adının sonekinden çeviri davranışını belirler.
    Returns: 'skip' | 'translate' | None

    ÖNEMLİ: FORCE_TRANSLATE (EN, ENG, ALT) her zaman SKIP'ten önce gelir.
    ED1-EN-kara gibi birleşik stil adlarında EN içeriyorsa → çeviri zorlanır.
    """
    s = style_name.strip().upper()
    # Ayraçları temizlemeden önce parçalara ayır (-, _, boşluk)
    parts = re.split(r'[-_\s]', s)  # ['ED1', 'EN', 'KARA']

    # 1. Herhangi bir parça FORCE_TRANSLATE ise → hemen 'translate' döndür
    for part in parts:
        if part in STYLE_SUFFIX_FORCE_TRANSLATE:
            return 'translate'

    # 2. Herhangi bir parca SKIP listesinde ise skip dondur
    # [FIX] ED1-JP-ButDark gibi JP ortada olsa da dogru tanisın
    for part in parts:
        if part in STYLE_SUFFIX_SKIP:
            return 'skip'

    # 3. Ayracsiz birlesik sonek (fallback)
    # 2. Ayraçsız birleşik sonek kontrolü (eski davranış, fallback)
    s_clean = re.sub(r'[-_\s]', '', s)
    for suffix in STYLE_SUFFIX_SKIP:
        if s_clean.endswith(suffix) and s_clean != suffix:
            return 'skip'
    for suffix in STYLE_SUFFIX_FORCE_TRANSLATE:
        if s_clean.endswith(suffix) and s_clean != suffix:
            return 'translate'
    return None


def is_song_style_name(style_name):
    s = style_name.lower().strip()

    # [FIX] Furigana suffix tespiti: 'Default-furigana', 'OP1 - ROM-furigana' gibi
    # Bu satirlar cevrilmez — ASS'de ust hece notasyonu (ruby text) icin kullanilir.
    if s.endswith('furigana') or '-furigana' in s or '_furigana' in s:
        return True

    # Tam eslesme + onek kontrolleri
    for kw in SONG_KEYWORDS:
        # Tam eslesme: 'op', 'ed', 'kara' vb.
        if s == kw:
            return True
        # Onek eslesimi SADECE rakamla devam ediyorsa: 'op1', 'op2', 'ed1'
        if s.startswith(kw) and len(s) > len(kw) and s[len(kw)].isdigit():
            return True
        # Ayracli: 'op_bg', 'op bg', 'op-bg', 'op.1' → hepsi song
        if s.startswith(kw) and len(s) > len(kw) and s[len(kw)] in ('_', ' ', '-', '.'):
            return True

    # Segment bazlı kontrol: GJM_InsEN, Chyuu_InsROM, SubsPlease_InsJP
    # Her bölümü ayrı kontrol et: "GJM_InsEN" → ["gjm", "insen"]
    # [FIX] jp/rom/en gibi dil-ONLY segmentler tek başına şarkı sayılmamalı!
    # ('Default - JP' → ['default','jp'] → 'jp' yanlış şarkı sayılıyordu)
    _INSERT_SONG_RE = re.compile(
        r'^(?:ins(?:ert)?|inssong|insong)(?:\d*[-_]?(?:jp|jpn|rom|en|eng|kana|mem|kai))?',
        re.IGNORECASE
    )
    _LANG_ONLY_SEGS = frozenset({
        'jp', 'jpn', 'jap', 'japanese',
        'rom', 'romaji', 'romanized',
        'en', 'eng', 'english',
        'kr', 'kor', 'korean',
        'zh', 'cn', 'chi', 'chinese',
        'tr', 'kana', 'kanji',
    })
    for seg in re.split(r'[-_\s]', s):
        if not seg:
            continue
        # Dil-only segment → atla (tek başına 'JP', 'ROM' şarkı değil)
        if seg in _LANG_ONLY_SEGS:
            continue
        # SONG_KEYWORDS tam segment eşleşimi
        if seg in SONG_KEYWORDS:
            return True
        # Insert song prefix (ins, insert, InsEN, InsJP...)
        if _INSERT_SONG_RE.match(seg):
            return True
    return False



# ==============================================================
# PHASE 2 — ŞARKI SÖZLERİ ÇEVİRİSİ
# ==============================================================
_SONG_TAG_RE  = re.compile(r'\{[^}]*\}')
_SONG_TR_CHARS = set('ğşçöüıİĞŞÇÖÜ')
# Prefix strip: '1. ', '2) ' ve Gemini [L1]/[L2] marker'lari
# Prefix strip: '1. ', '2) ' ve Gemini [L1]/[L2]/[L3] marker'lari
# MULTILINE ile hem satır başı hem satır içi [Lx] marker'ları temizlenir
_SONG_PREFIX_RE = re.compile(
    r'(?:^\d+[.)]\s+|\[L\d+\]\s*)',
    re.MULTILINE
)
# Fansub editor notu effect alani: '[term fix]', '[fix]' vb. (CrappySubs)
_EDIT_NOTE_RE_FX = re.compile(r'^\[[\w\s]+\]$')

# ASS vector draw komutu tespiti: "m 0 0 m 100 100" gibi
_DRAW_CMD_RE  = re.compile(r'\b(?:m|l|b|s|p|c|n)\s+-?\d+\s+-?\d+', re.IGNORECASE)

# ── İçerik Tabanlı Şarkı / Karaoke Tespiti ────────────────────────────────────
_MUSIC_NOTE_RE  = re.compile(r'[♪♫~～]')
_KARAOKE_TAG_RE = re.compile(r'\{[^}]*\\k\d+[^}]*\}', re.IGNORECASE)  # {\k100}

def _ts_ms(ts_str):
    """ASS zaman string'ini ms'ye çevirir: '0:23:54.18' → 1434180"""
    try:
        h, m, rest = str(ts_str).replace(',', '.').split(':')
        s, cs = rest.split('.')
        return int(h)*3600000 + int(m)*60000 + int(s)*1000 + int(cs)*10
    except Exception:
        return 0

def is_likely_song_by_content(ev, all_events=None, ep_duration_ms=0):
    """
    Stil adından bağımsız olarak bir event'in şarkı/karaoke olup olmadığını
    içerik analizi ile tespit eder.

    İpuçları (her biri puan ekler, toplam >= 2 → şarkı):
      +3  ♪ / ♫ müzik notu içeriyor
      +3  {\\kXX} karaoke zamanlama tag'i var
      +2  Metin < 4 kelime VE süre < 400ms (hece karaoke)
      +1  Bölüm başı (0-90s) veya sonu (son 180s) AND kısa metin
      +1  Aynı stil adındaki komşu eventler de kısa (< 5 kelime) → OP/ED bloğu

    Returns: (bool, int score, str reason)
    """
    parts = ev.get('parts', [])
    if len(parts) < 10:
        return False, 0, 'no_parts'

    raw_text   = parts[9]
    clean      = _SONG_TAG_RE.sub('', raw_text).strip()
    start_ms   = _ts_ms(parts[1])
    end_ms     = _ts_ms(parts[2])
    duration   = max(0, end_ms - start_ms)
    word_count = len(clean.split()) if clean else 0
    score      = 0
    reasons    = []

    # İpucu 1: Müzik notu
    if _MUSIC_NOTE_RE.search(clean) or _MUSIC_NOTE_RE.search(raw_text):
        score += 3
        reasons.append('music_note')

    # İpucu 2: Karaoke zamanlama tag'i
    if _KARAOKE_TAG_RE.search(raw_text):
        score += 3
        reasons.append('karaoke_tag')

    # İpucu 3: Çok kısa süre + az kelime = hece karaoke
    if duration < 400 and word_count <= 3 and word_count >= 1:
        score += 2
        reasons.append(f'short_ev_dur={duration}ms_words={word_count}')

    # İpucu 4: Bölüm başı/sonu pozisyonu + kısa metin
    if (start_ms < 90_000 or (ep_duration_ms > 0 and start_ms > ep_duration_ms - 180_000)):
        if word_count <= 8:
            score += 1
            reasons.append('op_ed_position')

    # İpucu 5: Komşularda da kısa eventler mi var? (OP/ED bloğu)
    if all_events and word_count <= 6:
        style = parts[3]
        same_style = [e for e in all_events
                      if e.get('parts', [''] * 4)[3] == style
                      and e is not ev]
        if same_style:
            avg_words = sum(
                len(_SONG_TAG_RE.sub('', e['parts'][9]).split())
                for e in same_style[:20] if len(e.get('parts', [])) > 9
            ) / min(len(same_style), 20)
            if avg_words <= 6:
                score += 1
                reasons.append(f'neighbor_short_avg={avg_words:.1f}')

    is_song = score >= 2
    return is_song, score, '+'.join(reasons) if reasons else 'no_signal'

def is_likely_karaoke_syllable_by_content(ev):
    """
    Tek bir event'in karaoke hecesi olup olmadığını kontrol eder.
    Hece karaoke: cok kisa sure + 1-3 karakter metin veya \k tag'i.
    """
    parts = ev.get('parts', [])
    if len(parts) < 10:
        return False
    raw   = parts[9]
    clean = _SONG_TAG_RE.sub('', raw).strip()
    dur   = max(0, _ts_ms(parts[2]) - _ts_ms(parts[1]))
    if _KARAOKE_TAG_RE.search(raw):
        return True
    if len(clean) <= 3 and dur < 600:
        return True
    return False


def _is_english_song_event(ev_item):
    """
    Event'in Ingilizce sarki sozu event'i olup olmadigini tespit eder.
    Romaji, Japonca, karaoke-hece, Turkce -> False doner.
    """
    style = ev_item.get('parts', [''] * 4)[3] if ev_item.get('parts') else ev_item.get('style', '')
    if not style:
        return False

    # ── Adım 0: ass_style_conventions.classify_style_name() ile güçlü ön filtreleme ──
    # SKIP_STYLE_WORDS, FORCE_TRANSLATE_STYLE_WORDS setleri (GJM, Chyuu, SubsPlease, CR)
    try:
        from ass_style_conventions import classify_style_name as _classify_sc
        _sc_result = _classify_sc(style)
        if _sc_result == 'skip':
            return False   # JP/ROM/KARA/CREDIT → kesinlikle atla
        _sc_force_translate = (_sc_result == 'translate')
    except ImportError:
        _sc_result = 'unknown'
        _sc_force_translate = False

    # ── Generic stil adı tespiti ──────────────────────────────────────────────
    # "Default", "Main", "Style0001", "Sign", "Alt" gibi anlamsız isimler
    # is_song_style_name'i geçemez. İçerik analizine geç.
    _GENERIC_STYLE_RE = re.compile(
        r'^(default|main|alt|sign|top|an\d|bottom|style\s*\d*|'
        r'subtitle|dialogue|dialog|note|screen|text|'
        r'event|flash|pos\d*|sub\d*|line\d*)$',
        re.IGNORECASE
    )
    _style_clean = re.sub(r'[-_\s]', '', style).lower()
    is_generic = bool(_GENERIC_STYLE_RE.match(_style_clean)) or _style_clean.startswith('style')

    if is_generic and not _sc_force_translate:
        # Stil adı generic → içerik analizine geç
        text = ev_item.get('parts', [''] * 10)[9] if ev_item.get('parts') and len(ev_item['parts']) > 9 else ''
        clean = _SONG_TAG_RE.sub('', text).strip()
        if not clean or len(clean) <= 2:
            return False
        if any(c in _SONG_TR_CHARS for c in clean):
            return False
        if not re.search(r'[a-zA-Z]{2,}', clean):
            return False
        # Karaoke syllable mi?
        if is_likely_karaoke_syllable_by_content(ev_item):
            return False
        # İçerik tabanlı şarkı tespiti
        _song_hit, _song_score, _song_why = is_likely_song_by_content(ev_item)
        return _song_hit
    # ──────────────────────────────────────────────────────────────────────────

    if not is_song_style_name(style):
        return False
    # 2. Skip gerektiren suffix var mı? (JP/ROM/KARA → atla)
    #    EN/ENG → doğrudan çevir
    #    None (suffix yok) → içerik analizine geç (örnk: "Opening", "OP1", "ED")
    behavior = get_style_suffix_behavior(style)
    if behavior == 'skip':
        return False
    # behavior == 'translate' → kesin çevir
    # behavior == None → suffix yok, içerik kontrolüne geç
    # 3. Karaoke hece eventi mi? (tek/çift karakter)
    text = ev_item.get('parts', [''] * 10)[9] if ev_item.get('parts') and len(ev_item['parts']) > 9 else ''
    clean = _SONG_TAG_RE.sub('', text).strip()
    if len(clean) <= 2:
        return False  # Karaoke hece: 'N', 'o', 'ne' gibi
    # 4. Draw command event mi? (\p1 ile çizilen harfler veya koordinat dataları)
    try:
        from ass_line_filter import is_drawing_line as _local_is_draw
        _is_draw_val = _local_is_draw(text) or _local_is_draw(clean)
    except Exception:
        _is_draw_val = bool(_DRAW_CMD_RE.search(clean)) and len(re.sub(r'[^a-zA-Z]', '', clean)) < 5
    if _is_draw_val:
        return False  # Vector art, metin değil
    # 5. Türkçe karakter içeriyorsa zaten çevrilmiş
    if any(c in _SONG_TR_CHARS for c in clean):
        return False
    # 6. En az 2 Latin harf içermeli
    if not re.search(r'[a-zA-Z]{2,}', clean):
        return False
    # 7. behavior=None → karaoke syllable değilse kabul et
    if behavior is None and not _sc_force_translate:
        if is_likely_karaoke_syllable_by_content(ev_item):
            return False
    return True



def _get_song_type(style_name):
    """Stil adından şarkı türünü belirle: Opening / Ending / Insert Song"""
    s = style_name.upper()
    parts = re.split(r'[-_\s]', s)
    if any(p in ('OP', 'OPENING', 'OPN') for p in parts): return 'Opening Song'
    if any(p in ('ED', 'ENDING', 'END') for p in parts):  return 'Ending Song'
    if any(p in ('INSERT', 'INS', 'IMAGE') for p in parts): return 'Insert Song'
    return 'Song'


# ─── Şarkı Sözü Çeviri Cache ──────────────────────────────────────────────────
def _get_song_cache_path():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), 'song_lyrics_cache.json')

def _load_song_cache():
    try:
        p = _get_song_cache_path()
        if os.path.exists(p):
            with open(p, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        pass
    return {}

def _save_song_cache(cache):
    try:
        with open(_get_song_cache_path(), 'w', encoding='utf-8') as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

def _make_song_cache_key(anime_title, season, en_lines, song_type=''):
    """
    Cache anahtarı: "AnimeAd|S3|OP|<hash>"
    - song_type dahil edildi: OP/ED/Insert aynı bölümde çakışmaz
    - hash: tıpatıp aynı metin → aynı hash, tek kelime fark → farklı hash
    """
    import hashlib
    _tag = re.compile(r'\{[^}]*\}')
    normalized = []
    for line in en_lines:
        c = _tag.sub('', line)
        c = re.sub(r'\\[nN]|__NL__|__SL__', ' ', c)
        c = ' '.join(c.split()).strip().lower()
        if c:
            normalized.append(c)
    h = hashlib.md5('|'.join(normalized).encode('utf-8')).hexdigest()[:12]
    s     = str(season) if season else '0'
    try:
        from termbase_manager import _split_title_season
        clean_title, _ = _split_title_season(anime_title)
    except Exception:
        clean_title = anime_title
    clean_title = re.sub(r'\s*-\s*\d+.*$', '', clean_title)
    title = re.sub(r'[^\w\s]', '', str(clean_title)).strip()
    stype = re.sub(r'[^\w]', '', str(song_type)).upper()[:12] if song_type else 'SONG'
    return f"{title}|S{s}|{stype}|{h}"
# ──────────────────────────────────────────────────────────────────────────────

def translate_song_lyrics_pass(structured_events, translator, media_context):
    """
    Phase 2: Ana çeviri bittikten sonra İngilizce şarkı stillerini
    ayrı, şiirsel/müzikal bir prompt ile Gemini'ye gönderir.

    - Romaji / JP / Karaoke-hece eventleri hiç dokunulmaz
    - Sadece ENG/EN suffix'li şarkı stilleri işlenir
    - Her stil grubu (OP, ED, Insert) ayrı batch olarak gönderilir
    - ev.text _pysubs2_ev referansı ile doğrudan güncellenir

    Returns: çevrilen event sayısı
    """
    from colorama import Fore, Style

    # Algılama Motoru flag'leri (media_context üzerinden gelir)
    _use_style_suffix = media_context.get('use_style_suffix_detection', True)
    _use_kara_collapse = media_context.get('use_karaoke_collapse', True)
    _ignore_style_romaji = media_context.get('ignore_song_style_for_romaji', False)

    song_events = []
    _pre_reserved = [ev for ev in structured_events if ev.get('type') == 'song_reserved']
    if _pre_reserved:
        song_events.extend(_pre_reserved)
        print(f"{Fore.CYAN}   [SongPass] {len(_pre_reserved)} pre-reserved şarkı satırı eklendi.{Style.RESET_ALL}")

    _seen_ids = {id(ev) for ev in song_events}

    if _use_style_suffix:
        _suffix_events = [
            ev for ev in structured_events 
            if _is_english_song_event(ev) and not (ev.get('skip_translation') and ev.get('type') != 'song_reserved')
        ]
        _added_suffix = 0
        for ev in _suffix_events:
            if id(ev) not in _seen_ids:
                song_events.append(ev)
                _seen_ids.add(id(ev))
                _added_suffix += 1
        if _added_suffix > 0:
            print(f"{Fore.CYAN}   [SongPass] {_added_suffix} stil suffix'li şarkı satırı eklendi.{Style.RESET_ALL}")
    else:
        _text_events = []
        for ev in structured_events:
            if ev.get('skip_translation') and ev.get('type') != 'song_reserved':
                continue
            style = ev['parts'][3] if len(ev.get('parts', [])) > 3 else ''
            if not is_song_style_name(style):
                continue
            text = ev['parts'][9] if len(ev.get('parts', [])) > 9 else ''
            clean = _SONG_TAG_RE.sub('', text).strip()
            if not clean or len(clean) <= 2:
                continue
            if any(c in _SONG_TR_CHARS for c in clean):
                continue
            if re.search(r'[a-zA-Z]{2,}', clean):
                _text_events.append(ev)
        
        _added_text = 0
        for ev in _text_events:
            if id(ev) not in _seen_ids:
                song_events.append(ev)
                _seen_ids.add(id(ev))
                _added_text += 1
        if _added_text > 0:
            print(f"{Fore.YELLOW}   [Motor] Stil suffix KAPALI — {_added_text} event metin analizi ile eklendi{Style.RESET_ALL}")

    if not song_events:
        return 0

    # 2. Stil grubuna göre gruplandır
    from collections import defaultdict
    groups = defaultdict(list)
    for ev in song_events:
        style = ev['parts'][3] if len(ev.get('parts', [])) > 3 else 'Unknown'
        song_type = _get_song_type(style)
        groups[song_type].append(ev)

    anime_title  = media_context.get('title', 'Unknown Anime')
    season_num   = media_context.get('season', '')
    episode_num  = media_context.get('episode', '')
    ctx_str      = f"{anime_title}"
    if season_num: ctx_str += f" Season {season_num}"
    if episode_num: ctx_str += f" Episode {episode_num}"

    total_fixed = 0
    _song_cache = _load_song_cache()   # Kalıcı şarkı sözü cache'i
    _song_cache_dirty = False
    lyrics_system_prompt = None        # Cache-hit durumunda da erişilebilir olsun

    for song_type, events_group in groups.items():
        print(f"{Fore.MAGENTA}   [SongPass] {song_type} — {len(events_group)} satir{Style.RESET_ALL}")

        # Grubun tüm İngilizce satırlarını topla (cache key için)
        all_en_lines = []
        for ev in events_group:
            t = ev['parts'][9] if len(ev.get('parts', [])) > 9 else ''
            all_en_lines.append(_SONG_TAG_RE.sub('', t).strip().replace('\\N', ' ').replace('\\n', ' '))

        # ── CACHE HIT KONTROLU ──────────────────────────────────────────────
        _ckey = _make_song_cache_key(anime_title, season_num, all_en_lines, song_type=song_type)
        if _ckey in _song_cache:
            _cached    = _song_cache[_ckey]
            _ctr       = _cached.get('tr_lines', [])
            _cached_en = _cached.get('en_lines', [])

            # ── İÇERİK DOĞRULAMASI: satır sayısı + en_lines tam eşleşmesi ──
            # Cache'deki satırlar farklıysa (eski/kısmi kayıt) → miss say
            _line_ok  = (len(_ctr) == len(events_group))
            _en_match = (_cached_en == all_en_lines) if _cached_en else True  # eski kayıtlarda yoksa kabul
            if not _line_ok or not _en_match:
                _why = f"satır sayısı {len(_ctr)}≠{len(events_group)}" if not _line_ok else "en_lines içerik farkı"
                print(f"{Fore.YELLOW}   [SongCache] ⚠ {song_type} — cache uyumsuz ({_why}), yeniden çevriliyor{Style.RESET_ALL}")
            else:
                print(f"{Fore.GREEN}   [SongCache] ✅ {song_type} — Ep{_cached.get('source_ep','?')} cache'i kullanılıyor, API atlandı{Style.RESET_ALL}")
                try:
                    from notif_bus import push_notif as _pn
                    _pn('SongCache: sarki sozu cacheden yuklendi', 'positive')
                except Exception: pass
                _STATIC_C = re.compile(r'(\{(?:[^{}]*?(?:\\pos\(|\\an\d|\\1c|\\c&H)[^{}]*?)\})')
                for _ci, _cev in enumerate(events_group):
                    if _ci >= len(_ctr) or not _ctr[_ci]:
                        continue
                    _orig = _cev['parts'][9] if len(_cev.get('parts', [])) > 9 else ''
                    _spfx = ''
                    for _m in _STATIC_C.finditer(_orig):
                        if not re.search(r'\\t\(|\\blur|\\bord|\\move\(', _m.group(0), re.IGNORECASE):
                            _spfx += _m.group(0)
                    _cfinal = _spfx + _ctr[_ci]
                    if len(_cev.get('parts', [])) > 9:
                        _cev['parts'][9] = _cfinal
                    _cev['text'] = _cfinal
                    _cpev = _cev.get('_pysubs2_event') or _cev.get('_pysubs2_ev')
                    if _cpev is not None:
                        _cpev.text = _cfinal
                        total_fixed += 1
                continue  # Bu grup bitti — API'ye gitme
        # ────────────────────────────────────────────────────────────────────

        # CACHE MISS — API'den çevir, sonucu kaydet
        _group_tr_results = {}   # batch_offset → translated_clean_text
    # Özel şarkı sözü system prompt'u
        lyrics_system_prompt = (
            f"You are a professional anime song lyric translator specializing in Turkish localization.\n\n"
            f"ANIME: {ctx_str}\n"
            f"SONG TYPE: {song_type}\n\n"
            "TRANSLATION RULES:\n"
            "1. This is SONG LYRICS — translate POETICALLY, not literally.\n"
            "2. Maintain the emotional tone, rhythm feel, and poetic flow.\n"
            "3. Write natural Turkish — how real Turkish music fans would feel the song.\n"
            "4. Keep character names and honorifics (-san, -kun, -chan, etc.) unchanged.\n"
            "5. Very short lines (1-4 words): preserve their brevity in Turkish.\n"
            "6. NEVER refuse. NEVER add explanations. Just translate.\n"
            "7. Return ONLY the translated lines with [L1], [L2]... format. Nothing else.\n"
            "8. If a line is already in Turkish, return it unchanged."
        )

        # Batch olarak API'ye gönder (en fazla 30 satır)
        BATCH_SIZE = 30
        for batch_start in range(0, len(events_group), BATCH_SIZE):
            batch = events_group[batch_start:batch_start + BATCH_SIZE]

            # Çevrilecek metinleri hazırla
            lines_to_send   = []   # API'ye gidecek (romaji ayıklanmış) metinler
            _mixed_segments = []   # Her satır için segment listesi (romaji geri koymak için)
            _cur_style = batch[0]['parts'][3] if batch and len(batch[0].get('parts', [])) > 3 else ''

            for ev in batch:
                text = ev['parts'][9] if len(ev.get('parts', [])) > 9 else ''
                clean = _SONG_TAG_RE.sub('', text).strip().replace('\\N', ' ').replace('\\n', ' ')

                if _ignore_style_romaji and _ROMAJI_DETECTOR_OK:
                    # Karma satır → romaji ayıkla, sadece İngilizce kısmı gönder
                    segs = _rom_split_mixed(clean, _cur_style)
                    eng_only = ' '.join(t for l, t in segs if l == 'english').strip()
                    _mixed_segments.append(segs)
                    lines_to_send.append(eng_only if eng_only else clean)
                else:
                    _mixed_segments.append(None)
                    lines_to_send.append(clean)

            # ── [DEDUP] Aynı metni sadece 1 kez çevir, gerisine yay ────────────
            # Ana pipeline'daki mantığın aynısı: clean_text → tek API çağrısı
            # Kriterler:
            #   1. Aynı clean metin  → textual dedup
            #   2. Aynı start+end zamanı → timing dedup (JP+ROM multi-track)
            _song_dedup_map = {}   # clean_text → [batch_index, ...]
            _song_time_map  = {}   # (start, end) → [batch_index, ...]

            for _di, _dev in enumerate(batch):
                _dc = lines_to_send[_di]
                # Metin bazlı
                if _dc not in _song_dedup_map:
                    _song_dedup_map[_dc] = []
                _song_dedup_map[_dc].append(_di)
                # Zaman bazlı (aynı timing → multi-track satır)
                _dstart = _dev.get('parts', [None]*4)[1] if len(_dev.get('parts', [])) > 1 else None
                _dend   = _dev.get('parts', [None]*4)[2] if len(_dev.get('parts', [])) > 2 else None
                if _dstart is not None and _dend is not None:
                    _dtk = (_dstart, _dend)
                    if _dtk not in _song_time_map:
                        _song_time_map[_dtk] = []
                    _song_time_map[_dtk].append(_di)

            # Hangi indexler "birincil" (API'ye gidecek) vs "kopya" (broadcast alacak)?
            _primary_indices  = []   # API'ye gidecek unique indexler
            _copy_of          = {}   # copy_index → primary_index (metin dedup)
            _time_primary     = {}   # (start,end) → ilk karşılaşılan primary index

            _seen_texts = {}
            for _di in range(len(batch)):
                _dc = lines_to_send[_di]
                if _dc in _seen_texts:
                    # Metin kopyası → broadcast al
                    _copy_of[_di] = _seen_texts[_dc]
                else:
                    _seen_texts[_dc] = _di
                    _primary_indices.append(_di)

            # Timing dedup: aynı zamanlı birden fazla primary var mı?
            # (Örn: JP satırı + ROM satırı aynı start/end ama farklı metin)
            # Bu satırlarda sadece ilkini çevir (İngilizce olan), diğeri boş kalır
            for (_dtk, _dgroup) in _song_time_map.items():
                _dprims = [i for i in _dgroup if i in _primary_indices]
                if len(_dprims) > 1:
                    # İlk primary kalsın, diğerleri timing-kopya olsun
                    for _dp in _dprims[1:]:
                        if _dp not in _copy_of:
                            _copy_of[_dp] = _dprims[0]
                            _primary_indices.remove(_dp)

            _dedup_saved_song = len(batch) - len(_primary_indices)
            if _dedup_saved_song > 0:
                print(f"   [SongDedup] {_dedup_saved_song} tekrar satır atlandı → {len(_primary_indices)} unique API'ye gönderilecek")

            # Sadece primary indexleri gönder
            _primary_texts = [lines_to_send[i] for i in _primary_indices]
            # ──────────────────────────────────────────────────────────────────

            # Numara ile formatla: "[L1] satir\n[L2] satir\n..."
            numbered = '\n'.join(f'[L{i+1}] {line}' for i, line in enumerate(_primary_texts))

            try:
                # system_prompt'u geçici olarak şarkı sözü prompt'uyla değiştir
                _orig_prompt = translator.config.get('system_prompt', '')
                translator.config['system_prompt'] = lyrics_system_prompt

                import time as _time_mod

                # translate_batch — sadece unique satırları gönder
                response = translator.translate_batch(_primary_texts)

                # Orijinal prompt'u geri yükle
                translator.config['system_prompt'] = _orig_prompt

                if not response:
                    continue

                # Yanıtı parse et — translate_batch liste döndürür
                if isinstance(response, list):
                    # primary_indices sırasına göre map: primary_idx → çeviri
                    _primary_tr = {}
                    for _pi_pos, _pi_idx in enumerate(_primary_indices):
                        if _pi_pos < len(response) and response[_pi_pos] and response[_pi_pos].strip():
                            _primary_tr[_pi_idx] = response[_pi_pos]
                elif isinstance(response, str):
                    _primary_tr = {}
                    for match in re.finditer(r'\[L(\d+)\]\s*(.+?)(?=\[L\d+\]|$)', response, re.DOTALL):
                        _lpos = int(match.group(1)) - 1
                        _lt   = _SONG_PREFIX_RE.sub('', match.group(2).strip())
                        if _lt and _lpos < len(_primary_indices):
                            _primary_tr[_primary_indices[_lpos]] = _lt
                else:
                    continue

                # ── BROADCAST: kopya indexlere primary'nin çevirisini yay ──
                _all_tr = dict(_primary_tr)
                for _ci, _pi in _copy_of.items():
                    if _pi in _primary_tr:
                        _all_tr[_ci] = _primary_tr[_pi]

                # Her event'e yaz
                for i, ev in enumerate(batch):
                    if i not in _all_tr:
                        continue
                    translated = str(_all_tr[i]).strip()
                    translated = _SONG_PREFIX_RE.sub('', translated)
                    translated = re.sub(r'\[L\d+\]\s*', '', translated).strip()
                    if not translated:
                        continue

                    # Karma satır: romaji segmentlerini geri ekle
                    segs = _mixed_segments[i] if i < len(_mixed_segments) else None
                    if segs and any(l == 'romaji' for l, _ in segs):
                        translated = _rom_join_mixed(segs, translated)
                        print(f"     [MixedLine] Romaji geri eklendi: {repr(translated[:60])}")

                    # Tag yönetimi
                    orig_text = ev['parts'][9] if len(ev.get('parts', [])) > 9 else ''
                    _ANIM_TAG_RE = re.compile(
                        r'\{[^}]*(?:\\t\(|\\blur|\\bord|\\move\(|\\org\(|\\fad\(|\\fade\()[^}]*\}',
                        re.IGNORECASE
                    )
                    _STATIC_TAGS = re.compile(r'(\{(?:[^{}]*?(?:\\pos\(|\\an\d|\\1c|\\c&H)[^{}]*?)\})')
                    static_prefix = ''
                    for m in _STATIC_TAGS.finditer(orig_text):
                        if not re.search(r'\\t\(|\\blur|\\bord|\\move\(', m.group(0), re.IGNORECASE):
                            static_prefix += m.group(0)
                    final = static_prefix + translated

                    _is_broadcast = (i in _copy_of)
                    _tag = "📢 [broadcast]" if _is_broadcast else "✓"

                    if len(ev.get('parts', [])) > 9:
                        ev['parts'][9] = final
                    ev['text'] = final

                    _pev = ev.get('_pysubs2_event') or ev.get('_pysubs2_ev')
                    if _pev is not None:
                        _pev.text = final
                        total_fixed += 1
                        print(f"     {_tag} {repr(translated[:50])}")
                    else:
                        print(f"     ⚠ [SongPass] _pev=None, text='{final[:40]}' ev_keys={list(ev.keys())[:6]}")

                    # Cache için: global event index → temiz çeviri metni
                    _global_i = batch_start + i
                    _group_tr_results[_global_i] = translated

                _time_mod.sleep(0.5)


            except Exception as _e:
                translator.config['system_prompt'] = _orig_prompt
                print(f"{Fore.RED}   [SongPass] Batch hatasi: {_e}{Style.RESET_ALL}")

        # API bitti — grubu cache'e kaydet (en az 1 başarılı çeviri varsa)
        if _group_tr_results:
            import datetime
            _tr_lines_for_cache = [_group_tr_results.get(i, '') for i in range(len(events_group))]
            _song_cache[_ckey] = {
                'song_type':  song_type,
                'en_lines':   all_en_lines,          # İçerik doğrulama için saklanıyor
                'tr_lines':   _tr_lines_for_cache,
                'cached_at':  str(datetime.date.today()),
                'source_ep':  str(episode_num),
                'line_count': len(events_group),
            }
            _song_cache_dirty = True
            print(f"{Fore.CYAN}   [SongCache] 💾 {song_type} (Ep{episode_num}) — {len(events_group)} satır cache'lendi. Sonraki aynı sözlerı API'ye gitmeyecek{Style.RESET_ALL}")


    # Yeni cache entry'leri varsa diske yaz
    if _song_cache_dirty:
        _save_song_cache(_song_cache)

    # ── KARAOKE COLLAPSE PASS ────────────────────────────────────
    if _use_kara_collapse:
        kara_collapsed = _collapse_and_translate_karaoke(
            structured_events, translator, lyrics_system_prompt, ctx_str
        )
        if kara_collapsed > 0:
            print(f"{Fore.MAGENTA}   [KaraCollapse] {kara_collapsed} kara-satir coker edildi{Style.RESET_ALL}")
            try:
                from notif_bus import push_notif as _pn
                _pn(f'KaraCollapse: {kara_collapsed} karaoke satiri birlestirildi', 'info')
            except Exception: pass
            total_fixed += kara_collapsed
    else:
        print(f"{Fore.YELLOW}   [Motor] Karaoke Collapse KAPALI{Style.RESET_ALL}")
    # ─────────────────────────────────────────────────────────────

    return total_fixed


def _preprocess_collapse_karaoke(subs):
    """
    PRE-PROCESSING: pysubs2 SSAFile event listesini structured_events'e
    donusturulmeden ONCE karaoke eventleri isler:

    MOD A — Full-line kara (3+ kelime): Her event bagımsız, sadece tag soy +
             style → base EN stili (ED1-EN-kara → ED1-EN). Birleştirme YOK.
    MOD B — Letter/hece kara (1-2 char, kara suffix'li): Zaman penceresi ile grupla, birlestir.
    MOD C — {k...} tag'li ama kara suffix'siz per-syllable EN sarki: Ayni timestamp
             grubundaki heceler birlestirilir, karaoke tag'leri temizlenir, ceviri
             icin hazirlanir. (Ornek: ED1-EN stilinde her hece ayri event)
    Draw command eventleri: tamamen bosalt + Comment'e al.

    Returns: islenen event/grup sayisi
    """
    _TAG_RE   = re.compile(r'\{[^}]*\}')
    _TR_CHARS = set('ğşçöüıİĞŞÇÖÜ')
    # {\kXX}, {\kfXX}, {\koXX}, {\ktXX} — tüm karaoke zamanlama tag'leri
    _KARA_TAG_RE = re.compile(r'\{[^}]*\\[kK][fFoOtT]?\d+[^}]*\}')

    # Dosyadaki varsayılan diyalog stilini bul
    _default_style = 'Default'
    for _st in subs.styles:
        if _st.lower() in ('default', 'dialogue', 'main', 'dialog'):
            _default_style = _st
            break

    GAP_MS = 1000  # 1 saniyeden fazla bosluk → yeni grup

    # ── Karaoke stili tespit (hem EN/ENG hem JP/ROM kontrol et)
    def _is_kara_style(style):
        """Stil herhangi bir karaoke suffixine sahip mi?"""
        return 'kara' in style.lower() or 'karaoke' in style.lower()

    def _kara_needs_translation(style):
        """Bu kara stili İngilizce → çeviri gerekiyor mu?
        romaji_detector'a sorulur; stil adı kesin romaji/JP ise → hayır"""
        # Stil adı kesin romaji/JP ise hiç çevirme
        if _rom_style_is_jp(style):
            return False
        # Stil adı kesin İngilizce ise çevir
        if _rom_style_is_eng(style):
            return get_style_suffix_behavior(style) == 'translate'
        # Belirsiz: behavior kontrol
        return get_style_suffix_behavior(style) == 'translate'

    # Kara suffix soy → base stil
    def _base_style(style):
        b = re.sub(r'[-_]?kara(?:oke)?$', '', style, flags=re.IGNORECASE).rstrip('-_ ')
        return b if b else _default_style

    total_collapsed = 0

    # ══════════════════════════════════════════════════════════════════
    # MOD C: {k...} tag'li ama kara suffix'siz per-syllable EN sarkilar
    # Ozel durum: ED1-EN, OP1-EN gibi sarkı stilleri her heceyi ayri event
    # olarak kodluyorsa bunları zaman-penceresiyle birleştir.
    # ══════════════════════════════════════════════════════════════════
    _MODC_GAP_MS = 150   # Hece arası max boşluk (ms) — karaoke timing çok sık
    _modc_by_style = {}
    for ev in subs:
        if ev.type == 'Comment':
            continue
        if _is_kara_style(ev.style):
            continue  # MOD A/B zaten hallediyor
        # Şarkı stili olmalı
        if not is_song_style_name(ev.style):
            continue
        # Stil çeviri gerektirmeli (JP/ROM değil)
        if _rom_style_is_jp(ev.style):
            continue
        # Metinde {k...} tag olmalı
        if not _KARA_TAG_RE.search(ev.text):
            continue
        clean = _TAG_RE.sub('', ev.text).replace('\\N', '').replace('\\n', '').strip()
        if not clean:
            continue
        # Zaten Türkçe ise atla
        if any(c in _TR_CHARS for c in clean):
            continue
        # Draw command ise atla
        try:
            from ass_line_filter import is_drawing_line as _local_is_draw
            _is_draw_val = _local_is_draw(ev.text) or _local_is_draw(clean)
        except Exception:
            _is_draw_val = bool(_DRAW_CMD_RE.search(clean)) and len(re.sub(r'[^a-zA-Z]', '', clean)) < 5
        if _is_draw_val:
            ev.type = 'Comment'
            continue
        _modc_by_style.setdefault(ev.style, []).append(ev)

    for style, ev_list in _modc_by_style.items():
        # Zamana göre sırala
        ev_list_sorted = sorted(ev_list, key=lambda e: e.start)
        # Zamana göre grupla — ardışık hece grubu
        groups = []
        cur_grp = [ev_list_sorted[0]]
        for ev in ev_list_sorted[1:]:
            # Bir önceki event'in bitiş zamanına yakın mı?
            gap = ev.start - cur_grp[-1].end
            if gap <= _MODC_GAP_MS:
                cur_grp.append(ev)
            else:
                if len(cur_grp) >= 2:  # 2+ hece birleşince anlam kazanır
                    groups.append(cur_grp)
                cur_grp = [ev]
        if len(cur_grp) >= 2:
            groups.append(cur_grp)

        for grp in groups:
            # Temiz metin parçalarını al
            parts_text = []
            for ev in grp:
                ch = _TAG_RE.sub('', ev.text).replace('\\N', '').replace('\\n', '').strip()
                if ch:
                    parts_text.append(ch)
            merged = ' '.join(parts_text).strip()
            if len(merged) < 2:
                continue

            # İlk event → birleştirilmiş metin + geniş süre
            first = grp[0]
            first.text  = merged           # Tag'siz temiz EN
            first.end   = grp[-1].end      # Son heceye kadar uzat
            # Stil suffix'ini temizle (OP1-EN → OP1-EN, zaten ok)
            # kara suffix yoktu, stil olduğu gibi kalır

            # Geri kalan heceleri Comment yap
            for ev in grp[1:]:
                ev.type = 'Comment'

            total_collapsed += 1
            print(f"   [KaraMODC] '{merged[:40]}' — {len(grp)} hece birlestirildi ({style})")
    # ══════════════════════════════════════════════════════════════════


    # Stil bazında eventleri topla
    from collections import defaultdict
    _by_style = defaultdict(list)
    for ev in subs:
        if ev.type == 'Comment':
            continue
        if not _is_kara_style(ev.style):
            continue
        clean = _TAG_RE.sub('', ev.text).replace('\\N', '').replace('\\n', '').strip()
        # Draw command eventleri → tamamen gizle (sadece Comment yap, metni silme)
        try:
            from ass_line_filter import is_drawing_line as _local_is_draw
            _is_draw_val = _local_is_draw(ev.text) or _local_is_draw(clean)
        except Exception:
            _is_draw_val = bool(_DRAW_CMD_RE.search(clean)) and len(re.sub(r'[^a-zA-Z]', '', clean)) < 5
        if _is_draw_val:
            ev.type = 'Comment'  # Gizle ama orijinal metni koru
            continue
        # Boş
        if not clean:
            ev.type = 'Comment'  # Gizle ama orijinal metni koru
            continue
        # Türkçe ise zaten çevrilmiş → atla
        if any(c in _TR_CHARS for c in clean):
            continue
        _by_style[ev.style].append((ev, clean))

    if not _by_style:
        return 0

    for style, ev_pairs in _by_style.items():
        bs = _base_style(style)

        # ── ROMAJI TESPITI: Üç katmanlı analiz ────────────────────────
        # Grup için tüm heceleri al ve birleştir
        all_syllables = [ch for _, ch in ev_pairs]
        merged_text   = ' '.join(all_syllables)

        # Katman 1: romaji_detector (stil adı + fonotaktik + hece listesi)
        label, conf, reason = _rom_classify_group(all_syllables, style, merged_text)

        # Katman 2: Belirsiz sonucu romaji_filter (157K kanwadict4 DB) ile doğrula
        if label == 'uncertain' and _is_romaji_sentence_v2 is not None:
            # Birleşik metinde tam cümle analizi yap
            db_is_romaji = _is_romaji_sentence_v2(merged_text)
            if db_is_romaji:
                label = 'romaji'
                reason = f'kanwadict_confirm({reason})'
            elif not _kara_needs_translation(style):
                # DB de romaji demedi ama çeviri gerekmiyor → güvenli atlama
                label = 'romaji'
                reason = f'no_translate_behavior({reason})'
            else:
                # DB romaji demedi VE stil çeviri istiyor → İngilizce kabul et
                label = 'english'
                reason = f'kanwadict_reject({reason})'

        # Katman 3: Stil adı kesin romaji ise her zaman atla
        if _rom_style_is_jp(style):
            label = 'romaji'
            reason = f'style_override'

        # Romaji → sessizleştir (sadece Comment yap, metni silme)
        if label == 'romaji':
            for ev, _ in ev_pairs:
                ev.type = 'Comment'  # Gizle ama orijinal romaji metni dosyada kalsin
            continue  # Bu stili atla

        # İngilizce / çeviri gerekiyor → devam
        # (label == 'english')

        # ── MOD KARAR: Full-line mi, Letter/hece mi? ──────────────────
        # İlk event'in temiz metnine bak
        sample_clean = ev_pairs[0][1]
        word_count = len(sample_clean.split())
        is_fullline_mode = word_count >= 3  # 3+ kelime → full cümle modu
        # ──────────────────────────────────────────────────────────────

        if is_fullline_mode:
            # ── MOD A: Full-line kara ─────────────────────────────────
            # Her event bağımsız: sadece tag soy + style değiştir
            # Birleştirme YOK → Phase 2'ye birer birer gider
            for ev, clean in ev_pairs:
                ev.text  = clean       # Tag'siz temiz İngilizce
                ev.style = bs          # ED1-EN-kara → ED1-EN
                total_collapsed += 1
            # ─────────────────────────────────────────────────────────
        else:
            # ── MOD B: Letter/hece kara ──────────────────────────────
            # Zaman penceresine göre grupla, birleştir
            evs_sorted = sorted(ev_pairs, key=lambda x: x[0].start)

            groups = []
            cur = [evs_sorted[0]]
            for item in evs_sorted[1:]:
                ev = item[0]
                if ev.start - cur[-1][0].end > GAP_MS:
                    groups.append(cur)
                    cur = [item]
                else:
                    cur.append(item)
            groups.append(cur)

            for grp in groups:
                chars = [ch for _, ch in grp]
                # Her parcayi boslukla birlestir
                # Onceki kod kisa (<=2 char) parcalari bosluksuz yapistiriyordu
                # Bu 'shi'+'ma'+'tsu' = 'shimatsui' gibi bozukluga yol aciyordu
                parts = []
                for ch in chars:
                    if ch.strip():
                        parts.append(ch.strip())
                merged = ' '.join(parts)  # Her zaman boslukla birlestir
                merged = merged.strip()
                if len(merged) < 3:
                    continue

                grp_start = grp[0][0].start
                grp_end   = grp[-1][0].end

                first_ev = grp[0][0]
                first_ev.start = grp_start
                first_ev.end   = grp_end
                first_ev.text  = merged
                first_ev.style = bs

                for ev, _ in grp[1:]:
                    ev.type = 'Comment'  # Gizle ama metni silme (gruba birleştirildi)

                total_collapsed += 1
            # ─────────────────────────────────────────────────────────

    return total_collapsed

def _collapse_and_translate_karaoke(structured_events, translator,
                                    lyrics_system_prompt, ctx_str):
    """
    Hece/harf bazlı karaoke İngilizce eventleri toplar, birleştirir,
    çevirir ve tek bir hareketsiz static event'e indirger.

    Algoritma:
    1. 'kara' suffix'li + İngilizce (EN/ENG) stilleri bul
    2. Aynı stil içinde zamana göre gruplara ayır (boşluk > 1sn → yeni grup)
    3. Her grubun text'ini birleştir, tüm tag'leri soy
    4. İngilizce ise çevir
    5. İlk event = merged süre + Türkçe metin (tag'siz)
    6. Geri kalan event'ler = boş metin (görünmez)

    Returns: collapse edilen grup sayısı
    """
    from colorama import Fore, Style
    import time as _time_mod

    # --- Yardımcı: ASS zaman string → ms ---
    def _ts2ms(ts):
        try:
            h, m, rest = str(ts).replace(',', '.').split(':')
            s, cs = rest.split('.')
            return int(h)*3600000 + int(m)*60000 + int(s)*1000 + int(cs)*10
        except Exception:
            return 0

    def _ms2ts(ms):
        ms = max(0, int(ms))
        h  = ms // 3600000; ms %= 3600000
        m  = ms //   60000; ms %=   60000
        s  = ms //    1000; ms %=    1000
        cs = ms //      10
        return f'{h}:{m:02d}:{s:02d}.{cs:02d}'

    # --- Karaoke stil adını tespit et ---
    def _is_kara_style(style):
        s = style.lower()
        # 'kara' veya 'karaoke' içermeli
        if 'kara' not in s and 'karaoke' not in s:
            return False
        # İngilizce suffix zorunlu (behavior == 'translate')
        return get_style_suffix_behavior(style) == 'translate'

    # 1. Karaoke İngilizce eventleri filtrele
    kara_events = []
    for ev in structured_events:
        parts = ev.get('parts', [])
        if len(parts) < 10:
            continue
        style = parts[3]
        if not _is_kara_style(style):
            continue
        # Metnin İngilizce olup olmadığını kontrol et (Türkçe char yoksa)
        clean = _SONG_TAG_RE.sub('', parts[9]).strip()
        if not clean:
            continue
        if any(c in _SONG_TR_CHARS for c in clean):
            continue  # Zaten çevrilmiş
        kara_events.append(ev)

    if not kara_events:
        return 0

    print(f"{Fore.MAGENTA}   [KaraCollapse] {len(kara_events)} kara event bulundu{Style.RESET_ALL}")

    # 2. Stil adına + zamana göre gruplara ayır
    from collections import defaultdict
    by_style = defaultdict(list)
    for ev in kara_events:
        style = ev['parts'][3]
        by_style[style].append(ev)

    GAP_MS   = 1000  # 1 saniyeden büyük boşluk → yeni satır grubu
    collapsed = 0

    for style, evs in by_style.items():
        # Başlangıç zamanına göre sırala
        evs_sorted = sorted(evs, key=lambda e: _ts2ms(e['parts'][1]))

        # Gruplara ayır
        groups = []
        cur_group = [evs_sorted[0]]
        for ev in evs_sorted[1:]:
            prev_end   = _ts2ms(cur_group[-1]['parts'][2])
            this_start = _ts2ms(ev['parts'][1])
            if this_start - prev_end > GAP_MS:
                groups.append(cur_group)
                cur_group = [ev]
            else:
                cur_group.append(ev)
        groups.append(cur_group)

        print(f"{Fore.MAGENTA}   [KaraCollapse] {style}: {len(groups)} satir grubu{Style.RESET_ALL}")

        # 3. Her grubu birleştir + çevir
        lines_to_translate = []
        _group_is_fullsentence = []
        for grp in groups:
            chars = []
            for ev in grp:
                ch = _SONG_TAG_RE.sub('', ev['parts'][9]).replace('\\N', '').replace('\\n', '').strip()
                chars.append(ch)
            parts_list = [ch for ch in chars if ch.strip()]
            merged = ' '.join(parts_list).strip()

            # Tam cümle tespiti: her event uzun metinse (ED1-EN-kara gibi)
            # bu bir hece-karaoke değil, song pass zaten çevirdi — atla
            avg_ev_len = sum(len(c) for c in parts_list) / max(len(parts_list), 1)
            is_full = avg_ev_len > 12
            _group_is_fullsentence.append(is_full)
            if is_full:
                print(f"{Fore.CYAN}   [KaraCollapse] ATLANDI (tam cumle song pass isledi): {merged[:50]!r}{Style.RESET_ALL}")
            lines_to_translate.append(merged)

        valid_indices = [
            i for i, t in enumerate(lines_to_translate)
            if len(t) >= 3 and not _group_is_fullsentence[i]
        ]

        if not valid_indices:
            continue

        lines_clean = [lines_to_translate[i] for i in valid_indices]
        groups_valid = [groups[i] for i in valid_indices]

        # 4. Çeviri
        try:
            _orig_prompt = translator.config.get('system_prompt', '')
            # lyrics_system_prompt tüm gruplar cache hit ise None olabilir — fallback oluştur
            _lsp = lyrics_system_prompt or (
                f"You are an anime song lyric translator. Translate the following song lines "
                f"to natural, poetic Turkish. Context: {ctx_str}. "
                "Return ONLY the translated lines, one per line. Do not add explanations."
            )
            translator.config['system_prompt'] = _lsp
            response = translator.translate_batch(lines_clean)
            translator.config['system_prompt'] = _orig_prompt

            if isinstance(response, list):
                translations = {i: str(r).strip() for i, r in enumerate(response) if r and str(r).strip()}
            else:
                translations = {}
        except Exception as _e:
            translator.config['system_prompt'] = _orig_prompt
            print(f"{Fore.RED}   [KaraCollapse] Ceviri hatasi: {_e}{Style.RESET_ALL}")
            continue

        # 5. Her gruba uygula
        for local_i, (grp, src_text) in enumerate(zip(groups_valid, lines_clean)):
            translated = translations.get(local_i, '')
            translated = _SONG_PREFIX_RE.sub('', translated)
            translated = re.sub(r'\[L\d+\]\s*', '', translated).strip()
            # [FIX3] API draw command dondurmuse fallback
            if len(re.findall(r'\bm\s+\d+\s+\d+\b', translated)) >= 3:
                _ltrs = re.findall(r'[a-zA-Z\u2014\-]+', src_text.replace('m 0 0 m 100 100 ', ''))
                translated = ' '.join(_ltrs[:20]) if _ltrs else src_text
            # [L1]/[L2]/[L3] marker'larini temizle (SONG_PREFIX_RE zaten halleder)
            translated = _SONG_PREFIX_RE.sub('', translated)
            translated = re.sub(r'\[L\d+\]\s*', '', translated).strip()

            if not translated:
                translated = src_text  # Fallback: orijinal (İngilizce kalır)

            # Grubun toplam süresini hesapla
            grp_start_ms = _ts2ms(grp[0]['parts'][1])
            grp_end_ms   = _ts2ms(grp[-1]['parts'][2])
            new_start    = _ms2ts(grp_start_ms)
            new_end      = _ms2ts(grp_end_ms)

            # İlk event: birleşik süre + temiz çeviri
            first_ev    = grp[0]
            first_parts = first_ev['parts']
            first_parts[1] = new_start
            first_parts[2] = new_end
            first_parts[9] = translated  # Tag'siz temiz Türkçe
            first_ev['text'] = translated
            _pev = first_ev.get('_pysubs2_ev')
            if _pev is not None:
                _pev.text    = translated
                _pev.start   = grp_start_ms
                _pev.end     = grp_end_ms

            # Geri kalan event'ler: boşalt
            for ev in grp[1:]:
                ev['parts'][9] = ''
                ev['text']     = ''
                _pev2 = ev.get('_pysubs2_ev')
                if _pev2 is not None:
                    _pev2.text = ''

            print(f"     [{style}] {repr(src_text[:35])} → {repr(translated[:35])}")
            collapsed += 1
            _time_mod.sleep(0.2)

    return collapsed


SIGN_KEYWORDS = DELETE_KEYWORDS

CREDIT_KEYWORDS = [
    'ceviri', 'ceviren', 'fansub', 'sunar',
    # Cevirmen ifadeleri — sadece kesin krediler
    'translated by', 'translation by', 'translation:', 'ceviri:', 'ceviren:',
    'edited by', 'editing by', 'editor:', 'duzenleyen:',
    'timed by', 'timing by', 'timing:', 'senkronize:',
    'encoded by', 'encoding by', 'upscaled by', 'encode:',
    'quality check', 'qc by', 'typeset by', 'karaoke by',
    'fansubbed by', 'subbed by', 'subtitles by', 'altyazi:',
    'hazirlayan:', 'hazirlayanlari:',
    'subs by', 'sub by', 'fansub by', 'soft sub by', 'hardsub by',
    # Sosyal medyaya DAVET ifadeleri (URL ile beraber kullanılan)
    'join discord', 'join our server', 'join our discord',
    'follow us on', 'find us on',
    'our discord', 'our server',
    # Bağış platformları (tam URL formatı)
    'discord.gg', 'discord.com/invite',
    'ko-fi.com', 'buymeacoffee.com', 'paypal.me', 'linktr.ee',
    'patreon.com', 'twitter.com', 'instagram.com', 'youtube.com',
    'reddit.com', 'discord.com', 'tiktok.com', 'twitch.tv',
    # Fansub grup kalıpları
    'fansubber', 'subgroup', 'sub group', 'scanlation',
    'sakuracircle', 'productions',
    # Açık URL formatları
    'http://', 'https://', 'www.',
    # Altyazı metadata (encode kalıpları)
    'upscaled by', 'subtitled by',
]


# Kredi satiri regex kaliplari (URL veya sosyal hesap iceren satirlar)
_CREDIT_REGEX_PATTERNS = re.compile(
    r'(?ix)'
    r'discord\.gg/[\w-]+|'             # discord.gg/invite
    r'discord\.com(?:/invite)?/[\w-]+|'# discord.com/invite/xxx
    r't\.me/[\w-]+|'                    # telegram
    r'youtu\.be/[\w-]+|'               # youtube kisa
    r'linktr\.ee/[\w-]+|'              # linktree
    r'ko-fi\.com/[\w-]+|'              # ko-fi
    r'buymeacoffee\.com/[\w-]+|'       # buymeacoffee
    r'patreon\.com/[\w-]+|'            # patreon
    r'paypal\.me/[\w-]+|'              # paypal me
    r'^@[a-zA-Z0-9_]{2,}$|'            # @handle SADECE - sozluk/referans degilse (in-anime post degil)
    r'https?://[^\s]+|'                # herhangi URL
    r'www\.[\w.-]+\.[a-z]{2,}|'        # www.site.com
    r'[\w.-]+\.(?:com|org|net|moe|gg|tv|io|me|link)/[\w-]+|'  # site.com/path
    # © ayri blokta studio check ile kontrol ediliyor (buradan kaldirildi)
    r'\[\w+(?:subs|fansub|raw|hd)\]'   # [SubsPlease] [FansubNameHD] gibi
)
# Hareketli taglerdeki anlamlı kısa kelimeleri korumamak (çevirmek) için
SHORT_ENGLISH_WHITELIST = {
    # 1-3 letter common words that might appear in signs/dialogue
    "i", "a", "ok", "no", "yes", "go", "hi", "ha", "ah", "oh", "hm", 
    "to", "in", "on", "at", "by", "up", "of", "or", "as", "if", "it", 
    "is", "he", "we", "do", "my", "me", "us", "be", "so", "an",
    "run", "end", "fin", "ask", "bad", "big", "box", "boy", "bus", 
    "but", "buy", "can", "car", "cat", "cut", "dad", "day", "die", 
    "dog", "eat", "eye", "fat", "fit", "fly", "for", "fun", "get", 
    "god", "got", "guy", "hey", "hit", "hot", "how", "hug", "job", 
    "joy", "key", "kid", "kit", "law", "let", "lie", "low", "mad", 
    "man", "map", "may", "mom", "new", "nor", "not", "now", "num", 
    "off", "oil", "old", "one", "out", "own", "pay", "pie", "pig", 
    "put", "red", "run", "sad", "saw", "say", "sea", "see", "set", 
    "she", "shy", "sin", "sit", "six", "sky", "son", "sun", "tap", 
    "tea", "ten", "the", "tie", "too", "top", "try", "two", "use", 
    "van", "war", "way", "who", "why", "win", "wow", "yes", "yet", "you"
}

def extract_tags(text):
    """
    Extracts {\\pos...} style tags from the text.
    Returns: (clean_text, tags_list)
    Sadece gerçek ASS tag'leri (backslash içerenler) döner.
    Inline comment'ler ({-san}, {bro wtf}) tamamen atlanır.
    """
    if _ASS_EXTRACTOR_AVAILABLE:
        # Yeni motor: comment blokları filtrelenir
        import re as _re
        _BLOCK = _re.compile(r'\{[^}]*\}')
        matches = []
        for m in _BLOCK.finditer(text):
            blk = m.group(0)
            if '\\' in blk:  # Sadece gerçek ASS tag'leri
                matches.append(blk)
        clean_text = _re.sub(r'\{[^}]*\}', '', text).strip()
        return clean_text, matches
    else:
        # Fallback: eski basit yöntem
        pattern = re.compile(r'\{.*?\}')
        matches = pattern.findall(text)
        clean_text = pattern.sub('', text).strip()
        return clean_text, matches

def restore_tags(text, tags):
    """
    Restores tags to the beginning of the text.
    """
    if not tags: return text
    tag_str = "".join(tags)
    return f"{tag_str}{text}"

def extract_tags_with_placeholders(text):
    """
    {\\...} tag bloklarini __T0__, __T1__... placeholder'larla degistirir.
    Tag'lerin orijinal metin icindeki konumlarini korur.
    Returns: (placeholder_text, tag_map_dict)

    [UPGRADE] ass_tag_extractor modulunu kullanir:
      - Gercek ASS tag bloklari (backslash icerenler) → __T0__ placeholder
      - Inline comment bloklari ({-san}, {bro wtf}, {wailing?}) → SILINDI
        (AI bu bloklari goremez, bozamaz, placeholder'a donusturemez)
    Source: libass/ass_parse.c — valid tags MUST start with backslash
    """
    if _ASS_EXTRACTOR_AVAILABLE:
        clean_text, tag_map = _ass_extract(text)
        return clean_text, tag_map
    else:
        # Fallback: eski yontem
        pattern = re.compile(r'\{[^}]*\}')
        tag_map = {}
        counter = [0]
        def replacer(m):
            tag_content = m.group(0)
            if '\\' not in tag_content:
                return ''
            key = f'__T{counter[0]}__'
            tag_map[key] = tag_content
            counter[0] += 1
            return key
        placeholder_text = pattern.sub(replacer, text)
        return placeholder_text, tag_map

def restore_tags_from_placeholders(text, tag_map):
    """
    __T0__, __T1__... placeholder'lari orijinal tag'lerle degistirir.
    Tag'ler orijinal konumlarina tam olarak yerlestrilir.
    AI placeholder'lari sildiyse eksik tag'ler basa eklenir.

    [UPGRADE] ass_tag_extractor'in fuzzy restore motorunu kullanir:
      - Exact match: __T0__ → tag
      - Fuzzy: __T 0__, __t0__, [T0], (T0) → tag
      - Pozisyon tag'leri (pos/move/org/an) eksikse → basa ekle
      - Son asama: kalan __Tn__ kalıntılarını temizle
    """
    if not tag_map:
        return text

    if _ASS_EXTRACTOR_AVAILABLE:
        restored, _missing = _ass_restore(text, tag_map)
        # Kalan __Txx__ kalıntıları temizle
        restored = re.sub(r'__[Tt]\d+__', '', restored)
        return restored
    else:
        # Fallback: eski yontem
        restored_keys = set()
        for key, tag in tag_map.items():
            if key in text:
                text = text.replace(key, tag)
                restored_keys.add(key)
            elif key.lower() in text.lower():
                pattern = re.compile(re.escape(key), re.IGNORECASE)
                if pattern.search(text):
                    text = pattern.sub(tag, text)
                    restored_keys.add(key)
        missing_tags = [tag_map[k] for k in tag_map if k not in restored_keys]
        if missing_tags:
            # Akıllı yerleştirme: açılış/kapanış çiftlerini tespit et
            # {\i1}...{\i0}, {\b1}...{\b0}, {\u1}...{\u0} gibi çiftler
            _OPEN_RE  = re.compile(r'\{\\([ibuscBIUS])1\}')
            _CLOSE_RE = re.compile(r'\{\\([ibuscBIUS])0\}')
            # Tüm missing tag'leri sona ekle (başa değil — daha az zararli)
            # Gerçek çift varsa orjinal metnin anahtar kelimeleriyle match dene
            for _mt in missing_tags:
                _om = _OPEN_RE.match(_mt)
                _cm = _CLOSE_RE.match(_mt)
                if _om or _cm:
                    # İtalik/bold/underline tag'i — sona ekle
                    text = text + _mt
                else:
                    # Konum tag'i (pos, move, an, clip) → BASA ekle
                    text = _mt + text
        text = re.sub(r'__[Tt]\d+__', '', text)
        return text

# ============================================
# ASS ÖZEL KARAKTER KORUMASI (\N \n \h)
# ============================================
# \N = Hard Newline (satır sonu, kesinlikle kırılır)
# \n = Soft Newline (wrap moduna göre kırılır)
# \h = Hard Space (bölünmeyen boşluk)
# Bunlar çeviriye giderse AI siler ya da bozar — placeholder ile koruyoruz.
_ASS_SPECIAL_CHARS = [
    ('\\N', '__NL__'),  # Hard newline  (ASS: tek backslash + N)
    ('\\n', '__SL__'),  # Soft newline  (ASS: tek backslash + küçük n)
    ('\\h', '__HS__'),  # Hard space    (ASS: tek backslash + h)
]

def protect_ass_newlines(text):
    """
    ASS özel satır/boşluk karakterlerini placeholder'lara çevirir.
    Çeviriye göndermeden ÖNCE çağrılmalı.

    Dönüşümler:
      \\N → __NL__
      \\n → __SL__
      \\h → __HS__
      <br />, <br/>, <BR> vb. → __NL__  [FIX: kaynak HTML br desteği]

    Returns: (protected_text, True/False değişiklik oldu mu)
    """
    changed = False
    # [FIX] Kaynak dosyada <br /> varsa (başka araçtan üretilmiş satır vb.)
    # AI'ya göndermeden önce __NL__'e çevir. Restore sırasında \N olur.
    if '<br' in text.lower():
        new_text = re.sub(r'(?i)<br\s*/?>', '__NL__', text)
        if new_text != text:
            text = new_text
            changed = True
    for original, placeholder in _ASS_SPECIAL_CHARS:
        if original in text:
            text = text.replace(original, placeholder)
            changed = True
    return text, changed


def restore_ass_newlines(text):
    """
    protect_ass_newlines() ile değiştirilen placeholder'ları geri yükler.
    Çeviri sonrası MUTLAKA çağrılmalı.

    Dönüşümler:
      __NL__ → \\N
      __SL__ → \\n
      __HS__ → \\h

    [FIX] Restore sonrası art arda \\N\\N → \\N dedup.
    [FIX2] <br /> HTML etiketleri → \\N (AI cache/fuzzy path dahil her yerde).
    [FIX3] __NL____NL__ placeholder dedup restore öncesi.
    """
    # [FIX3] Placeholder dedup — restore öncesi (kaynak ASS'de \\N\\N varsa)
    if '__NL____NL__' in text or '__SL____SL__' in text:
        text = re.sub(r'(__NL__){2,}', '__NL__', text)
        text = re.sub(r'(__SL__){2,}', '__SL__', text)
    # [FIX2] <br /> HTML etiketlerini \\N'e çevir (AI'dan veya cache'den gelebilir)
    if '<br' in text.lower():
        text = re.sub(r'(?i)(<br\s*/?>\s*)+', r'\\N', text)
    # Placeholder'ları geri yükle
    for original, placeholder in _ASS_SPECIAL_CHARS:
        if placeholder in text:
            text = text.replace(placeholder, original)
    # [FIX] Çift/üçlü \\N kalıplarını tek \\N'e indir (kaynak veya AI kaynaklı)
    if '\\N\\N' in text:
        text = re.sub(r'(\\N){2,}', r'\\N', text)
    return text

# ============================================
# KARAOKE TAG KORUMASI (\k \kf \ko \K)
# ============================================
# Karaoke tag'leri: {\k50}Kelime {\kf30}Kelime2 gibi yapılardır.
# \k = syllable timing, \kf = fill karaoke, \ko = outline karaoke, \K = sweep karaoke
# SORUN: Bu tag'ler __T0__ sistemiyle SADECE kapalı {} bloğu olarak korunuyor.
# Ama karaoke satırları birden fazla kelime-timing çifti içerir:
#   {\k50}Hel {\k40}lo {\k60}World
#   Her {} bloğu ayrı __T0__, __T1__, __T2__ olur → doğru çalışıyor.
# 
# Asıl sorun: Bu satırlar has_karaoke=True ile TAMAMEN ATLANIYOR!
# FIX: Karaoke timing tag'leri __T__ sistemiyle korunuyor (extract_tags_with_placeholders
# zaten bunu yapıyor), sadece skip mantığını değiştirmemiz gerekiyor.
#
# ÖZEL DURUM — {\k} tag'siz metin içindeki "inline karaoke":
# Bazen karaoke şöyle gelir: {\1c&H00FFFF&\k50}Hel{\k40}lo
# Burada ilk {} bloğu hem stil hem timing içeriyor. Bu da __T__ ile korunuyor.
#
# SONUÇ: extract_tags_with_placeholders zaten karaoke tag'lerini de kapsıyor.
# Sadece "karaoke satırlarını atla" kararını kaldırıp çeviri akışına bırakmak yeterli.
# Şarkı sözü (is_song_symbol ♪) veya song_style ise yine atlanır.

# Sansür tespiti: AI bazen küfürlü kelimeleri s*k, f**k, b*tch gibi maskeler
# Bu durum tespit edilince retry mekanizması tetiklenir
_CENSORED_PATTERN = re.compile(
    r'\b\w*\*+\w*\b',  # En az bir * içeren kelime: s*k, f**k, b*tch, a**hole
    re.IGNORECASE
)

def has_censored_content(text):
    """
    Çeviri sonucunda sansürlenmiş (yıldızlı) kelime var mı kontrol eder.
    Örnekler: s*k, f**k, b*tch, a**hole, şi* gibi kalıplar.
    Returns True → Sansür tespit edildi, retry gerekli.
    """
    if not text:
        return False
    # En az bir harf + en az bir * + opsiyonel harf içeren kelime
    matches = _CENSORED_PATTERN.findall(text)
    # Sadece * içeren kısa "kelimeler" (örn: "***" tek başına) da sansür sayılır
    return len(matches) > 0

def has_karaoke_tags(text):
    """
    Metinde karaoke timing tag'i var mi kontrol eder.
    Sadece gercek karaoke timing tag'leri:
      \\k50   = syllable timing
      \\kf30  = fill karaoke
      \\ko20  = outline karaoke
      \\K100  = sweep karaoke

    [FIX] Eski regex r'\\\\[Kkf]{1,2}o?\\d*' yanlistir:
      \\fk (font skew) ve \\b1 (bold) de eslesiyordu!
    Yeni regex: k harfiyle baslayan + opsiyonel f/o + zorunlu rakam
    veya buyuk K + zorunlu rakam. Boylece \\fk, \\b, \\fs gibi
    harflerle baslayan diger tagler hic eslesmiyor.

    NOT: Bu fonksiyon sadece tespit icin, skip karari vermez.
    Karaoke satirlari tag'ler korunarak cevriliyor.
    """
    # {\\k50}, {\\kf30}, {\\ko20}, {\\K100} eslesir
    # {\\fk}, {\\b1}, {\\fs40} ESLESMEZ (k/K ile baslayan sadece)
    return bool(re.search(r'\\k[fo]?\d+|\\K\d+', text))

# ============================================
# ROMAJI FILTRE (Kapsamli cumle duzeyinde)
# ============================================
try:
    from romaji_filter import is_romaji_sentence as _is_romaji_sentence_v2
    _ROMAJI_FILTER_LOADED = True
except ImportError:
    _is_romaji_sentence_v2 = None
    _ROMAJI_FILTER_LOADED = False

# ============================================
# ROMAJİ TESPİTİ (sadece Japonca şarkı sözlerini engelle)
# ============================================
# Japonca romaji kalıpları: "wa", "wo", "ga", "ni" gibi dilbilgisi ekleri
_ROMAJI_SUFFIXES = re.compile(
    r'\b(wa|wo|ga|ni|no|de|to|ka|na|mo|ya|ne|yo|sa|kara|made|demo|dake|'
    r'nomi|shika|ba|tara|tari|te|nde|ta|da|ru|ku|su|mu|nu|bu|gu|zu|'
    r'suru|shita|shite|shimau|shimatta|iru|ita|ite|iku|itta|itte|kuru|kita|kite|'
    r'miru|mita|mite|dekiru|dekita|naru|natta|natte|'
    r'mono|koto|toki|yori|hodo|gurai|bakari|noni|node|kedo|shi)\b',
    re.IGNORECASE
)

# İngilizce dilbilgisi kelimeleri — bunlar varsa cümle muhtemelen İngilizce
_ENG_GRAMMAR = {
    'the','be','of','and','a','in','that','have','it','for','not','on','with',
    'he','as','you','do','at','this','but','his','by','from','they','we','say',
    'her','she','or','an','will','my','one','all','would','there','their','what',
    'so','up','out','if','about','who','get','which','go','me','are','is','was',
    'were','okay','wait','how','too','make','time','come','see','look','just',
    'know','want','good','well','need','way','day','man','got','let','put','set',
    'run','try','him','its','here','when','then','them','than','very','been','has',
    'had','can','could','should','would','where','why','because','also','into',
    'after','before','over','between','through','take','said','like','some','than',
    'then','these','those','such','each','more','most','other','some','have','been'
}

# İngilizce ile romaji arasında çakışan kısa kelimeler — tek başına romaji kanıtı değil
_ROMAJI_OVERLAP = {
    'no','to','de','sa','ya','ta','mo','ka','na','ne','ba',
    'ru','ku','su','mu','nu','bu','gu','zu','da','te','shi'
}

# ─────────────────────────────────────────────────────────────────────────────
# [KRiTiK] ingilizce icerik tespiti — Her zaman cevir zamani
# ─────────────────────────────────────────────────────────────────────────────
def _is_english_content(text: str) -> bool:
    """
    Metin ingilizce mi? Evet ise -> KESINLIKLE CEVIR, hicbir skip kurali gecersiz.

    Kapsam: tabela, karaoke, sign, kisa satir, OP/ED sozu — farketmez.
    Romaji (Japonca transliterasyon) False, gercek ingilizce True doner.

    Algoritma:
      1. Bos / cok kisa → False
      2. Turkce ozel karakter (g-breve, s-cedilla vb.) varsa → kesin TR → False
      3. Yalnizca muzik sembolu (musika notasi ~) → False
      4. Romaji filter → Japonca ise False
      5. Anime isim filtresinden gecmiyor (tum kelime isim) → False
      6. content_detector freq analizi → romaji ise False
      7. TR frekans DB: kelime cogunlugu Turkce → False (zaten cevrilmis)
      8. ASCII alfabetik karakter orani >= %85 → Ingilizce → True
    """
    if not text:
        return False
    # Placeholder kalintilari temizle
    clean = re.sub(r'__[A-Za-z0-9]+__', '', text).strip()
    # Sadece sembol/muzik notu → Ingilizce degil
    if not re.search(r'[a-zA-Z]', clean):
        return False

    # ── [1] TURK'CE OZEL KARAKTER ERKEN CIKIS (EN ONEMLI) ────────────────────
    # Metnin herhangi bir yerinde Turkce ozel harf varsa → kesinlikle Turkce → False
    # Bu kontrolun en basta olmasi zorunlu — diger tum kontroller ondan once firlamakta
    _TR_CHARS_SET = frozenset('\u011f\u015f\xe7\xf6\xfc\u0131\u0130\u011e\u015e\xc7\xd6\xdc')
    if any(c in _TR_CHARS_SET for c in clean):
        return False

    # Cok kisa (1-2 karakter) → belirsiz
    alpha_chars = re.findall(r'[a-zA-Z]', clean)
    if len(alpha_chars) < 3:
        return False
    # Romaji filtresi: Romaji ise Ingilizce degil
    try:
        if is_romaji_text(clean):
            return False
    except Exception:
        pass
    # Melodic filler (la la la, na na na) → Japonca sarki dolgusu
    _words_only = re.findall(r'[a-z]+', clean.lower())
    _MELODIC = {'la', 'na', 'da', 'ra', 'ya', 'wa', 'ha', 'ba', 'pa', 'ta', 'ka', 'ga', 'sa', 'ma'}
    if _words_only and all(w in _MELODIC for w in _words_only):
        return False

    # ── Anime Karakter Ismi Kontrolu ─────────────────────────────────────────
    # Cumlenin TUMU sadece anime isimleri ise → proper noun → ceviri gerekmez.
    # Ama anime ismi + Ingilizce kelime varsa → gercek diyalog → True.
    try:
        from content_detector import is_anime_name as _is_aname
        _aw = re.findall(r"[a-zA-Z']+", clean)
        if _aw:
            _anime_hits = sum(1 for _aw_w in _aw if _is_aname(_aw_w))
            if _anime_hits == len(_aw):  # Tum kelimeler anime ismi → False
                return False
    except Exception:
        pass

    # ── content_detector Frekans Tabanli Kontrol ─────────────────────────────
    # score_text_romaji: > 0.70 → Romaji/JP (atla)
    # NOT: < 0.10 → True kismini KALDIRDIK — TR kelimeleri de dusuk romaji skoruna sahip
    try:
        from content_detector import score_text_romaji as _srom
        _rom_score, _rom_reason = _srom(clean)
        if _rom_score > 0.70:
            return False  # Romaji/Japonca, cevirme
    except Exception:
        pass

    # ── Turkce Frekans Kontrolu ──────────────────────────────────────────────
    # Eger kelimelerin cogunlugu GERCEKTEN Turkce ise → zaten cevrilmis.
    # KURAL: Yalnizca TR DB'de yuksek FAKAT EN DB'de DUSUK frekanslı kelimeler sayilir.
    # Bu sayede "game", "over", "look" gibi iki listede de olan kelimeler atlanir.
    _TR_EXCLUSIVE_SHORT = frozenset({
        # Saf Turkce, Ingilizce dictionary'sinde kesinlikle olmayan kisalar
        'bir','bu','ne','ve','da','mi','ki','ben','sen','biz','siz','onlar',
        'evet','hayir','tamam','ama','ile','icin','gibi','daha','cok',
        'var','yok','git','gel','dur','bak','bil','yap','sor','ver',
        'neden','nasil','nerede','nereye','simdi','sonra','once',
        'hadi','evet','tamam','belki','zaten','artik','sadece',
    })
    try:
        from content_detector import _tr_freq_score as _trf, _en_freq_score as _enf
        _all_words = re.findall(r"[a-zA-Z]+", clean)
        if _all_words:
            _tr_hits = 0
            for _w in _all_words:
                _wl = _w.lower()
                # Saf Turkce kisa kelimeler → kesin TR (Ingilizce'de bu anlamda kullanilmaz)
                if _wl in _TR_EXCLUSIVE_SHORT:
                    _tr_hits += 1
                # Uzun kelimeler: TR frekansi yuksek VE EN frekansi dusuk ise TR
                elif len(_w) >= 4:
                    _trs = _trf(_w)
                    _ens = _enf(_w)
                    # TR frekansi yuksek + EN frekansi yoksa veya cok dusuksa → TR kelimesi
                    if _trs >= 0.50 and _ens < 0.25:
                        _tr_hits += 1
            _tr_ratio = _tr_hits / len(_all_words)
            if _tr_ratio >= 0.40:  # Kelimelerin %40+ kesin Turkce → zaten cevrilmis
                return False
    except Exception:
        pass

    # ASCII alfabetik orani: %85+ ise Ingilizce
    total_alpha = sum(1 for c in clean if c.isalpha())
    ascii_alpha = sum(1 for c in clean if c.isascii() and c.isalpha())
    if total_alpha == 0:
        return False
    return (ascii_alpha / total_alpha) >= 0.85


def is_romaji_text(text):
    """
    Metnin Japonca romaji (sarkısozu, vb.) olup olmadigini tespit eder.
    Returns True  -> Romaji (atlanmali)
    Returns False -> Ingilizce veya baska -> CEVIR

    Strateji:
    1. 8+ kelime     -> asla romaji, cevir
    2. <3 kelime     -> belirsiz, cevir
    3. Ingilizce gram. kelimesi -> Ingilizce, cevir
    4. Guclu (3+harf) romaji ekleri yogunsa -> Romaji
    5. Guclu romaji + yuksek toplam yogunluk -> Romaji
    6. Japonca'ya has (non-English, non-overlap) kelimeler varsa -> Romaji
    """
    if not text or not text.strip():
        return False

    # === KAPSAMLI ROMAJI FILTRE (romaji_filter.py) ===
    # Cumle duzeyinde, 600+ sozluk + hece analizi ile calisir
    if _ROMAJI_FILTER_LOADED:
        return _is_romaji_sentence_v2(text)
    # === GERI DONUS: eski kelime tabanli mantik ===

    words = re.findall(r'[a-zA-Z]+', text.lower())
    if not words:
        return False

    # Kural 1: Uzun İngilizce cümle
    if len(words) >= 8:
        return False

    # Kural 2: Çok kısa
    if len(words) < 3:
        return False

    # Kural 3: İngilizce dilbilgisi kelimesi varsa → İngilizce cümle
    # "Ta... Take... ya!" → 'take' İngilizce'de var → False (çevir)
    # Dikkat: 'take' elin almasında "ta-ke" okunur ama İngilizce'de de kelime
    eng_count = sum(1 for w in words if w in _ENG_GRAMMAR)
    if eng_count >= 1:
        return False

    # Romaji eki eşleşmeleri
    romaji_matches = _ROMAJI_SUFFIXES.findall(text.lower())
    if not romaji_matches:
        return False

    total_ratio = len(romaji_matches) / max(len(words), 1)
    strong_romaji = [m for m in romaji_matches if len(m) >= 3 and m not in _ROMAJI_OVERLAP]
    strong_ratio = len(strong_romaji) / max(len(words), 1)

    # Kural 4: Güçlü (3+ harf) romaji ekleri yoğun → Japonca
    # Kural 5: Güçlü romaji VAR + toplam yoğunluk yüksek → Japonca
    # "kore wa nan desu ka": kore/nan/desu (strong) + wa/ka (overlap) → total=5/5=1.0
    if len(strong_romaji) >= 1 and total_ratio >= 0.50:
        return True

    # Kural 6: Japonca'ya özgü kelimeler (ne İngilizce ne overlap)
    # "suki da yo kimi no koto" → suki, kimi, koto İngilizce değil
    jp_specific = [w for w in words
                   if w not in _ENG_GRAMMAR
                   and w not in _ROMAJI_OVERLAP
                   and len(w) >= 3]
    if len(jp_specific) >= 1 and total_ratio >= 0.40:
        return True

    return False


def clean_brackets(text):
    # Remove content within () or [] if it contains Japanese or seems like meta info
    # 1. Remove standard JP parentheticals
    text = JP_PATTERN_NORMAL.sub('', text)
    text = JP_PATTERN_FULL.sub('', text)

    # 2. General Bracket Cleaner for comments (heuristic)
    # Strip [...] totally as it's usually meta/sound effects not needed or JP comments.
    text = re.sub(r'\[.*?\]', '', text)

    # 3. Strip parentheses containing credit keywords
    for kw in CREDIT_KEYWORDS:
        text = re.sub(r'\([^)]*?' + re.escape(kw) + r'.*?\)', '', text, flags=re.IGNORECASE)

    # 4. Clean extra spaces
    text = " ".join(text.split())
    return text

def is_credit_line(text: str, style_name: str = "", has_pos: bool = False,
                   word_count: int = 0, **kwargs) -> bool:
    """
    Kredi satiri tespit mekanizmasi DEVRE DISI.
    Yanlis pozitif (false-positive) nedeniyle kaldirildi.
    Her satir cevirilecek, hicbir sey silinmeyecek.
    """
    return False

def parse_ass_time(time_str):
    """ASS zaman formatını (h:mm:ss.cs) saniyeye çevirir"""
    try:
        parts = time_str.split(':')
        h = int(parts[0])
        m = int(parts[1])
        s = float(parts[2])
        return h * 3600 + m * 60 + s
    except:
        return 0.0

def format_ass_time(seconds):
    """Saniyeyi ASS zaman formatına (h:mm:ss.cs) çevirir"""
    try:
        h = int(seconds // 3600)
        rem = seconds % 3600
        m = int(rem // 60)
        s = rem % 60
        return f"{h}:{m:02d}:{s:05.2f}"
    except:
        return "0:00:00.00"

def convert_srt_vtt_to_ass(lines, is_vtt=False):
    """
    SRT veya VTT formatındaki altyazıları ASS formatına çevirir.
    Returns: ASS format lines (list)
    """
    try:
        # ASS Header oluştur
        ass_lines = [
            "[Script Info]",
            "Title: Converted Subtitle",
            "ScriptType: v4.00+",
            "WrapStyle: 0",
            "PlayResX: 1920",
            "PlayResY: 1080",
            "ScaledBorderAndShadow: yes",
            "",
            "[V4+ Styles]",
            "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
            "Style: Default,Arial,80,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,2,2,2,10,10,10,1",
            "",
            "[Events]",
            "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text"
        ]
        
        # SRT/VTT parse et
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            
            # VTT header'ı atla
            if line.upper().startswith('WEBVTT') or line.upper().startswith('NOTE'):
                i += 1
                continue
            
            # Boş satırları atla
            if not line:
                i += 1
                continue
            
            # Sayı satırını atla (SRT için)
            if line.isdigit():
                i += 1
                if i >= len(lines):
                    break
                line = lines[i].strip()
            
            # Zaman satırını bul
            if '-->' in line:
                # Zamanları parse et
                time_parts = line.split('-->')
                if len(time_parts) != 2:
                    i += 1
                    continue
                
                start_time = time_parts[0].strip()
                end_time = time_parts[1].strip().split()[0]  # VTT'de position bilgisi olabilir
                
                # SRT/VTT formatını ASS formatına çevir
                def convert_time_to_ass(time_str):
                    """
                    SRT: 00:00:19,102 veya VTT: 00:00:19.102
                    ASS: 0:00:19.10
                    """
                    # Virgülü noktaya çevir (SRT için)
                    time_str = time_str.replace(',', '.')
                    
                    # Zamanı parçala: HH:MM:SS.mmm
                    try:
                        if '.' in time_str:
                            time_part, ms_part = time_str.split('.')
                        else:
                            time_part = time_str
                            ms_part = '00'
                        
                        # HH:MM:SS'i parçala
                        parts = time_part.split(':')
                        if len(parts) == 3:
                            h, m, s = parts
                        elif len(parts) == 2:
                            h = '0'
                            m, s = parts
                        else:
                            return time_str
                        
                        # Milisaniyeyi 2 haneye düşür (ASS formatı)
                        ms_part = ms_part[:2].ljust(2, '0')
                        
                        # Saat kısmındaki gereksiz sıfırları kaldır
                        h = str(int(h))
                        
                        # ASS formatı: h:mm:ss.cs (centiseconds)
                        return f"{h}:{m}:{s}.{ms_part}"
                    except:
                        return time_str
                
                start_time = convert_time_to_ass(start_time)
                end_time = convert_time_to_ass(end_time)
                
                # Metin satırlarını topla
                i += 1
                text_lines = []
                while i < len(lines) and lines[i].strip() and '-->' not in lines[i]:
                    # Sayı satırını atla (bazen metin içinde numara olabilir)
                    if not lines[i].strip().isdigit():
                        text_lines.append(lines[i].strip())
                    i += 1
                
                if text_lines:
                    # Metni birleştir (\N ile)
                    text = '\\N'.join(text_lines)
                    
                    # <br> / <br /> taglarını ASS \N satır sonuna çevir (silme!)
                    text = re.sub(r'<br\s*/?>', r'\\N', text, flags=re.IGNORECASE)
                    # Art arda \N\N → tek \N
                    text = re.sub(r'(\\N){2,}', r'\\N', text)
                    # Kalan diger HTML taglerini temizle (<i>, <b>, <u> vs.)
                    text = re.sub(r'<(?!br)[^>]+>', '', text)
                    
                    # ASS dialogue satırı oluştur
                    dialogue = f"Dialogue: 0,{start_time},{end_time},Default,,0,0,0,,{text}"
                    ass_lines.append(dialogue)
            else:
                i += 1
        
        return ass_lines
        
    except Exception as e:
        print(f"{Fore.RED}   [!] Format dönüşüm hatası: {e}{Style.RESET_ALL}")
        return None

def process_and_replace_subtitle(filepath, prefs, translator=None, output_path=None, time_offset=0.0):
    print(f"{Fore.CYAN}[*] Altyazı işleniyor...{Style.RESET_ALL}")
    # [ANTI-SPAM] Her yeni dosya için kredi ve skip log state'ini sıfırla
    process_and_replace_subtitle._credit_seen = set()
    process_and_replace_subtitle._credit_counts = {}
    process_and_replace_subtitle._skip_seen = set()
    process_and_replace_subtitle._banner_seen = set()  # [Fix Asama 3] Her dosyada sifirla
    # ── Kalite Raporu Başlat ────────────────────────────────────────
    from translation_report import start_report, get_report
    _report = start_report(filepath)
    _report_start_time = __import__("time").time()
    
    if not output_path:
        output_path = filepath
    
    try:
        # ============================================
        # [pysubs2] FORMAT DETECTION & ASS PARSE
        # ============================================
        # SRT/VTT için ham içerik okuma (format tespiti gerekli)
        content = ""
        encoding_used = "unknown"
        try:
            with open(filepath, 'r', encoding='utf_8_sig') as f:
                content = f.read()
            encoding_used = "utf_8_sig"
        except:
            try:
                with open(filepath, 'r', encoding='utf-16') as f:
                    content = f.read()
                encoding_used = "utf-16"
            except:
                with open(filepath, 'r', encoding='latin-1') as f:
                    content = f.read()
                encoding_used = "latin-1"

        lines = content.splitlines()

        # SRT/VTT Format Kontrolü ve ASS'e Dönüştürme
        is_srt_format = False
        is_vtt_format = False
        if len(lines) > 3:
            for i in range(min(10, len(lines))):
                line_chk = lines[i].strip()
                if '-->' in line_chk and ',' in line_chk:
                    is_srt_format = True; break
                if line_chk.upper().startswith('WEBVTT') or ('-->' in line_chk and '.' in line_chk and ',' not in line_chk):
                    is_vtt_format = True; break

        if is_srt_format or is_vtt_format:
            fmt_name = "SRT" if is_srt_format else "VTT"
            print(f"{Fore.YELLOW}   [*] {fmt_name} formatı algılandı, ASS'e dönüştürülüyor...{Style.RESET_ALL}")
            lines = convert_srt_vtt_to_ass(lines, is_vtt=is_vtt_format)
            if not lines:
                print(f"{Fore.RED}   [!] Format dönüşümü başarısız!{Style.RESET_ALL}")
                return None
            # Geçici dosyaya yaz, pysubs2 ile yeniden yükle
            import tempfile, os as _os
            _tmp = tempfile.NamedTemporaryFile(suffix='.ass', mode='w', encoding='utf-8-sig', delete=False)
            _tmp.write('\n'.join(lines))
            _tmp.close()
            filepath = _tmp.name
            print(f"{Fore.GREEN}   [OK] ASS formatına dönüştürüldü.{Style.RESET_ALL}")

        # ============================================
        # [pysubs2] DOSYA PARSE — split(',', 9) KALDIRILDI
        # ============================================
        font_size_mode   = prefs.get('font_size_mode', 'preserve')
        custom_font_size = prefs.get('custom_font_size', 80)

        try:
            from ass_file_reader import build_structured_events_pysubs2
            (
                _ass_reader,
                _raw_lines,
                header,
                styles,
                events,
                _pysubs2_parts_list,
                idx_style,
                idx_name,
                idx_text,
                format_line_string,
                encoding_used,
            ) = build_structured_events_pysubs2(filepath, font_size_mode, custom_font_size)
            _using_pysubs2 = True

            # ══════════════════════════════════════════════════════
            # PRE-PROCESS: Karaoke Collapse
            # pysubs2 event listesi structured_events'e dönüştürülmeden
            # ÖNCE: İngilizce kara eventleri birleştir, stillerini
            # Default'a evrilt, böylece satır sayısı bozulmaz.
            # ══════════════════════════════════════════════════════
            if prefs.get('translate', True):
                _kara_pre_count = _preprocess_collapse_karaoke(_ass_reader._subs)
                if _kara_pre_count > 0:
                    print(f"{Fore.MAGENTA}   [KaraPre] {_kara_pre_count} kara satir pre-collapse edildi{Style.RESET_ALL}")
            # ══════════════════════════════════════════════════════


            try:
                from ass_file_reader import validate_script_info as _vsinfo
                _si_result = _vsinfo(_ass_reader)
                if _si_result['errors']:
                    for _err in _si_result['errors']:
                        print(f"{Fore.RED}   [ScriptInfo] HATA: {_err}{Style.RESET_ALL}")
                if _si_result['warnings']:
                    for _wrn in _si_result['warnings']:
                        print(f"{Fore.YELLOW}   [ScriptInfo] Uyari: {_wrn}{Style.RESET_ALL}")
                # WrapStyle=2 → auto_split bu dosyada devre dışı bırakılmalı
                _wrap = _si_result['info_snapshot'].get('WrapStyle', '')
                if str(_wrap).strip() == '2':
                    prefs = dict(prefs)           # Mevcut prefs'i bozmadan kopy
                    prefs['_no_auto_split'] = True # pipeline içi sinyal
                    print(f"{Fore.CYAN}   [ScriptInfo] WrapStyle=2: auto_split bypass aktif{Style.RESET_ALL}")
                # PlayRes bilgisini signed events için sakla
                _play_x = int(_si_result['info_snapshot'].get('PlayResX') or 1280)
                _play_y = int(_si_result['info_snapshot'].get('PlayResY') or 720)
            except Exception as _sie:
                _play_x, _play_y = 1280, 720   # Varsayilan
            # ────────────────────────────────────────────────────────────────

        except Exception as _pe:
            # Fallback: eski split(',', 9) mantığı
            print(f"{Fore.YELLOW}   [!] pysubs2 parse hatasi, fallback aktif: {_pe}{Style.RESET_ALL}")
            _using_pysubs2 = False
            _ass_reader = None
            _play_x, _play_y = 1280, 720  # [Fix] Fallback icin de tanimla

        if not _using_pysubs2:
            # ── ESKI FALLBACK (kırılgan ama yedek) ───────────────────────
            header = []; styles = []; events = []
            section = "header"
            for line in lines:
                line_l = line.strip().lower()
                if line_l == "[script info]": section = "header"; header.append(line); continue
                elif line_l in ("[v4+ styles]", "[styles]"): section = "styles"; styles.append(line); continue
                elif line_l == "[events]": section = "events"; events.append(line); continue
                if section == "header": header.append(line)
                elif section == "styles": styles.append(line)
                elif section == "events": events.append(line)
            events_start_index = next((i for i, l in enumerate(lines) if l.strip().lower() == "[events]"), -1)
            format_line_index = -1; format_definition = []; format_line_string = ""
            for i, line in enumerate(lines):
                if events_start_index != -1 and i > events_start_index and re.match(r'^format\s*:', line.strip().lower()):
                    format_line_index = i
                    parts_f = line.split(':', 1)[1].strip().split(',')
                    format_definition = [p.strip().lower() for p in parts_f]
                    format_line_string = line; break
            if events_start_index == -1 or format_line_index == -1:
                print(f"{Fore.RED}   [!] Format satırı anlaşılamadı.{Style.RESET_ALL}"); return
            try:
                idx_style = format_definition.index("style")
                idx_name  = format_definition.index("name") if "name" in format_definition else -1
                idx_text  = format_definition.index("text")
            except ValueError: return
        # ── ESKI FALLBACK SONU ────────────────────────────────────────────

        # Translator initialization
        translation_cache = load_translation_cache()
        if prefs['translate']:
            if translator is None:
                model_name  = prefs.get('ai_model', 'google/gemini-2.0-flash-001')
                nsfw_on     = prefs.get('nsfw_mode', False)
                simple_mode = prefs.get('simple_mode', True)
                translator  = SubtitleTranslator(model_name=model_name, nsfw_enabled=nsfw_on, simple_mode=simple_mode)
            force_translate = prefs.get('force_translate', False)
            translator.config['ignore_cache'] = force_translate
            if force_translate:
                print(f"{Fore.YELLOW}   [ZORLA ÇEVİR] Cache devre dışı - Her satır yeniden çevrilecek{Style.RESET_ALL}")
                try:
                    from notif_bus import push_notif as _pn
                    _pn('Zorla Cevir: cache devre disi - her satir yeniden cevriliyor', 'warning')
                except Exception: pass

            # ── HStream İndirici Modu ─────────────────────────────────────────
            # prefs['hstream_mode'] = True ise translator'da prompt şişmesi önleme:
            # additional_context (deyim taraması), use_glossary (200+ sözlük) ve
            # sliding_window (önceki video bağlamı) devre dışı bırakılır.
            if prefs.get('hstream_mode', False):
                try:
                    translator.set_hstream_mode(True)
                    print(f"{Fore.CYAN}   [HStream] Prompt optimizasyonu aktif — gereksiz bağlam verileri devre dışı{Style.RESET_ALL}")
                except Exception as _hm_err:
                    print(f"{Fore.YELLOW}   [HStream] set_hstream_mode hatası: {_hm_err}{Style.RESET_ALL}")
            # ─────────────────────────────────────────────────────────────────

        structured_events = []
        total_dialogues   = 0

        # ── Event Kaynak Seçimi ───────────────────────────────────────────
        # pysubs2 varsa _pysubs2_parts_list kullan (güvenli)
        # yoksa fallback: events[1:] ile eski split mantığı
        if _using_pysubs2:
            _event_source = _pysubs2_parts_list   # [{parts, line, is_comment_event, _ev}, ...]
        else:
            # Fallback için eski format: satır listesinden dict üret
            _event_source = []
            for _line in events[1:]:
                if not _line.strip(): continue
                if re.match(r'^format\s*:', _line.strip().lower()): continue
                _p = _line.split(',', 9)
                if len(_p) < 10: continue
                _event_source.append({'parts': _p, 'line': _line, 'is_comment_event': False})

        for _ev_item in _event_source:
            parts    = _ev_item['parts']
            line     = _ev_item['line']
            # Comment satirlari — akilli filtre:
            # lead-in / lead-out / efekt Comment'leri gec, ama
            # actor='' ve Ingilizce metin iceren "referans" Comment'leri cevir
            if _ev_item.get('is_comment_event', False):
                _c_ev  = _ev_item.get('_ev')
                _actor = (_c_ev.name if _c_ev else '').strip() if _c_ev else parts[idx_name].strip()
                _eff   = (_c_ev.effect if _c_ev else '').strip() if _c_ev else parts[8].strip() if len(parts) > 8 else ''
                _ctxt  = re.sub(r'\{[^}]*\}', '', parts[9]).replace('\\N',' ').strip() if len(parts) > 9 else ''

                # Kesinlikle atla: actor varsa (lead-in/lead-out/Effector), efekt varsa, koordinat datasi varsa
                _skip_comment = (
                    bool(_actor) or
                    bool(_eff) or
                    bool(re.match(r'^[ml]\s+[-\d]', _ctxt)) or  # vektor/koordinat
                    len(_ctxt) < 3 or
                    not re.search(r'[a-zA-Z]{3,}', _ctxt)       # harf icermiyor → sembol/bos
                )
                if _skip_comment:
                    continue
                # Buraya geldiyse: actor='', efekt yok, Ingilizce metin var → cevrilmeli
                # Dialogue gibi isleme devam et
            if len(parts) < 10: continue

            style_name = parts[idx_style].strip()
            actor_name = parts[idx_name].strip() if idx_name >= 0 else ""
            raw_text   = parts[9].strip()

            # ── [ERKEN ÇIKIŞ — BLOK 0] High Layer + CJK dominant ───────────────
            # A) Layer >= 100 → drawing/mask katmanı (ass_content_classifier A12)
            #    Normal diyalog: 0-5, Typeset: 10-50, Drawing mask: 100+
            try:
                _layer_num = int(parts[0].strip()) if parts[0].strip().isdigit() else 0
            except (ValueError, IndexError):
                _layer_num = 0
            if _layer_num >= 100:
                _raw_no_tag = re.sub(r'\{[^}]*\}', '', raw_text).strip()
                if len(_raw_no_tag) == 0 or len(_raw_no_tag) <= 3:
                    structured_events.append({
                        "line": line, "parts": parts, "text": raw_text,
                        "type": "dialogue", "skip_translation": True,
                        "reason": f"high_layer_drawing_{_layer_num}",
                        "_pysubs2_ev": _ev_item.get('_ev'),
                    })
                    continue
            # ─────────────────────────────────────────────────────────────────────

            # ── [ERKEN ÇIKIŞ — BLOK 1] \\p1/\\p2+ Çizim Modu = çeviriye GİRMEZ ──
            # {\p1}m 0 0 l 100 100 b ... → pure vector drawing, metin yok
            # {\p0} ile kapatılmış olsa bile çizim verisi çevrilmez.
            if re.search(r'\\p[1-9]\b', raw_text):
                structured_events.append({
                    "line": line, "parts": parts, "text": raw_text,
                    "type": "dialogue", "skip_translation": True,
                    "reason": "drawing_mode_p1",
                    "_pysubs2_ev": _ev_item.get('_ev'),
                })
                continue

            # ── [ERKEN ÇIKIŞ — BLOK 2] \\clip/\\iclip(m...) + typeset junk ───
            # OP/ED logo satırları: her harf/segment ayrı event, vektör kırpma
            # uygulanır. İki senaryo:
            #   A) {bigTag\clip(m)}l{colorTag}   → ec='l'       → len<=2
            #   B) {bigTag\clip(m)}l{c}l{c}l...  → ec='llll...' → tek unique char
            # Gerçek tabela: "Blade Throw", "Track" → unique_chars > 1 → GEÇİLİR.
            # \iclip(m ...) = ters vektör kırpma, aynı mantık.
            if re.search(r'\\i?clip\(m\s', raw_text):
                _ec = re.sub(r'\{[^}]*\}', '', raw_text)   # kapalı tag'ler
                _ec = re.sub(r'\{[^}]*$',  '', _ec)         # kapanmamış tag
                _ec = _ec.strip()
                _ec_unique = len(set(_ec.lower().replace(' ', '')))
                _is_typeset_junk = (
                    len(_ec) == 0 or          # tamamen boş
                    len(_ec) <= 2 or          # tek harf (A: 'l', 'E', 'I')
                    _ec_unique <= 1           # tek harf tekrarı (B: 'lllll...')
                )
                if _is_typeset_junk:
                    structured_events.append({
                        "line": line, "parts": parts, "text": raw_text,
                        "type": "dialogue", "skip_translation": True,
                        "reason": "vector_clip_typeset_junk",
                        "_pysubs2_ev": _ev_item.get('_ev'),
                    })
                    continue
            # ─────────────────────────────────────────────────────────────────────

            # ── [ERKEN ÇIKIŞ — BLOK 3] ass_tag_reference kapsamlı junk kontrolü ─
            # is_vector_clip_junk'un yeni senaryoları (D: title_typeset, E: midword)
            # + invisible_alpha burada da yakalanır.
            if _ATR_AVAILABLE:
                _atr_junk, _atr_reason = _atr_is_clip_junk(raw_text)
                if _atr_junk:
                    structured_events.append({
                        "line": line, "parts": parts, "text": raw_text,
                        "type": "dialogue", "skip_translation": True,
                        "reason": f"atr_{_atr_reason}",
                        "_pysubs2_ev": _ev_item.get('_ev'),
                    })
                    continue

            # ── [ERKEN ÇIKIŞ — BLOK 4] Invisible Alpha = görsel yok, çevirme ────
            # \1a&HFF& veya \alpha&HFF& → primary kanal tam saydam → maskeleme katmanı
            # Glow/blur efekti için kullanılır, gerçek metin değil.
            # Kaynak: ass_content_classifier.py A9 kuralı
            if re.search(r'\\(?:1a|alpha)&H(?:FF|ff)&?', raw_text):
                _has_visible_outline = bool(re.search(r'\\[34]a&H[0-7][0-9A-Fa-f]', raw_text, re.IGNORECASE))
                if not _has_visible_outline:
                    structured_events.append({
                        "line": line, "parts": parts, "text": raw_text,
                        "type": "dialogue", "skip_translation": True,
                        "reason": "invisible_alpha_mask",
                        "_pysubs2_ev": _ev_item.get('_ev'),
                    })
                    continue
            # ─────────────────────────────────────────────────────────────────────

            # --- CLEANING LOGIC ---

            # ... (rest of filtering logic)
            # Actually tags are {}, we want to strip () and [].
            # Be careful: \pos(x,y) uses parens! We must NOT strip position parens.
            # Our clean_brackets func works on text, but regex might catch \pos(..).
            # Solution: Extract tags FIRST, then clean text, then process.
            
            # [FIX] Placeholder sistemi: tag'ler orijinal konumlarında korunur
            placeholder_text, tag_map = extract_tags_with_placeholders(raw_text)
            # Geriye dönük uyumluluk için tags_list de doldur (junk detection için)
            _, tags_list = extract_tags(raw_text)
            clean_text_no_tags = re.sub(r'__T\d+__', '', placeholder_text).strip()
            
            # [FIX] Filter out non-command tags (e.g. {Comment} or {Kanji})
            # ASS tags MUST contain '\' to be functional commands (e.g. {\pos...}).
            # If it doesn't have '\', it's a comment or garbage -> discard it.
            # [NEW] Font size handling for inline tags based on user preferences
            # Three modes: preserve (keep original), normalize (min 80), custom (set specific size)
            font_size_mode = prefs.get('font_size_mode', 'preserve')
            custom_font_size = prefs.get('custom_font_size', 80)
            
            normalized_tags = []
            for tag in tags_list:
                if "\\" in tag:
                    # Handle \fs## (font size) tags based on mode
                    if font_size_mode == 'preserve':
                        # Keep original font sizes - no modification
                        pass
                    elif font_size_mode == 'normalize':
                        # Normalize \\fs## (font size) tags - increase if too small
                        def normalize_font_size(match):
                            size = int(match.group(1))
                            # If font is too small (< 80), set to standard size for TV viewing
                            if size < 80:
                                return r'\fs80'
                            return match.group(0)
                        tag = re.sub(r'\\fs(\d+)', normalize_font_size, tag)
                    elif font_size_mode == 'custom':
                        # Replace all font size tags with custom size
                        tag = re.sub(r'\\fs\d+', f'\\\\fs{custom_font_size}', tag)
                    
                    # Remove empty tags like {} or { }
                    tag_content = tag.strip()
                    if tag_content and tag_content not in ['{', '}', '{}', '{ }']:
                        normalized_tags.append(tag)
            tags_list = normalized_tags
            
            # Placeholder text: tag konumları korunmuş, sadece metin AI'ya gidecek
            # clean_text_no_tags: junk/digit/credit kontrolü için tag'siz saf metin
            # placeholder_text:   çeviri için kullanılacak (tag konumları __Tx__ olarak)
            cleaned_content = placeholder_text  # AI'ya placeholder'lı metin gidecek
            
            if prefs['clean_sub']:
                is_protected = prefs.get('protect_positioning', False)
                
                if not is_protected:
                    # Normal Cleaning
                    cleaned_content = clean_brackets(cleaned_content)
                    
                    # Check DELETE keywords (Styles/Actors)
                    style_lower = style_name.lower()
                    if any(x in style_lower for x in DELETE_KEYWORDS):
                        print(f"Deleting Line (Keyword): '{cleaned_content}' | Style: {style_name}")
                        continue # Skip this line completely (Sign/Logo etc)
                else:
                    # Protected Mode - Minimal Cleaning
                    # Only clean distinct junk like Japanese if needed, but for now KEEP brackets
                    # cleaned_content = clean_brackets(cleaned_content) # DISABLED
                    pass
                
                # [FIX] KREDİ/LİNK TEMİZLEME HER ZAMAN ÇALIŞMALI
                # protect_positioning=True olsa bile fansub kredileri, site linkleri SİLİNMELİ.
                # Kredi kontrolü için tag'siz temiz metin + orijinal ASS satırı birlikte gönderilir.
                if is_credit_line(clean_text_no_tags, raw_ass_line=raw_text):
                    # [ANTI-SPAM] Aynı içerik için sadece 1 kez log yaz
                    _fn = process_and_replace_subtitle
                    _credit_seen  = getattr(_fn, '_credit_seen',  set())
                    _credit_counts = getattr(_fn, '_credit_counts', {})
                    _key = clean_text_no_tags[:60]
                    _credit_counts[_key] = _credit_counts.get(_key, 0) + 1
                    if _key not in _credit_seen:
                        _credit_seen.add(_key)
                        print(f"Deleting Line (Credit): '{clean_text_no_tags[:80]}'")
                    _fn._credit_seen   = _credit_seen
                    _fn._credit_counts = _credit_counts
                    continue
                
                if not clean_text_no_tags.strip() and not tags_list:
                    continue  # Empty line


            # Check Heuristic Protection (Songs/Romaji)
            
            # [NEW] Vector Preservation & Junk Detection
            # Goal: Protect vector commands (m 0 0...) if mixed with text, but SKIP if line is pure junk.
            
            is_junk = False
            current_vectors = [] # Initialize early to avoid NameError
            
            # 1. FX ve Animasyon Koruması
            # [FIX] has_drawing_tag: \p1 = drawing START, \p0 = drawing END.
            # Sadece \p[1-9] varsa (yani sıfır değil, gerçekten çizim açıksa) kontrol et.
            # Ayrıca: tag bloğu içinde \p1 olması YETERLİ değil → metnin kendisinde
            # vektör komutu (m X Y / l X Y) da olmalı ki gerçekten çizim satırı sayılsın.
            # [ALF-FIX] ass_tag_parser tabanli drawing tespiti — regex fallback yerine kesin parse
            has_drawing_tag_raw = _alf_is_draw(raw_text) if _ALF_OK else bool(re.search(r'\\p[1-9]', raw_text))
            # [FIX v3] \\t( tag'i artik skip TETIKLEMEZ.
            # \\t() sadece renk/opaklık geçişidir — metin hala çevrilebilir.
            # Gerçek animasyon skip'i sadece per-char karaoke üzerinden yapılır.
            has_hard_animation = False
            # Metin kısmı (placeholder temizlenmiş, tag'siz saf metin) boş veya çok kısaysa → gerçek çizim satırı
            text_after_tags = clean_text_no_tags.strip()
            has_drawing_tag = has_drawing_tag_raw and (
                len(text_after_tags) == 0 or  # Tüm içerik tag'lerdeydi → junk
                bool(re.search(r'\b[mlb]\s+[\d.-]', text_after_tags))  # Vektör komutu var
            )
            
            # Effect sütunu doluysa FX satırı (parts[8])
            effect_field = parts[8].strip() if len(parts) > 8 else ""
            # [YENİ Aşama 1] Banner/Scroll efekti → kayan credits/staff roll → çevirme
            is_banner_scroll = _has_scroll_effect(effect_field)
            if is_banner_scroll:
                _fn = process_and_replace_subtitle
                _bs_seen = getattr(_fn, '_banner_seen', set())
                _bs_key  = f"BANNER:{style_name}"
                if _bs_key not in _bs_seen:
                    _bs_seen.add(_bs_key)
                    print(f"[Skip] Banner/Scroll efekti: credits satiri atlanıyor '{clean_text_no_tags[:40]}'")
                _fn._banner_seen = _bs_seen
                structured_events.append({
                    "line": line, "parts": parts,
                    "text": raw_text, "original_text": raw_text,
                    "type": "dialogue", "style": style_name,
                    "skip_translation": True, "reason": "banner/scroll_effect",
                    "actor": effect_field,
                    "effect": effect_field,
                    "_pysubs2_ev": _ev_item.get('_ev'),
                })
                continue
            # is_fx_line: Gercek ASS scroll/banner mi yoksa fansub editor notu mu?
            # CrappySubs gibi gruplar effect alanini '[term fix]', '[fix]' seklinde
            # editor notu olarak kullanir -- bunlar SCROLL/BANNER degil, ATLANMAMALI.
            # NOT: _EDIT_NOTE_RE module seviyesinde tanimlanmis (asagida / yukarda)
            _is_editor_note = bool(_EDIT_NOTE_RE_FX.match(effect_field.strip())) if effect_field else False
            is_fx_line = (
                effect_field != "" and
                effect_field.lower() != "none" and
                not _is_editor_note
            )
            
            # Ağır animasyon: aşırı tag/text oranı.
            # [FIX] Eşik 3.0'dan 6.0'a yükseltildi. Kısa diyaloglu ama birden fazla
            # stil tag'i olan satırlar (bold+italic+color = ~60 char tag, 10 char text)
            # yanlış junk sayılıyordu.
            tag_char_count = sum(len(tag) for tag in tags_list)
            text_char_count = len(cleaned_content.strip())
            is_tag_heavy_fx = text_char_count > 0 and (tag_char_count / text_char_count) > 12.0
            # FIX7: Editor notu ([term fix] vb.) ise tag-heavy bypass
            if _is_editor_note and is_tag_heavy_fx:
                is_tag_heavy_fx = False  # Editor notu = çevrilebilir
            # FIX2: Signs stilinde gercek metin (>=8 char) varsa tag-heavy bypass
            # is_signs_style: style adi 'sign' ile basliyor veya iceriyor
            is_signs_style = (
                style_name.lower().startswith('sign')
                or 'sign' in style_name.lower()
            )
            if is_signs_style and text_char_count >= 8 and is_tag_heavy_fx:
                is_tag_heavy_fx = False  # Signs + metin = cevirile


            # Per-hecel/per-karakter karaoke tespiti
            # Per-char:    __T0__O__T1__r__T2__i__   → ph ≈ char  (oran ~1.0)
            # Per-syllable: __T0__Wa__T1__ta__T2__shi → ph ≈ char/3 (oran ~0.33)
            # Normal diyalog: __T0__Full sentence      → ph << char
            # Oran eşiği: 1/3 → per-syllable karaoke yakalanır, normal dialog yakalanmaz.
            _ph_count = len(re.findall(r'__T\d+__', cleaned_content))
            # __NL__/__SL__/__HS__ da placeholder; bunları da çıkar ki gerçek char sayılsın
            _actual_chars = len(re.sub(r'__(?:T\d+|NL|SL|HS)__|\s', '', cleaned_content))
            is_per_char_karaoke = (
                _ph_count >= 2 and
                _actual_chars >= 4 and              # En az 4 gerçek karakter
                _ph_count >= (_actual_chars / 3)    # 1 tag / 3 char → per-syllable eşiği
            )

            # [COPYRIGHT-SKIP] Telif hakki bildirimi mi? Hicbir zaman cevirmek zorunda degiliz.
            if not is_junk:
                _raw_no_tags_strip = re.sub(r'{[^}]*}', '', raw_text).strip()
                if _COPYRIGHT_SKIP_RE.search(_raw_no_tags_strip):
                    is_junk = True
                    # [ANTI-SPAM] Copyright skip - sadece 1 kez logla
                    _fn2 = process_and_replace_subtitle
                    _cpr_seen = getattr(_fn2, '_cpr_seen', set())
                    _cpr_key = f"CPR:{_raw_no_tags_strip[:30]}"
                    if _cpr_key not in _cpr_seen:
                        _cpr_seen.add(_cpr_key)
                        print(f"[Skip] Copyright/telif satiri atlandi: '{_raw_no_tags_strip[:50]}'")
                    _fn2._cpr_seen = _cpr_seen

            # Regex for "m X Y", "l X Y", "b X Y" sequences common in ASS drawings
            vector_pattern = r'\b[mlb]\s+[\d\s.-]+'
            vector_matches = list(re.finditer(vector_pattern, cleaned_content))
            vector_len = sum(len(m.group(0)) for m in vector_matches)
            
            # 2. Check Ratio (Is it MOSTLY vector code?) or has drawing tag / FX
            if has_drawing_tag or is_fx_line or is_tag_heavy_fx or has_hard_animation or is_per_char_karaoke:
                 is_junk = True
                 _fn = process_and_replace_subtitle
                 _fx_key = "FX_ANY"  # Tüm FX türleri tek key altında → sadece 1 mesaj
                 _fx_seen = getattr(_fn, '_skip_seen', set())
                 if _fx_key not in _fx_seen:
                     _fx_seen.add(_fx_key)
                     print(f"[Skip] FX/karaoke satiri atlaniyor (fx={is_fx_line} draw={has_drawing_tag} anim={has_hard_animation}) -- tekrarlar bastirildi")
                 _fn._skip_seen = _fx_seen
                 
            elif vector_len > 0:
                if (vector_len / len(cleaned_content)) > 0.6: # Strict > 60% is Junk
                    is_junk = True
                    pass  # [ANTI-SPAM] Vector skip print kapatildi
                else:
                    # It's MIXED content (e.g. "Text m 0 0").
                    # PROTECT the vector parts by treating them as Tags!
                    
                    preserved_vectors = []
                    def mask_vector(match):
                        preserved_vectors.append(match.group(0))
                        return f" __VEC{len(preserved_vectors)-1}__ "
                    
                    cleaned_content = re.sub(vector_pattern, mask_vector, cleaned_content)
                    current_vectors = preserved_vectors

            # 3. Check for High Digit Density (> 50% numbers) - Only if not already junk
            if not is_junk:
                digit_count = sum(c.isdigit() for c in cleaned_content)
                # Be careful not to count our placeholders as junk
                text_len = len(cleaned_content)
                if text_len > 10 and (digit_count / text_len) > 0.6: # Increased threshold to 60%
                    is_junk = True
                    pass  # [ANTI-SPAM] Digit density print kapatildi
            
            if is_junk:
                 structured_events.append({
                    "line": line, # Orijinal satırı koru
                    "parts": parts,
                    "text": raw_text, 
                    "tags": tags_list if tags_list else [],
                    "vectors": current_vectors, 
                    "start": parts[1], "end": parts[2], "style": style_name, 
                    "original_text": raw_text,
                    "type": "dialogue", 
                    "skip_translation": True, 
                    "skip_reason": "junk/vector/fx",
                    "_pysubs2_ev": _ev_item.get('_ev'),  # [FIX] Song Pass icin
                })
                 continue
            
            # NOTE: If we masked vectors, 'cleaned_content' now has __VEC0__.
            # We need to restore them AFTER translation (handled in restore steps).

            # Check Heuristic Protection (Songs/Romaji)
            # Use original raw_text for pattern checks to see tags
            
            is_song_symbol = '♪' in raw_text or '♬' in raw_text
            # ... other checks ...
            
            # Simplified Logic for speed/readability in snippet:
            # Reconstruct logic from previous but optimized
            
            # [FIX] Stil adı kontrolü: Artık is_song_style_name() fonksiyonu kullanılıyor.
            # 'op' kelimesi 'OPa' stilinde yanlış eşleşmiyecek.
            is_song_style = is_song_style_name(style_name)
            # [FIX 2] Karaoke tespiti: \k, \K, \kf, \ko hepsini kapsar
            has_karaoke = has_karaoke_tags(raw_text)
            
            # [FIX] Konumlandırma Koruması
            # Sadece gerçekten "sadece grafik" olan kısa pos satırları atla.
            # Gerçek diyalog içerikli satırlar (4+ kelime) ASLA atlanmaz.
            # protect_positioning=True: hiçbir şey atlanmaz (tam koruma modu)
            has_position_tags = (
                r'\pos' in raw_text or
                r'\move' in raw_text or
                r'\org' in raw_text or
                r'\clip' in raw_text or
                r'\iclip' in raw_text
            )
            if has_position_tags and not prefs.get('protect_positioning', False):
                _pos_word_count = len(clean_text_no_tags.strip().split())
                _is_signs_style = style_name.lower().startswith('sign') or 'sign' in style_name.lower()
                # Kısa + Signs stili → grafik etiket, çevirme
                # [KRİTİK FIX] İngilizce tabela/yazı varsa → ÇEVİR (EXIT, OPEN, DANGER vb.)
                if _pos_word_count <= 3 and _is_signs_style:
                    _pos_txt = re.sub(r'__[A-Za-z0-9]+__', '', clean_text_no_tags).strip()
                    if _is_english_content(_pos_txt):
                        pass  # İngilizce → aşağıya devam, çevir
                    else:
                        structured_events.append({
                            "line": line,
                            "parts": parts,
                            "text": raw_text,
                            "type": "dialogue",
                            "skip_translation": True,
                            "reason": "position+short (grafik etiket)",
                            "_pysubs2_ev": _ev_item.get('_ev'),
                        })
                        continue
                # else: içerik var → ÇEVİR (aşağıya devam et)

            
            # Romaji / Kisa Satir Detect
            # [FIX] clean_word icin cleaned_content DEGIL clean_text_no_tags kullan.
            # cleaned_content icinde __T0__ gibi placeholder'lar var; bunlar \w karakteri
            # sayilir ve re.sub filtrelemez. Ornek: __T0__OK -> 'T0OK' -> whitelist'te yok
            # -> {\an8}OK yanlis skip ediliyordu! clean_text_no_tags saf metindir.
            clean_word = re.sub(r'[^\w]', '', clean_text_no_tags).lower()
            # [FIX] 1-2 karakter -> her zaman atla (anlamsiz, cevirmege gerek yok)
            is_very_short = 0 < len(clean_text_no_tags.strip()) <= 2
            is_english = clean_word in SHORT_ENGLISH_WHITELIST
            has_tags = len(tags_list) > 0
            
            # Konumlama tag'i var mı? (\pos, \move, \org)
            has_pos_tag = (r'\pos' in raw_text or r'\move' in raw_text or r'\org' in raw_text)
            
            # Skip Check Logic
            should_skip_translation = False
            skip_reason = ""
            
            matches_skip_criteria = (
                is_song_symbol or
                # [KRİTİK FIX] Karaoke + şarkı stili: sadece Romaji ise atla
                # İngilizce sarkı sözü ise (örn. "I'll find my way") → ÇEVİR
                (is_song_style and has_karaoke and not _is_english_content(clean_text_no_tags)) or
                (is_song_style and is_song_symbol) or
                is_very_short or
                (has_tags and len(clean_text_no_tags.strip()) <= 3 and not is_english)
            )
            
            # [STİL SONEK SİSTEMİ] ROM/JPN/KOR/CHN/CREDIT → atla | ENG/ALT → zorla çevir
            if not matches_skip_criteria:
                _style_beh = get_style_suffix_behavior(style_name)
                if _style_beh == 'skip':
                    # [KRİTİK FIX] Style suffix skip: içerik İNGiLiZCE ise gene de çevir
                    if _is_english_content(clean_text_no_tags):
                        pass  # İngilizce içerik, stil sonekine rağmen çevir
                    else:
                        matches_skip_criteria = True
                        # [ANTI-SPAM] Style suffix skip - ayni stil sadece 1 kez
                        _fn = process_and_replace_subtitle
                        _seen = getattr(_fn, '_skip_seen', set())
                        _sk = f"STYLE:{style_name}"
                        if _sk not in _seen:
                            _seen.add(_sk)
                            print(f"[Skip] Stil atlaniyor: '{style_name}' (ROM/JPN/KARA/vs)")
                        _fn._skip_seen = _seen
                elif _style_beh == 'translate' and is_song_style_name(style_name):
                    # ENG/EN şarkı stili → Phase 2 SongPass'e bırak, main pass geçme
                    # (ED1-EN, OP1-ENG, pre-collapse'dan gelen ED1-EN gibi stilleri kapsar)
                    matches_skip_criteria = True
                    skip_reason = "song_en_phase2"
                # Diğer 'translate' durumları: matches_skip_criteria False → normal çeviri

            # [ROMAJİ İÇERİK TESPİTİ]
            # Prefs'ten gelen bayraklar:
            #   skip_romaji_mode : False → romaji filtreyi tamamen kapat
            #   content_detect   : False → _cd_* (content_detector) kullanma
            #   force_no_style   : True  → stil adına bakma, hep icerik analizi yap
            _romaji_skip_enabled = prefs.get('romaji_block', True) if prefs else True
            _skip_romaji_mode    = prefs.get('skip_romaji_mode', True) if prefs else True
            _content_detect_on   = prefs.get('content_detect', True) if prefs else True
            _force_no_style      = prefs.get('force_no_style', False) if prefs else False

            # skip_romaji_mode kapalıysa romaji filtresi hiç çalışmaz
            _romaji_skip_enabled = _romaji_skip_enabled and _skip_romaji_mode

            if _romaji_skip_enabled and not matches_skip_criteria and clean_text_no_tags.strip():
                _is_song_st   = is_song_style_name(style_name)
                _style_beh2   = get_style_suffix_behavior(style_name)
                _is_skip_style = _is_song_st or (_style_beh2 == 'skip') or _force_no_style

                if _is_skip_style:
                    _text_for_romaji = re.sub(r'__T\d+__', '', clean_text_no_tags).strip()

                    # content_detector aktifse önce onu dene (daha güvenilir)
                    if _content_detect_on and _CONTENT_DETECTOR_OK:
                        _cd_action, _cd_conf, _ = _cd_classify_event(
                            _text_for_romaji, style_name
                        )
                        if _cd_action in ('skip_romaji', 'skip_karaoke_jp', 'skip_effect', 'skip_japanese'):
                            matches_skip_criteria = True
                    elif is_romaji_text(_text_for_romaji):
                        matches_skip_criteria = True

                    if matches_skip_criteria:
                        # [ANTI-SPAM] Romaji skip - aynı stil sadece 1 kez logla
                        _fn = process_and_replace_subtitle
                        _seen = getattr(_fn, '_skip_seen', set())
                        _rk = f"ROMAJI:{style_name}"
                        if _rk not in _seen:
                            _seen.add(_rk)
                            print(f"[Skip] Romaji/şarkı satırı atlanıyor: '{clean_text_no_tags[:30]}'")
                        _fn._skip_seen = _seen
                # Diyalog stili ve force_no_style=False → romaji kontrolü YOK → her zaman çeviri


            if matches_skip_criteria:
                should_skip_translation = True
                skip_reason = "song/karaoke/short"

            if should_skip_translation:
                 # Skip Translation, Keep Line
                 structured_events.append({
                    "line": line, # Use Original line
                    "parts": parts,
                    "text": raw_text,
                    "type": "dialogue",
                    "skip_translation": True,
                    "reason": skip_reason,
                    "_pysubs2_ev": _ev_item.get('_ev'),  # [FIX] Song Pass icin
                 })
                 continue

            # Add to list for translation
            # Important: We pass the CLEANED content (brackets removed) for translation.
            # But we must remember the TAGS to restore them later.
            
            structured_events.append({
                "line": line,
                "parts": parts,
                "text": cleaned_content, # Placeholder'lı metin (AI'ya gidecek)
                "tags": tags_list,       # Eski sisteme dönük uyum için
                "tag_map": tag_map,      # [NEW] Placeholder → orijinal tag haritası
                "vectors": current_vectors, # Preserved Vector Commands
                "original_text": raw_text, # Backup
                "type": "dialogue",
                "style": style_name,
                "is_sign": is_sign_style_name(style_name),  # [NEW] Signs tespiti
                "skip_translation": False,
                # [FIX KRİTİK] pysubs2 SSAEvent referansı — parts[9] ile ev.text
                # birbirinden bağımsız olduğu için (string copy) çeviriyi doğrudan
                # ev.text'e yazmak zorunlu. Aksi halde pysubs2.save() orijinali yazar!
                "_pysubs2_ev": _ev_item.get('_ev'),
                # [Asama 1 — YENİ]
                "actor": parts[4] if len(parts) > 4 else "",   # Karakter adı
                "effect": parts[8] if len(parts) > 8 else "",  # Banner/Scroll efekti
                "duration_ms": (_ass_time_to_ms(parts[2]) - _ass_time_to_ms(parts[1]))
                               if len(parts) > 2 and _VALIDATOR_AVAILABLE else 0,
            })
            total_dialogues += 1

            # ── [SONG PRE-RESERVE] Şarkı satırlarını SongPass'e ayır ──────────
            # Eğer bu event İngilizce şarkı sözü ise (Opening-Eng, ED-EN vb.)
            # normal çeviri döngüsünü ATLAMASI için skip_translation=True yapılır.
            # SongPass bu satırları original_text üzerinden poetik prompt ile çevirir.
            # Bu sayede "Vücuduma yük olacak..." yerine gerçek şiirsel çeviri gelir.
            _last_ev = structured_events[-1]
            if (not _last_ev.get('skip_translation')
                    and _is_english_song_event(_last_ev)):
                _last_ev['skip_translation'] = True
                _last_ev['type']   = 'song_reserved'
                _last_ev['reason'] = 'song_reserved'
                # total_dialogues sayacından çıkar (song pass ayrı sayar)
                total_dialogues -= 1
            # ─────────────────────────────────────────────────────────────────

            
        print(f"{Fore.CYAN}   [*] Toplam Satır: {len(structured_events)}, Çevrilecek: {total_dialogues}{Style.RESET_ALL}")
        try:
            from notif_bus import push_notif as _pn
            _pn(f'Analiz tamam: {len(structured_events)} satir, {total_dialogues} cevirilecek', 'info')
        except Exception: pass

        # Signs satırlarını raporla
        _sign_count = sum(1 for e in structured_events if e.get('is_sign') and not e.get('skip_translation'))
        if _sign_count:
            print(f"{Fore.CYAN}   [Signs] {_sign_count} ekran yazısı (Signs stili) tespit edildi → kısa/literal mod.{Style.RESET_ALL}")
            try:
                from notif_bus import push_notif as _pn
                _pn(f'Signs: {_sign_count} ekran yazisi tespit edildi - kisaltilmis cevirisi mod', 'info')
            except Exception: pass

        total_dialogues = len(structured_events)

        # ══════════════════════════════════════════════════════════════
        # TIMESTAMP COLLISION FIX — Çok Katmanlı Signs Tespiti
        # Bazı fansub dosyaları aynı timestamp'e 2 katman koyar:
        #   • Katman 1: blur/glow efekti — Türkçe (çevrilmiş) ✓
        #   • Katman 2: ana metin (net renk) — İngilizce skip_translation=True ✗
        # Bu pass: aynı start+end+style grubunda biri çevriye gidiyorken
        # diğeri İngilizce skip olarak kalmışsa → geri çeviri kuyruğuna al.
        # ══════════════════════════════════════════════════════════════
        _ts_groups = {}
        for _ev in structured_events:
            _p = _ev.get('parts', [])
            _ts_key = (
                _p[0] if len(_p) > 0 else '',   # layer (farkli layer = farkli katman)
                _p[1] if len(_p) > 1 else '',   # start
                _p[2] if len(_p) > 2 else '',   # end
                _ev.get('style', ''),
            )
            _ts_groups.setdefault(_ts_key, []).append(_ev)

        _collision_rescued = 0
        for _ts_key, _group in _ts_groups.items():
            if len(_group) < 2:
                continue
            # Grupta aktif (çevriye giden) event var mı?
            _has_active = any(not ev.get('skip_translation') for ev in _group)
            if not _has_active:
                continue
            # Skip olan ama İngilizce içerikli event'leri kurtar
            for _ev in _group:
                if not _ev.get('skip_translation'):
                    continue
                _ev_raw = re.sub(r'\{[^}]*\}', '', _ev.get('text', ''))
                _ev_raw = _ev_raw.replace('\\N', ' ').replace('\\n', ' ').strip()
                # [ALF-FIX] Draw/karaoke/skip-style kontrolu — bu tur satirlari HICBIR ZAMAN kurtarma!
                # ass_tag_parser ile \p1 vektor satirlari, karaoke, JP/ROM stiller korunur.
                _alf_rescue_safe = _alf_ts_safe(_ev) if _ALF_OK else (
                    not bool(re.search(r'\\p[1-9]', _ev.get('text', '')))
                )
                # [FIX] \clip(m)/\iclip(m) karaoke typeset junk'larini kurtarma!
                # Bu satirlar zaten erken exit'te dogru skip edilmisti;
                # TimestampFix onlari yanlis sekilde ceviriye almamali.
                _ev_txt = _ev.get('text', '')
                if _alf_rescue_safe and re.search(r'\\i?clip\(m\s', _ev_txt):
                    _ec_ts = re.sub(r'\{[^}]*\}', '', _ev_txt)
                    _ec_ts = re.sub(r'\{[^}]*$', '', _ec_ts).strip()
                    _ec_uniq = len(set(_ec_ts.lower().replace(' ', '')))
                    if len(_ec_ts) == 0 or len(_ec_ts) <= 2 or _ec_uniq <= 1:
                        _alf_rescue_safe = False  # clip junk → kurtarma!
                if _alf_rescue_safe and _is_english_content(_ev_raw) and len(_ev_raw) >= 5:
                    _ev['skip_translation'] = False
                    _ev.pop('reason', None)
                    _collision_rescued += 1
                    print(f"{Fore.CYAN}   [TimestampFix] Kurtarilan katman: '{_ev_raw[:55]}'{Style.RESET_ALL}")

        if _collision_rescued > 0:
            print(f"{Fore.GREEN}   [TimestampFix] {_collision_rescued} cift-katman EN satiri cevriye alindi.{Style.RESET_ALL}")
            try:
                from notif_bus import push_notif as _pn
                _pn(f'TimestampFix: {_collision_rescued} cift-katman EN satir kurtarildi', 'positive')
            except Exception: pass
        # ══════════════════════════════════════════════════════════════

        
        # 4. ÇEVİRİ İŞLEMİ (Eğer Aktifse)
        stats_skipped = 0
        stats_translated = 0

        if prefs['translate'] and translator:
            # Sadece çevrilecek olanları filtrele
            to_process_events = [e for e in structured_events if not e.get("skip_translation")]
            stats_skipped = len(structured_events) - len(to_process_events)
            
            print(f"{Fore.YELLOW}   -> Çeviri Başlıyor ({len(to_process_events)}/{total_dialogues} satır){Style.RESET_ALL}")
            _report.set_totals(total_dialogues)
            _report.set_skipped_lines(stats_skipped)

            # ── [FuzzyCache] Çeviri başlamadan önce key index oluştur ───────────────────
            # diskcache.keys() her satırda çağrılmaz — başlangıçta bir kez çekilir.
            _rfuzz_key_index = []
            if _RAPIDFUZZ_OK and _rfuzz_process:
                try:
                    # Diskcache buyuk olabilir (50k+) — daha genis pencere tara
                    _rfuzz_key_index = list(translation_cache.keys())[:30000]
                    if _rfuzz_key_index:
                        print(f"{Fore.CYAN}   [FuzzyCache] {len(_rfuzz_key_index)} key index yuklendi — fuzzy TM aktif{Style.RESET_ALL}")
                        try:
                            from notif_bus import push_notif as _pn
                            _pn(f'FuzzyCache: {len(_rfuzz_key_index)} anahtar yuklendi - akilli onbellek aktif', 'info')
                        except Exception: pass
                except Exception:
                    _rfuzz_key_index = []
            # ─────────────────────────────────────────────────────────────────────────────
            # AI model bilgisini raporda kaydet
            _report.set_ai_model(getattr(translator, 'model', '') or translator.config.get('model', ''))
            # Signs satır sayısını kaydet
            _report.set_sign_count(sum(1 for e in to_process_events if e.get('is_sign')))
            # Stil dağılımını hesapla ve kaydet
            _style_bd = {}
            for _ev in structured_events:
                _sn = _ev.get('style', 'Default')
                if _ev.get('skip_translation'):
                    _st = 'song' if (_ev.get('type') == 'song' or is_song_style_name(_sn)) else 'skipped'
                elif _ev.get('is_sign'):
                    _st = 'sign'
                else:
                    _st = 'translated'
                _cnt, _ = _style_bd.get(_sn, (0, _st))
                _style_bd[_sn] = (_cnt + 1, _st)
            if _style_bd:
                _report.set_style_breakdown(_style_bd)
            if stats_skipped > 0:
                print(f"{Fore.CYAN}   [Skip] {stats_skipped} satır çevriden hariç.{Style.RESET_ALL}")

            # ── DEYIM TARAMASI (Idiom Scanner) ──────────────────────────────────
            # SADECE İngilizce kaynak için! JP primary modda Japonca satırlar var,
            # İngilizce deyim taraması anlamsız ve yanlış sonuç verir.
            _is_jp_primary = getattr(translator, '_jp_primary', False)
            if not _is_jp_primary:
                try:
                    from idiom_scanner import scan_for_idioms, build_idiom_context
                    _all_texts = [e.get("text", "") for e in to_process_events]
                    _idioms_found = scan_for_idioms(_all_texts, max_idioms=20)
                    if _idioms_found:
                        _idiom_ctx = build_idiom_context(_idioms_found)
                        translator.set_additional_context(_idiom_ctx)
                        print(f"{Fore.GREEN}   [Idiom] {len(_idioms_found)} deyim tespit edildi → prompt'a eklendi.{Style.RESET_ALL}")
                        _report.set_idioms(_idioms_found)
                    else:
                        print(f"{Fore.CYAN}   [Idiom] Bu dosyada bilinen deyim bulunamadı.{Style.RESET_ALL}")
                except Exception as _ie:
                    print(f"{Fore.YELLOW}   [Idiom] Tarama atlandı: {_ie}{Style.RESET_ALL}")
            else:
                # JP primary modda deyim bağlamını sıfırla (önceki dosyadan kalmasın)
                translator.set_additional_context(None)
                print(f"{Fore.CYAN}   [Idiom] JP kaynak tespit edildi → deyim taraması atlandı.{Style.RESET_ALL}")
            # ────────────────────────────────────────────────────────────────────

            # ── TERMBASE + FANDOM GLOSSARY ───────────────────────────────────────
            # YENİ MİMARİ:
            #   1. Termbase: non-karakter terimler ÖNCEDen Gemini'ye çevirtilir
            #      → EN→TR tablosu termbase/ dizinine kaydedilir (TTL: 30 gün)
            #   2. Altyazi cevirisi: sadece Turkce versiyonlar + karakterler gider
            #      → Gemini onaylı Türkçe terimleri görür, tutarlı kullanır
            # HYBRID API ROUTING:
            #   ├─ Termbase/Glossary ön-çevirisi → OPENROUTER (api_keys.txt)
            #   └─ Altyazı batch çevirisi        → ANTIGRAVITY (seçilen model)
            if prefs.get('use_fandom_glossary', True):
                try:
                    _gloss_title  = prefs.get('media_title', '') or prefs.get('series_title', '')
                    _season_num   = prefs.get('season')
                    _season_title = prefs.get('season_title') or prefs.get('media_title_season')
                    _media_type   = prefs.get('media_type', 'anime')
                    _known_type   = prefs.get('known_type', '')

                    if _gloss_title:

                        # ─────────────────────────────────────────────────────────
                        # TEK SEFERLIK GUARD: glossary/termbase/PATF sadece
                        # BIRINCI dosyada çalışır. Sonraki dosyalarda prefs'ten
                        # alınan sonuç kullanılır — tekrar fetch/parse yapılmaz.
                        # ─────────────────────────────────────────────────────────
                        if not prefs.get('_glossary_initialized'):

                            # ── ADIM 1: Termbase yükle / oluştur ──────────────────
                            from termbase_manager import (
                                pre_translate_terms as _pre_tr,
                                get_termbase_tr_list as _tr_list,
                            )
                            _tb_terms = _pre_tr(
                                _gloss_title,
                                media_type=_media_type or _known_type or 'anime',
                                season_num=_season_num,
                                season_title=_season_title,
                                verbose=True,
                            )

                            # ── ADIM 2: Rapor için tam terim listesi (Fandom) ──────
                            from fandom_glossary import get_prompt_terms as _gpt
                            _meta_chars = prefs.get('media_characters', [])
                            _filtered_terms = _gpt(
                                _gloss_title,
                                media_type=_media_type,   # 'series' → Jikan atlanır
                                known_type=_known_type,   # 'series' → Jikan atlanır
                                season_num=_season_num,
                                season_title=_season_title,
                                metadata_chars=_meta_chars,  # TVMaze/TMDB fallback
                            )
                            # ── Alternatif başlıkla yeniden dene (İngilizce başarısız olursa) ──
                            # Örn: "Rascal Does Not Dream..." başarısız → "Seishun Buta Yarou..." ile tekrar
                            if not _filtered_terms and prefs.get('media_title_alt'):
                                _alt_title = prefs['media_title_alt']
                                print(f"{Fore.YELLOW}   [Glossary] '{_gloss_title}' bulunamadı → alternatif başlık deneniyor: '{_alt_title}'{Style.RESET_ALL}")
                                _filtered_terms = _gpt(
                                    _alt_title,
                                    media_type=_media_type,
                                    known_type=_known_type,
                                    season_num=_season_num,
                                    season_title=_season_title,
                                    metadata_chars=_meta_chars,
                                )
                            if _filtered_terms:
                                _term_count = sum(len(v) for v in _filtered_terms.values())
                                _report.set_glossary(_gloss_title, _term_count, terms_data=_filtered_terms)
                                print(f"{Fore.GREEN}   [Glossary] '{_gloss_title}' → {_term_count} terim (rapor){Style.RESET_ALL}")
                                try:
                                    from notif_bus import push_notif as _pn
                                    _pn(f'📚 {_gloss_title}: {_term_count} terim yüklendi', 'positive', 4000)
                                except Exception: pass

                                # Retry word set (mevcut mantık korunuyor)
                                _terms_word_set = set()
                                for _cat_terms in _filtered_terms.values():
                                    for _term in _cat_terms:
                                        for _w in re.findall(r'[a-zA-ZÀ-ɏ]+', _term.lower()):
                                            _terms_word_set.add(_w)
                                if _terms_word_set:
                                    prefs['_fandom_terms_set'] = _terms_word_set
                                    print(f"{Fore.GREEN}   [Glossary] Retry koruması: {len(_terms_word_set)} kelime{Style.RESET_ALL}")

                                # prefs'e sakla — sonraki dosyalar için
                                prefs['_filtered_terms_cached'] = _filtered_terms

                            # ── ADIM 3: Altyazı çevirisi için Türkçe prompt bloğu ─
                            # NOT: set_additional_context sadece BURADA bir kez çağrılır.
                            # Dosya döngüsünde tekrar çağrılmaz → birikim olmaz.
                            _chars_fallback = _filtered_terms.get('characters', []) if _filtered_terms else []
                            _termbase_block = _tr_list(
                                _gloss_title,
                                season_num=_season_num,
                                include_characters=_chars_fallback[:30],
                            )
                            if _termbase_block:
                                # Mevcut context'e ekle (append değil, SET)
                                _cur_add = translator._additional_context or ''
                                _sep = '\n\n' if _cur_add else ''
                                _full_ctx = _cur_add + _sep + _termbase_block
                                translator.set_additional_context(_full_ctx)
                                # !! KRITIK: prefs'e sakla — simple mode'da her dosyada
                                # yeni translator oluşturulur, context sıfırlanır!
                                # Sonraki dosyalar bu cache'den context'i geri yükler.
                                prefs['_termbase_ctx_cached'] = _termbase_block
                                _tb_term_count = sum(len(v) for v in _tb_terms.values()) if _tb_terms else 0
                                print(f"{Fore.CYAN}   [Termbase] '{_gloss_title}' → "
                                      f"{_tb_term_count} Türkçe terim + {len(_chars_fallback)} "
                                      f"karakter (fallback) Gemini'ye hazırlandı.{Style.RESET_ALL}")

                            # ── [YENİ] Termbase compliance için _tb_data kaydet ───
                            # _check_termbase_compliance ve _build_tb_lookup_from_prefs
                            # bu veriyi kullanır. characters kategorisi muaf tutulur.
                            if _tb_terms and isinstance(_tb_terms, dict):
                                prefs['_tb_data'] = _tb_terms
                                prefs.pop('_tb_lookup_flat', None)  # cache'i temizle (yeni seri)
                                _nc = sum(
                                    len(v) for cat, v in _tb_terms.items()
                                    if cat not in _TB_SKIP_CATS and isinstance(v, dict)
                                )
                                print(f"{Fore.CYAN}   [TB-Check] {_nc} terim compliance"
                                      f" kontrolüne hazır (chars muaf){Style.RESET_ALL}")



                            # ── ADIM 4: PATF — Aktif Terim Filtresi ───────────────
                            # Tüm hedef dosyalar corpus olarak taranır.
                            # Glossary'den sadece diyalogda GEÇEN terimler seçilir.
                            try:
                                from glossary_prescanner import build_active_termbase as _patf_build
                                _all_files = prefs.get('_all_target_files', [])
                                if not _all_files:
                                    # Fallback: mevcut dosyanın klasörünü tara
                                    import glob as _glob
                                    _cur_dir = os.path.dirname(
                                        prefs.get('_current_filepath', '') or filepath
                                    )
                                    _all_files = _glob.glob(os.path.join(_cur_dir, '*.ass'))
                                    _all_files += _glob.glob(os.path.join(_cur_dir, '*.srt'))

                                _patf_active = _patf_build(
                                    title=_gloss_title,
                                    file_paths=_all_files,
                                    season_num=_season_num,
                                    season_title=_season_title,
                                    media_type=_media_type or 'anime',
                                    known_type=_known_type or None,
                                    verbose=True,
                                )
                                if _patf_active:
                                    prefs['_active_terms'] = _patf_active
                                    _n_active = sum(len(v) for v in _patf_active.values())
                                    print(f"{Fore.GREEN}   [PATF] {_n_active} aktif terim → "
                                          f"batch inject filtrelenecek{Style.RESET_ALL}")
                            except Exception as _patf_err:
                                print(f"{Fore.YELLOW}   [PATF] Hata (fallback mevcut mantık): "
                                      f"{_patf_err}{Style.RESET_ALL}")

                            # Guard'ı kapat → sonraki dosyalarda bu blok çalışmaz
                            prefs['_glossary_initialized'] = True
                            print(f"{Fore.GREEN}   [Glossary] Başlatma tamamlandı — "
                                  f"sonraki dosyalarda tekrar çalışmaz.{Style.RESET_ALL}")

                        else:
                            # ── Sonraki dosyalar: zaten başlatıldı ────────────────
                            # SIMPLE MODE FIX: Her dosyada yeni translator oluşturulur
                            # → cached context'i yeni translator'a yeniden uygula.
                            _cached_ctx = prefs.get('_termbase_ctx_cached', '')
                            if _cached_ctx and not translator._additional_context:
                                translator.set_additional_context(_cached_ctx)
                                print(f"{Fore.LIGHTBLACK_EX}   [Termbase] ⚡ Context restore edildi "
                                      f"(simple mode — yeni translator).{Style.RESET_ALL}")
                            _n_active = sum(len(v) for v in prefs.get('_active_terms', {}).values())
                            print(f"{Fore.LIGHTBLACK_EX}   [Glossary] ⚡ Zaten yüklendi "
                                  f"({_n_active} aktif terim) — atlandı.{Style.RESET_ALL}")

                except Exception as _tb_exc:
                    print(f"{Fore.YELLOW}   [Termbase] Hata (fallback Fandom): {_tb_exc}{Style.RESET_ALL}")
                    # Fallback: eski Fandom-only yöntemi (sadece bir kez)
                    if not prefs.get('_glossary_initialized'):
                        try:
                            from fandom_glossary import get_prompt_terms as _gpt
                            _gloss_title2 = prefs.get('media_title', '') or prefs.get('series_title', '')
                            if _gloss_title2:
                                _ft = _gpt(_gloss_title2,
                                           media_type=prefs.get('media_type', 'auto'),
                                           known_type=prefs.get('known_type', ''),
                                           season_num=prefs.get('season'),
                                           season_title=prefs.get('season_title'))
                                if _ft:
                                    _report.set_glossary(_gloss_title2,
                                                         sum(len(v) for v in _ft.values()),
                                                         terms_data=_ft)
                                    prefs['_filtered_terms_cached'] = _ft
                        except Exception:
                            pass
                        prefs['_glossary_initialized'] = True
            # ────────────────────────────────────────────────────────────────────





            # ── BÖLÜMLER ARASI BAĞLAM (Cross-Episode Context) ────────────────────
            # Önceki bölümün son çevrilen satırlarını sliding window'a yükle.
            # AI ilk batch'te "önceki bölüm böyle bitmişti" görerek devam eder.
            if prefs.get('use_episode_context', True):
                try:
                    from episode_context import load_episode_context
                    _ep_series = prefs.get("media_title", "") or prefs.get("series_title", "")
                    _ep_season  = prefs.get("season")
                    _ep_current = prefs.get("episode")

                    # [FIX #3] Filename fallback: series/season/episode None ise filename'den parse et
                    if not _ep_series and filepath:
                        import re as _re_ep
                        _fname = os.path.basename(filepath)
                        # "Sword Art Online - S01E05 - ..." veya "SAO S2E03" gibi formatlar
                        _sm = _re_ep.search(r'(.+?)\s*[-_]?\s*[Ss](\d{1,2})[Ee](\d{1,3})', _fname)
                        if _sm:
                            _ep_series  = _sm.group(1).strip().strip('-').strip()
                            _ep_season  = int(_sm.group(2))
                            _ep_current = int(_sm.group(3))
                            print(f"{Fore.CYAN}   [EpCtx] Filename'den parse: '{_ep_series}' S{_ep_season}E{_ep_current}{Style.RESET_ALL}")
                        elif not _ep_series:
                            # En azından dosya adını seri adı olarak kullan
                            _ep_series = _re_ep.sub(r'[._-]', ' ', os.path.splitext(_fname)[0]).strip()

                    if _ep_series:
                        _ep_pairs = load_episode_context(_ep_series, season=_ep_season, current_episode=_ep_current)
                        if _ep_pairs:
                            translator.seed_context_window(_ep_pairs)
                            _report.set_ep_context(len(_ep_pairs))
                            print(f"{Fore.GREEN}   [Bölüm Bağlam] Önceki bölümden {len(_ep_pairs)} bağlam satırı yüklendi.{Style.RESET_ALL}")
                except Exception as _ece:
                    pass  # Bağlam yüklenemezse sessizce devam et
                # ────────────────────────────────────────────────────────────────────

                print(f"{Fore.CYAN}   -> {stats_skipped} satır (Şarkı/Karaoke/Romaji) korundu.{Style.RESET_ALL}")

            # ============================================================
            # ANIMASYON FRAME COLLAPSE — DEDUP'tan once
            # ============================================================
            # Ardisik, ayni temiz metne sahip Signs animasyon karelerini
            # tek bir event'e birlestir (tek API cagrisi = verimli + dogru).
            _collapse_enabled = prefs.get('collapse_animation_frames', True)
            if _collapse_enabled:
                to_process_events = collapse_animation_frames(to_process_events)
            # ============================================================

            # ============================================================
            # TEKİLLEŞTİRME (DEDUP) — Aynı metni sadece 1 kez çevir
            # ============================================================
            # Adım 1: Temiz metin → [event listesi] haritası oluştur
            _dedup_map = {}  # key (temiz metin) → [aynı metne sahip event'ler]
            for _ev in to_process_events:
                _dk = _get_dedup_key(_ev)
                if _dk not in _dedup_map:
                    _dedup_map[_dk] = []
                _dedup_map[_dk].append(_ev)

            # Adım 2: Her gruptan yalnızca ilk event'i çeviriye gönder
            _unique_events = [grp[0] for grp in _dedup_map.values()]
            _dedup_saved = len(to_process_events) - len(_unique_events)

            if _dedup_saved > 0:
                print(f"{Fore.GREEN}   [DEDUP] {_dedup_saved} tekrarlayan satır atlandı "
                      f"({len(_unique_events)} unique metin çevrilecek){Style.RESET_ALL}")
                try:
                    from notif_bus import push_notif as _pn
                    _pn(f'DEDUP: {_dedup_saved} tekrar atlandi, {len(_unique_events)} unique cevirilecek', 'info')
                except Exception: pass
            _report.set_dedup_saved(_dedup_saved)

            # Bundan sonra sadece unique event'ler batch'e gönderilir
            to_process_events = _unique_events
            # ============================================================

            # batch_size: UI'dan gelen satır limiti (varsayılan 10)
            _ui_batch_size = prefs.get('batch_size', translator.config.get('batch_size', 10))
            max_bytes = translator.config.get("max_bytes_per_batch", 2000)

            print(f"{Fore.CYAN}   [*] Batch Modu: BYTE BAZLI (Max {max_bytes} byte / Max {_ui_batch_size} satır/batch){Style.RESET_ALL}")
            try:
                from notif_bus import push_notif as _pn
                _pn(f'Batch modu: max {max_bytes}B / {_ui_batch_size} satır — {len(to_process_events)} satir kuyrukta', 'info')
            except Exception: pass

            pbar = tqdm(total=len(to_process_events), unit="satır", desc="Çevriliyor")

            # Etkinlikleri byte bazlı + satır sayısı bazlı gruplara ayır
            chunks = create_byte_based_batches(to_process_events, max_bytes, max_lines=_ui_batch_size)

            for chunk in chunks:
                # 1. Hazırlık ve Cache Kontrolü
                texts_to_translate = []
                indices_to_translate = []
                tags_map = {}    # index -> tags list (eski sistem)
                tag_maps = {}    # index -> placeholder tag_map (yeni sistem)
                seg_meta  = {}   # ── [SEGMENT MOD] idx -> {structure, n_segs} bilgisi
                
                for idx, item in enumerate(chunk):
                    # Text is already cleaned and tags extracted in previous step
                    clean_text = item["text"]
                    tags = item.get("tags", [])
                    item_tag_map = item.get("tag_map", {})

                    # [FIX 1] ASS özel karakterleri koru: \N, \n, \h → __NL__, __SL__, __HS__
                    # [FIX DEDUP] protect öncesi çift \\N\\N → tek \\N (kaynak dosyadan gelebilir)
                    clean_text = re.sub(r'(\\N){2,}', r'\\N', clean_text)
                    clean_text_protected, has_newlines = protect_ass_newlines(clean_text)
                    # [FIX KRİTİK] __NL__ / __SL__ placeholder'larını AI'ya GÖSTERME.
                    # AI'ya tek satır gönder → translasyon sonrası auto_split_line
                    # akıllıca orta noktadan böler (max 2 satır, asla 3 satır olmaz).
                    clean_text_for_ai = (clean_text_protected
                                         .replace('__NL__', ' ')
                                         .replace('__SL__', ' ')
                                         .replace('__HS__', ' '))
                    clean_text_for_ai = ' '.join(clean_text_for_ai.split()).strip()
                    # has_newlines: auto_split'in karar vermesi için sakla
                    item["_has_ass_newlines"] = has_newlines

                    # [SIGNS MOD] Ekran yazısı satırlarını işaretle → AI kısa/literal çevirir
                    if item.get('is_sign') and clean_text_for_ai:
                        clean_text_for_ai = "[SIGN] " + clean_text_for_ai

                    # ── [GARBAGE FİLTRE DEVRE DIŞI] ──────────────────────────────
                    # KALDIRILDI: Yanlış pozitif tespitler diyalog satırlarını siliyordu.
                    # Tüm satırlar API'ya gönderilir veya orijinal olarak korunur.
                    # ──────────────────────────────────────────────────────────────

                    # ── [SEGMENT MOD] Inline tag varsa segmentlere böl ────────────
                    # Tag'ler API'ya HİÇ gönderilmez — endüstri standardı yaklaşım.
                    # Metin tag sınırlarında bölünür, segmentler ⟦SEP⟧ ile birleşir,
                    # sonuçta tag'ler orijinal konumlarına programatik yerleştirilir.
                    _use_seg_mode = False
                    if _ASS_EXTRACTOR_AVAILABLE and item_tag_map:
                        # KRİTİK: _seg_split GERÇEK ASS tag'ları ister ({..} formatı).
                        # clean_text'te placeholder var (__T0__) → split_into_segments {..} bulamaz.
                        # original_text'te raw \N ve karaoke artefaktları olabilir → dosya bozulur.
                        # ÇÖZÜM: clean_text üzerindeki placeholder → gerçek tag dönüşümü yaparak
                        # "temiz ama taglı" bir metin oluştur → split_into_segments buna çalışır.
                        _seg_source = clean_text
                        for _ph, _orig_tag in item_tag_map.items():
                            _seg_source = _seg_source.replace(_ph, _orig_tag)
                        _seg_info = _seg_split(_seg_source)
                        if _seg_info['eligible'] and len(_seg_info['text_segments']) >= 1:
                            _use_seg_mode = True
                            # Tüm segmentleri ⟦SEP⟧ ile birleştir → tek batch girişi
                            _merged = _seg_merge(_seg_info['text_segments'])
                            seg_meta[idx] = {
                                'structure': _seg_info['structure'],
                                'n_segs': len(_seg_info['text_segments']),
                                'merged_text': _merged,
                            }
                            item['_seg_mode'] = True
                            texts_to_translate.append(_merged)
                            indices_to_translate.append(idx)
                            continue  # [KRİTİK] Cache/son-append atla — sadece merged text gider!
                    # ─────────────────────────────────────────────────────────────

                    # Store maps for restoration (sadece normal mod)
                    if tags: tags_map[idx] = tags
                    if item_tag_map: tag_maps[idx] = item_tag_map

                    
                    if not clean_text_for_ai or clean_text_for_ai.replace('__', '').strip() == '':
                        # Sadece tag varsa veya bossa: orijinali koru
                        # [FIX] raw_text burada tanimsiz! item["original_text"] kullan.
                        original_raw = item.get("original_text", clean_text)
                        item_tag_map = tag_maps.get(idx, {})
                        if item_tag_map:
                            item["parts"][9] = original_raw
                            item["text"] = original_raw
                        elif tags:
                            item["parts"][9] = restore_tags("", tags)
                            item["text"] = item["parts"][9]
                        continue
                        
                    # Cache Kontrolü
                    ignore_cache = translator.config.get("ignore_cache", False)
                    found_in_cache = False
                    
                    # Cache Key: normalize_cache_key() ile MD5 hash — buyuk/kucuk harf + bosluk farki artik sorun degil
                    # Ornek: 'Hello!' ve 'hello!' → ayni cache key → gereksiz API cagrisi kalmaz
                    from settings import normalize_cache_key as _nck
                    _cache_key = _nck(clean_text_for_ai)
                    if not ignore_cache and _cache_key in translation_cache:
                        cached_val = translation_cache[_cache_key]
                        
                        # [FIX KRİTİK] Boş veya çok kısa cache değeri → GEÇERSİZ!
                        # Eski merge koşusundan boş string cache'e yazılmış olabilir.
                        # Boş cache değerini geçerli sayarsak satır boş çıkıyor.
                        if not cached_val or len(cached_val.strip()) < 2:
                            found_in_cache = False
                            print(f"{Fore.YELLOW}  -> Cache ignored (empty value): {clean_text_for_ai[:30]}...{Style.RESET_ALL}")
                        else:
                            # Normalize for comparison
                            s_norm = clean_text_for_ai.strip().lower().replace('\n', ' ')
                            c_norm = cached_val.strip().lower().replace('\n', ' ')
                            
                            similarity = _string_similarity(s_norm, c_norm)
                            short_text = len(clean_text_for_ai) <= 4
                            is_same = (s_norm == c_norm)

                            if similarity > 0.85 and not short_text:
                                # Cache var ama çevrilmemiş gibi duruyor (>%85 benzerlik)
                                found_in_cache = False
                                print(f"{Fore.YELLOW}  -> Cache ignored (untranslated detected, sim={similarity:.2f}): {clean_text_for_ai[:30]}...{Style.RESET_ALL}")
                            elif is_same and not short_text:
                                 # Fallback strict check
                                 found_in_cache = False
                                 print(f"{Fore.YELLOW}  -> Cache ignored (exact match detected): {clean_text_for_ai[:30]}...{Style.RESET_ALL}")
                            else:
                                # Cache geçerli
                                translated_text = cached_val
                                translated_text = " ".join(translated_text.split())
                                # [FIX 1] ASS newline placeholder'larını restore et (__NL__ → \N vs.)
                                translated_text = restore_ass_newlines(translated_text)
                                _POS_PAT = r'\\(pos|move|org|clip|iclip|an[1-9])'
                                has_pos_tag = any(re.search(_POS_PAT, t) for t in tags)
                                if "\\N" not in translated_text:
                                    if prefs.get('_no_auto_split'):  # [Fix] WrapStyle=2
                                        pass
                                    elif has_pos_tag and len(translated_text) < 60:
                                        pass
                                    elif has_pos_tag:
                                        translated_text = auto_split_line(translated_text, max_len=65, max_lines=2)
                                    else:
                                        translated_text = auto_split_line(translated_text, max_len=65, max_lines=2)
                                
                                # Restore Tags
                                cached_tag_map = tag_maps.get(idx, {})
                                if cached_tag_map:
                                    final_text = restore_tags_from_placeholders(translated_text, cached_tag_map)
                                else:
                                    final_text = restore_tags(translated_text, tags)

                                item["parts"][9] = final_text
                                item["text"] = final_text
                                stats_translated += 1
                                found_in_cache = True
                                _report.add_cache_hit()
                    
                    if not found_in_cache and _RAPIDFUZZ_OK and _rfuzz_process and _rfuzz_key_index \
                            and len(clean_text_for_ai) >= 10 and not ignore_cache:
                        # ── [KATMAN 2] Fuzzy Cache (CAT tool standardı: ≥87% = fuzzy hit) ────────────
                        try:
                            _fuzz_m = _rfuzz_process.extractOne(
                                clean_text_for_ai,
                                _rfuzz_key_index,
                                scorer=_rfuzz.token_set_ratio,
                                score_cutoff=87.0
                            )
                            if _fuzz_m:
                                _fkey, _fscore, _ = _fuzz_m
                                _fcached = translation_cache.get(_fkey)
                                if _fcached and len(_fcached.strip()) >= 2:
                                    # Benzerlik %87+ ve çeviri doğrulaması geçti
                                    _fcs_n = _fcached.strip().lower()
                                    _fct_n = clean_text_for_ai.strip().lower()
                                    if _string_similarity(_fcs_n, _fct_n) <= 0.85:  # Çevrilmiş mi?
                                        # Yeni key'e de yaz — hit rate zaman içinde artar
                                        translation_cache[_nck(clean_text_for_ai)] = _fcached
                                        _rfuzz_key_index.append(_nck(clean_text_for_ai))
                                        # Normal cache akışına sokarak restore et
                                        cached_val = _fcached
                                        print(f"{Fore.CYAN}   [FuzzyTM] {_fscore:.0f}% hit: '{clean_text_for_ai[:35]}'{Style.RESET_ALL}")
                                        _report.add_cache_hit()
                                        # Cache restore akışı— aynı restore path'i
                                        _fz_text = " ".join(cached_val.split())
                                        _fz_text = restore_ass_newlines(_fz_text)
                                        _fz_tag_map = tag_maps.get(idx, {})
                                        if _fz_tag_map:
                                            _fz_final = restore_tags_from_placeholders(_fz_text, _fz_tag_map)
                                        else:
                                            _fz_final = restore_tags(_fz_text, tags)
                                        item["parts"][9] = _fz_final
                                        item["text"] = _fz_final
                                        stats_translated += 1
                                        found_in_cache = True
                        except Exception:
                            pass
                        # ──────────────────────────────────────────────────────────────

                    if not found_in_cache:
                        # ── Batch öncesi ön filtre ──────────────────────────────
                        # Placeholder'ları silerek gerçek içeriği bul
                        _real_content = re.sub(r'__T\d+__|__NL__|__SL__|__HS__', '', clean_text_for_ai, flags=re.IGNORECASE).strip()

                        if not _real_content:
                            # Sadece tag var, içerik yok → API'ya gönderme, orijinal koru
                            item["parts"][9] = item.get("original_text", clean_text)
                            item["text"]     = item["parts"][9]
                            continue

                        # ── [NEW] Typesetting animasyon frame tespiti ───────────
                        # "LLLLLLLL..." gibi tek karakter tekrarı → karaoke/gradient frame
                        # Hiçbir çeviri değeri yok, API'ya gönderme.
                        _content_stripped = _real_content.strip()
                        if len(_content_stripped) >= 20:
                            _dominant_char = max(set(_content_stripped), key=_content_stripped.count)
                            _dominant_ratio = _content_stripped.count(_dominant_char) / len(_content_stripped)
                            if _dominant_ratio >= 0.85:
                                # %85'den fazlası aynı karakter → animasyon frame'i
                                item["parts"][9] = item.get("original_text", clean_text)
                                item["text"]     = item["parts"][9]
                                stats_skipped += 1
                                continue

                        # ── [NEW] Yüksek entropi / watermark string tespiti ─────
                        # Şifreli/random veri: harf-rakam-noktalama karmaşık karışımı
                        # Shannon entropy > 4.5 ve kelime sayısı < 3 → watermark
                        if len(_content_stripped) >= 60:
                            import math as _math
                            _freq = {}
                            for _c in _content_stripped:
                                _freq[_c] = _freq.get(_c, 0) + 1
                            _entropy = -sum(
                                (_v / len(_content_stripped)) * _math.log2(_v / len(_content_stripped))
                                for _v in _freq.values()
                            )
                            _word_count = len(re.findall(r'[a-zA-Z]{3,}', _content_stripped))
                            _special_ratio = len(re.findall(r'[^a-zA-Z0-9\s]', _content_stripped)) / len(_content_stripped)
                            if _entropy > 4.5 and _word_count < 5 and _special_ratio > 0.15:
                                # Random/encrypted watermark → orijinal koru, çevirme
                                item["parts"][9] = item.get("original_text", clean_text)
                                item["text"]     = item["parts"][9]
                                stats_skipped += 1
                                continue
                        # ────────────────────────────────────────────────────────

                        # Çevrilecek listeye ekle
                        texts_to_translate.append(clean_text_for_ai)
                        indices_to_translate.append(idx)

                # 2. Toplu Çeviri
                if texts_to_translate:
                    try:
                        _report.add_batch()
                        _report.add_translated(len(texts_to_translate))

                        # ── PATF Batch-Seviyesi Filtre ─────────────────────────
                        # Active terimler bu batch'in satırlarına göre ikinci kez
                        # filtrelenir → sadece bu batch'te geçen terimler gider.
                        _patf_orig_ctx = None
                        _active_terms  = prefs.get('_active_terms')
                        if _active_terms:
                            try:
                                from glossary_prescanner import build_active_injection as _patf_inject
                                _batch_block = _patf_inject(
                                    active_terms=_active_terms,
                                    batch_lines=texts_to_translate,
                                    title=prefs.get('media_title', ''),
                                    max_chars=900,
                                )
                                if _batch_block:
                                    # Mevcut context'i geçici olarak batch-özel ile değiştir
                                    _patf_orig_ctx = translator._additional_context
                                    _base_ctx = _patf_orig_ctx or ''
                                    # Önceki "SERIES REFERENCE" bloğunu sil, yenisini koy
                                    import re as _re_patf
                                    _base_ctx = _re_patf.sub(
                                        r'SERIES REFERENCE[^\n]*\n(?:  [^\n]*\n)*',
                                        '', _base_ctx
                                    ).strip()
                                    _merged_ctx = (_base_ctx + '\n\n' + _batch_block).strip()
                                    translator.set_additional_context(_merged_ctx)
                            except Exception:
                                pass  # PATF hatası çeviriyi durdurmasın
                        # ──────────────────────────────────────────────────────

                        results = translator.translate_batch(texts_to_translate)

                        # PATF: orijinal context'i geri yükle
                        if _patf_orig_ctx is not None:
                            translator.set_additional_context(_patf_orig_ctx)

                        
                        # [FIX] Güvenli index erişimi: result listesi batch'ten kısa gelebilir
                        result_count = min(len(results), len(indices_to_translate))
                        
                        # [DEBUG] Batch sonucu kontrolü
                        if len(results) != len(indices_to_translate):
                            print(f"{Fore.RED}   [!] UYARI: Batch beklenti={len(indices_to_translate)} sonuç={len(results)} — {len(indices_to_translate)-len(results)} satır YOK!{Style.RESET_ALL}")
                        
                        for i in range(result_count):
                            res = results[i]
                            original_idx = indices_to_translate[i]
                            original_text_ai = texts_to_translate[i]

                            # ── [SEGMENT MOD RESULT] ─────────────────────────────────────────
                            # Bu idx segment modundaysa → ⟦SEP⟧ ile ayır, tag'lerle yeniden birleştir
                            if original_idx in seg_meta and res:
                                _sm = seg_meta[original_idx]
                                _translated_segs = _seg_split_result(res, _sm['n_segs'])
                                _rejoined = _seg_rejoin(_translated_segs, _sm['structure'])
                                # [KRİTİK] Literal Python newline → ASS \N dönüşümü!
                                # AI bazen çeviri içine \n koyar → ASS satırını fiziksel ikiye böler
                                # → Subtitle Edit "zaman kodu okuma hatası" verir (satır bozulur).
                                _rejoined = _rejoined.replace('\r\n', r'\N').replace('\r', r'\N').replace('\n', r'\N')
                                # Çift \N\N → tek \N (temizlik)
                                import re as _re_nl
                                _rejoined = _re_nl.sub(r'(\\N){2,}', r'\\N', _rejoined)
                                _item = chunk[original_idx]
                                # [FIX] AI seg modda \\N yerine __ASSNL__ yazabilir — temizle
                                _rejoined = (_rejoined
                                             .replace('__ASSNL__', r'\N')
                                             .replace('__ASSn__',  r'\n')
                                             .replace('__ASSh__',  r'\h'))
                                _item['parts'][9] = _rejoined
                                _item['text'] = _rejoined
                                # ── [KRİTİK DÜZELTME] pysubs2 ev.text DOĞRUDAN güncelle ────────
                                # Dosya pysubs2 üzerinden yazılıyor: _ev.text → dosyaya gidiyor.
                                # Sadece parts[9] / item['text'] güncellemek YETERSİZ —
                                # _pysubs2_ev güncellenmezse orijinal İngilizce metin dosyaya yazılır!
                                _pysubs2_ev_seg = _item.get('_pysubs2_ev')
                                if _pysubs2_ev_seg is not None:
                                    _pysubs2_ev_seg.text = _rejoined
                                _item['_batch_translated'] = True  # Rescue pass bu satırı atlar
                                # ────────────────────────────────────────────────────────────────
                                stats_translated += 1
                                pbar.update(1)
                                # Translation cache'e de yaz (birleşik segment → birleşik çeviri)
                                from settings import normalize_cache_key as _nck2
                                translation_cache[_nck2(_sm['merged_text'])] = res
                                continue
                            # ─────────────────────────────────────────────────────────────────

                            # ── JAPONCA ZAMİR TEMİZLEYİCİ ──────────────────────────────────
                            # Gemini prompt kuralına rağmen bazen "boku", "ore" gibi kelimeler
                            # Türkçe çıktının başına yapıştırıyor. Kod tarafında temizle.
                            if res:
                                # Cümle başında zamir → kaldır (Ben zaten Türkçede özne belirtilmez)
                                res = re.sub(
                                    r'(?i)^(boku|ore|watashi|atashi|ware|washi|omae|kisama)\s+',
                                    '', res
                                ).strip()
                                # Büyük harfle cümle başında → kaldır
                                res = re.sub(
                                    r'(?i)^(Boku|Ore|Watashi|Atashi)([,!.]\s*)',
                                    r'\2', res
                                ).strip()
                                # '__NL__' sonrası (yeni satır başı) → kaldır
                                res = re.sub(
                                    r'(?i)(__NL__|__SL__)\s*(boku|ore|watashi|atashi)\s+',
                                    r'\1 ', res
                                ).strip()
                                # [SIGN] öneki AI çıktısında kalırsa temizle
                                if res.startswith('[SIGN]') or res.startswith('[sign]'):
                                    res = re.sub(r'^\[SIGN\]\s*', '', res, flags=re.IGNORECASE).strip()
                                # Temizleme boş bıraktıysa orijinali geri al
                                if not res.strip():
                                    res = results[i]
                            # ─────────────────────────────────────────────────────────

                            # ── KALİTE KONTROLÜ: Şüpheli çıktıları yakala → single-line retry ──
                            _quality_fail_reason = None
                            _tb_missed = []   # Adım 4'te retry hint için kullanılacak

                            # 1. Çıktıda Japonca/Çince karakter var → çeviri başarısız
                            if res and re.search(r'[\u3040-\u30ff\u3400-\u9fff]', res):
                                _quality_fail_reason = f"Japonca karakter çıktıda ({res[:30]})"
                                _report.add_quality_flag("jp_chars", original_text_ai, res[:60])

                            # 2. Kaynak uzun ama çıktı çok kısa → anlamsız / kesilmiş
                            elif res and not _quality_fail_reason:
                                # [FIX] [SIGN] prefix ve __T0__ placeholder'ları kelime sayımından çıkar
                                # "{\fnDroid\pos(726,...)}l" gibi sign satırlardaki tag içeriği sayılmasın
                                _src_for_count = re.sub(r'^\[SIGN\]\s*', '', original_text_ai, flags=re.IGNORECASE)
                                _src_for_count = re.sub(r'__(?:T\d+|NL|SL|HS)__', ' ', _src_for_count, flags=re.IGNORECASE)
                                _src_for_count = re.sub(r'\{[^}]*\}', ' ', _src_for_count)  # Ham ASS {tag} bloklarını soy
                                _src_for_count = _src_for_count.strip()
                                src_words = len(_src_for_count.split())
                                res_words = len(res.split())
                                if src_words >= 5 and res_words <= 1:
                                    _quality_fail_reason = f"Çok kısa çıktı ({res_words} kelime / {src_words} kelime kaynak)"
                                    _report.add_quality_flag("too_short", original_text_ai, f"{res_words}kw/{src_words}kw")

                            # 3. [YENİ] Termbase uyum kontrolü — EN→TR karşılığı yanlış/eksik
                            # Karakterler kategorisi MUAF (karakter isimleri çevrilmez zaten).
                            # Signs satırları da muaf (genellikle grafik/sinyal — terim içermez).
                            _is_sign_for_tb = chunk[original_idx].get('is_sign', False) if original_idx < len(chunk) else False
                            if res and not _quality_fail_reason and not _is_sign_for_tb:
                                try:
                                    _tb_lu = _build_tb_lookup_from_prefs(prefs)
                                    if _tb_lu:
                                        _tb_ok, _tb_missed = _check_termbase_compliance(
                                            original_text_ai, res, _tb_lu
                                        )
                                        if not _tb_ok and _tb_missed:
                                            _quality_fail_reason = (
                                                f"Terim kaçırıldı: "
                                                f"{_tb_missed[0][0]} → {_tb_missed[0][1]}"
                                            )
                                            _report.add_quality_flag(
                                                "term_miss",
                                                original_text_ai,
                                                f"{_tb_missed[0][0]}≠{_tb_missed[0][1]}"
                                            )
                                except Exception:
                                    pass  # Termbase hatası çeviriyi durdurmasın

                            if _quality_fail_reason:
                                print(f"{Fore.YELLOW}   [⚠ Kalite] Tek satır retry: {_quality_fail_reason}{Style.RESET_ALL}")
                                try:
                                    # Terim miss ise — retry prompt'una hint ekle (Adım 4)
                                    if _tb_missed:
                                        _hint = "TERIM ZORUNLU: " + "; ".join(
                                            f"{e}={t}" for e, t in _tb_missed[:5]
                                        )
                                        _orig_add_ctx = getattr(translator, '_additional_context', '') or ''
                                        _hint_ctx = (_orig_add_ctx + "\n\n" + _hint).strip()
                                        translator.set_additional_context(_hint_ctx)
                                        _sq = translator.translate_batch([original_text_ai])
                                        # Hint'i kaldır — bir sonraki satırı etkilemesin
                                        translator.set_additional_context(_orig_add_ctx)
                                    else:
                                        _sq = translator.translate_batch([original_text_ai])
                                    if _sq and _sq[0].strip():
                                        _new_res = _sq[0]
                                        if re.search(r'[぀-ヿ㐀-鿿]', _new_res):
                                            print(f"{Fore.CYAN}     [Kalite] Retry başarısız (Japonca var) → orijinal korundu{Style.RESET_ALL}")
                                        elif _tb_missed:
                                            _retry_ok, _ = _check_termbase_compliance(original_text_ai, _new_res, _tb_lu)
                                            if not _retry_ok:
                                                print(f"{Fore.CYAN}     [Kalite] Retry terimi yine içeremedi → orijinal korundu{Style.RESET_ALL}")
                                            else:
                                                res = _new_res
                                                print(f"{Fore.GREEN}     [Kalite] Retry başarılı: {res[:40]}{Style.RESET_ALL}")
                                        else:
                                            res = _new_res
                                            print(f"{Fore.GREEN}     [Kalite] Retry başarılı: {res[:40]}{Style.RESET_ALL}")
                                except Exception:
                                    pass  # Retry başarısız → mevcut res ile devam
                            # ────────────────────────────────────────────────────────


                            # ── ARDIŞIK BENZERLİK KONTROLÜ ──────────────────────────
                            # Çeviri önceki satırın çevirisine çok benziyorsa (>0.82)
                            # VE kaynak satırlar birbirinden farklıysa (<0.45)
                            # → AI muhtemelen önceki cümleyi tekrar çevirdi → retry.
                            # [FIX] Signs satırları (ekran yazısı) bu kontrolden MUAF:
                            # Özel isimler/yer adları doğası gereği aynı kalır — dialog akışıyla ilgisiz.
                            _is_sign_item = chunk[original_idx].get('is_sign', False) if original_idx < len(chunk) else False
                            if res and not _quality_fail_reason and i > 0 and not _is_sign_item:
                                _prev_tr  = chunk[original_idx - 1].get("_translated_text", "") if original_idx > 0 else ""
                                _prev_src = texts_to_translate[i - 1]
                                if _prev_tr and _prev_src:
                                    _src_sim = difflib.SequenceMatcher(
                                        None,
                                        _strip_for_sim(original_text_ai),
                                        _strip_for_sim(_prev_src)
                                    ).ratio()
                                    _tr_sim = difflib.SequenceMatcher(
                                        None,
                                        res.strip().lower(),
                                        _prev_tr.strip().lower()
                                    ).ratio()
                                    if _tr_sim > 0.82 and _src_sim < 0.45:
                                        _sim_fixed_flag = False  # retry sonrası güncellenecek
                                        print(f"{Fore.YELLOW}   [⚠ Tekrar] Çeviriler çok benzer "
                                              f"(TR={_tr_sim:.2f}, SRC={_src_sim:.2f}) → retry...{Style.RESET_ALL}")
                                        print(f"     Önceki : '{_prev_tr[:55]}'")
                                        print(f"     Şimdiki: '{res[:55]}'")
                                        try:
                                            _retry_r = translator.translate_batch([original_text_ai])
                                            if _retry_r and _retry_r[0].strip():
                                                _r_sim2 = difflib.SequenceMatcher(
                                                    None,
                                                    _retry_r[0].strip().lower(),
                                                    _prev_tr.strip().lower()
                                                ).ratio()
                                                if _r_sim2 < _tr_sim:
                                                    res = _retry_r[0]
                                                    _sim_fixed_flag = True
                                                    print(f"{Fore.GREEN}     [Tekrar-Retry OK] {res[:55]}{Style.RESET_ALL}")
                                                else:
                                                    print(f"{Fore.CYAN}     [Tekrar-Retry] Retry da benzer → mevcut korundu.{Style.RESET_ALL}")
                                        except Exception:
                                            pass
                            # Ardışık benzerlik raporuna kaydet
                            if "_sim_fixed_flag" in dir():
                                try:
                                    _report.add_consecutive_sim(
                                        _prev_tr, res, _tr_sim, _src_sim, _sim_fixed_flag
                                    )
                                except Exception: pass
                                del _sim_fixed_flag
                            # Bir sonraki satır için bu çeviriyi sakla
                            chunk[original_idx]["_translated_text"] = res
                            # ────────────────────────────────────────────────────────

                            # [FIX KRİTİK] API boş sonuç dönerse → RETRY tetikle
                            # [FIX 402] translate_batch 402 erken çıkışında orijinal metni döndürür
                            # (res == original_text_ai) → bu boş değil, sadece çevrilmemiş
                            # Similarity kontrolüne bırak, "boş sonuç" sayma.
                            _res_is_original = (res and res.strip() == original_text_ai.strip())
                            if not res or len(res.strip()) < 2:
                                print(f"{Fore.YELLOW}   [!] BOŞ SONUÇ (batch): idx={original_idx} '{original_text_ai[:45]}' → retry tetikleniyor...{Style.RESET_ALL}")
                                _empty_result = True
                            elif _res_is_original:
                                # 402 erken çıkış: orijinal döndü → similarity=1.0 olacak, normal retry yolu
                                _empty_result = False
                            else:
                                _empty_result = False

                            # CACHE YAZMA KONTROLÜ
                            # Similarity hesabı: __Txx__ placeholder ve TitleCase isimler çıkar
                            # Aksi halde 'Stay calm, Natsuki Subaru' vs 'Sakin ol, Natsuki Subaru'
                            # placeholder + isim benzerliği yüzünden yanlış yüksek sim çıkıyor.
                            def _strip_for_sim(t: str) -> str:
                                # Case-insensitive: __T0__ ve __t0__ her ikisini de temizle
                                t = re.sub(r'__[Tt]\d+__|__NL__|__SL__|__HS__', ' ', t, flags=re.IGNORECASE)
                                # [SIGN], [OP], [ED] gibi prefix'leri temizle
                                # Aksi halde "[SIGN] Do you know what time" vs "Do you know what time"
                                # similarity = 0.84 → retry tetiklenmiyor → Ingilizce kabul!
                                t = re.sub(r'^\s*\[[A-Z][A-Z0-9]*\]\s*', '', t, flags=re.IGNORECASE)
                                t = re.sub(r'\b[A-Z][a-z]{1,}\b', '', t)  # TitleCase kelimeler (isimler)
                                t = re.sub(r'\s+', ' ', t).strip().lower()
                                return t

                            s_norm = _strip_for_sim(original_text_ai)
                            r_norm = _strip_for_sim(res)

                            # PLACEHOLDER-DOMINANT CHECK:
                            # Orijinal metin tamamen placeholder + tek kelimeyse
                            # (örn: __T0__Beater, {\pos(x,y)}OK) → AI bunu korursa doğru davranış.
                            # Similarity 1.0 görünse de retry gereksiz — direkt atla.
                            _orig_no_ph = re.sub(r'__(?:[Tt]\d+|NL|SL|HS)__', '', original_text_ai, flags=re.IGNORECASE).strip()
                            _orig_word_count = len(_orig_no_ph.split()) if _orig_no_ph else 0
                            _has_placeholder = bool(re.search(r'__[Tt]\d+__', original_text_ai, re.IGNORECASE))
                            _ai_ph_count = len(re.findall(r"__[Tt]\d+__", original_text_ai, re.IGNORECASE))
                            _skip_due_to_placeholder = (
                                _has_placeholder and (
                                    # [FIX] <= 2 → <= 1: "__T0__ Hello" gibi tag+kelime
                                    # artik atlanmiyor (2-kelimeli diyaloglar kaybediliyordu)
                                    _orig_word_count <= 1 or
                                    (_orig_word_count <= 6 and _ai_ph_count >= _orig_word_count - 1)
                                )
                            )

                            # Temizleme sonrası boşsa orijinal normalize ile karşılaştır
                            if not s_norm or not r_norm:
                                s_norm = original_text_ai.strip().lower().replace('\n', ' ')
                                r_norm = res.strip().lower().replace('\n', ' ')
                            # [rapidfuzz] difflib yerine token_set_ratio — kelime sırası farklı bile doğru
                            if _RAPIDFUZZ_OK:
                                similarity = _rfuzz.token_set_ratio(s_norm, r_norm) / 100.0
                            else:
                                similarity = _string_similarity(s_norm, r_norm)

                            # [FIX KRİTİK] should_retry sıfırla — her item için, rapidfuzz/difflib bağımsız
                            should_retry = False

                            # [FIX] Boş sonuç → doğrudan retry tetikle
                            if _empty_result:
                                should_retry = True
                                _censored_result = False
                                print(f"{Fore.YELLOW}     [!] Boş sonuç → retry tetikleniyor: '{original_text_ai[:40]}...'{Style.RESET_ALL}")
                            # [NEW] Sansür tespiti: s*k, f**k, b*tch gibi kalıplar
                            elif has_censored_content(res):
                                should_retry = True
                                _censored_result = True
                                _report.add_quality_flag("censored", original_text_ai, res[:60])
                                print(f"{Fore.YELLOW}     [!] Sansürlü çeviri → retry: '{res[:50]}'{Style.RESET_ALL}")
                            # [MEVCUT] İngilizce kaldıysa retry
                            # _skip_due_to_placeholder: sadece tag+tek_kelime → AI doğru davrandı, atla
                            elif similarity > 0.85 and not _skip_due_to_placeholder:
                                _censored_result = False
                                # [FIX5] Onomatope/kisa unlem: 'Oh uh urgh...' gibi satirlar
                                # dogasi geregi TR/EN'de benzer ses → sim=1.00 normal
                                # NOT: 'hey' listeden CIKARTILDI — 'Hey, Mother?' gibi
                                # gercek diyaloglari yanlis engelliyor.
                                _ONOMA_WORDS = frozenset(['oh','ah','uh','um','hmm','ow','ugh','urgh','err','eww','hm','huh','mhm','shh','aah','ooh'])
                                _words_in_text = re.findall(r'[a-zA-Z]+', original_text_ai.lower())
                                _all_onoma = all(w in _ONOMA_WORDS for w in _words_in_text)
                                _is_short_onoma = (
                                    len(original_text_ai.strip()) <= 20 and
                                    len(original_text_ai.split()) <= 4 and
                                    similarity >= 0.99 and
                                    bool(_words_in_text) and
                                    _all_onoma
                                )
                                if _is_short_onoma:
                                    should_retry = False
                                    print(f"{Fore.CYAN}     [Info] Onomatope, retry atlanıyor: '{original_text_ai[:30]}{Style.RESET_ALL}")
                                else:
                                    should_retry = True
                                clean_s = re.sub(r'[^\w\s]', '', s_norm).strip()
                                words_list = clean_s.split()
                                word_count = len(words_list)

                                if word_count <= 1:
                                    # Tek kelime: isim/unlem olabilir, retry gereksiz
                                    should_retry = False
                                    if len(clean_s) >= 2:
                                        print(f"{Fore.CYAN}     [Info] Tek kelime/isim, retry atlaniyor: '{clean_s}'{Style.RESET_ALL}")
                                # [FIX] Kisa Signs satirlari: kismî/animasyon metni
                                # Bunlari agresif retry'a sokma — AI zaten yapamiyor.
                                elif word_count <= 4 and item.get('is_sign'):
                                    should_retry = False
                                    print(f"{Fore.CYAN}     [Info] Kisa Signs satiri ({word_count}k), retry atlaniyor: '{clean_s[:30]}'{Style.RESET_ALL}")
                                elif words_list:
                                    # TitleCase isim listesi kontrolü KALDIRILDI.
                                    # Yerine: Fandom Glossary kelime seti ile kontrol
                                    # Satırdaki tüm kelimeler bilinen özel isim/terimse
                                    # → AI doğru davrandı (değiştirmedi) → retry GEREKSİZ
                                    _fandom_set = prefs.get('_fandom_terms_set') if prefs else None
                                    if _fandom_set and words_list:
                                        _src_words = set(re.findall(r'[a-zA-ZÀ-ɏ]+', original_text_ai.lower()))
                                        if _src_words and _src_words.issubset(_fandom_set):
                                            should_retry = False
                                            print(f"{Fore.CYAN}     [Info] Glossary özel isim satırı, retry atlanıyor: '{original_text_ai[:30]}'{Style.RESET_ALL}")
                                    # Diğer her durumda → retry yap (should_retry zaten True)

                                # Romanize Japonca şarkı sözü tespiti:
                                # Sim=1.0, AI değiştirmedi + romaji → AI doğru bıraktı, retry atla.
                                if should_retry:
                                    _romaji_chk = re.sub(
                                        r'__(?:[Tt]\d+|NL|SL|HS)__', '', original_text_ai,
                                        flags=re.IGNORECASE
                                    ).strip()
                                    _romaji_is_jp = False
                                    if prefs and prefs.get('content_detect', True) and _CONTENT_DETECTOR_OK:
                                        _cd_act, _, _ = _cd_classify_event(_romaji_chk, style_name if 'style_name' in dir() else '')
                                        _romaji_is_jp = _cd_act in ('skip_romaji', 'skip_karaoke_jp', 'skip_japanese')
                                    else:
                                        _romaji_is_jp = is_romaji_text(_romaji_chk)
                                    if _romaji_chk and _romaji_is_jp:
                                        should_retry = False
                                        print(f"{Fore.CYAN}     [Info] Romaji sarki/lyric -> retry atlaniyor: '{_romaji_chk[:40]}'{Style.RESET_ALL}")
                            else:
                                _censored_result = False


                            if should_retry:
                                _retry_reason = 'Boş sonuç' if _empty_result else ('Sansürlü çeviri' if _censored_result else f'Sim={similarity:.2f}')
                                print(f"{Fore.YELLOW}  -> Retry başlıyor ({_retry_reason}): '{original_text_ai[:30]}...'{Style.RESET_ALL}")
                                
                                max_sub_retries = 3
                                retry_succeeded = False
                                for attempt in range(1, max_sub_retries + 1):
                                    # [FIX] Boş sonuç için 2sn, benzerlik/sansür için 3sn
                                    _retry_wait = 2 if _empty_result else 3
                                    print(f"{Fore.YELLOW}     [Retry {attempt}/{max_sub_retries}] {_retry_wait}sn bekleniyor...{Style.RESET_ALL}")
                                    time.sleep(_retry_wait)
                                    
                                    try:
                                        retry_res_list = translator.translate_batch([original_text_ai])
                                        if retry_res_list:
                                            retry_res = retry_res_list[0]
                                            
                                            # [FIX] Boş sonuç + 402 orijinal dönüş + Sansür kontrolü retry içinde de
                                            if not retry_res or len(retry_res.strip()) < 2:
                                                print(f"{Fore.RED}     [Retry {attempt}] Yine boş sonuç!{Style.RESET_ALL}")
                                                break
                                            if retry_res.strip() == original_text_ai.strip():
                                                # 402 erken çıkış: API hâlâ kota limitinde
                                                print(f"{Fore.RED}     [Retry {attempt}] 402 kota: orijinal döndü, daha fazla bekleme yok.{Style.RESET_ALL}")
                                                break  # Tüm key'ler 402'de, devam etmenin anlamı yok
                                            
                                            if has_censored_content(retry_res):
                                                print(f"{Fore.RED}     [Retry {attempt}] Yine sansürlü: '{retry_res[:40]}'{Style.RESET_ALL}")
                                                break  # [FIX] continue → break: sadece retry döngüsünü kır
                                            
                                            r_retry_norm = _strip_for_sim(retry_res)
                                            _s_norm_retry = _strip_for_sim(original_text_ai) or s_norm
                                            if not r_retry_norm:
                                                r_retry_norm = retry_res.strip().lower().replace('\n', ' ')
                                            retry_sim = _string_similarity(_s_norm_retry, r_retry_norm)
                                            retry_words = re.sub(r'[^\w\s]', '', retry_res.strip().lower()).strip().split()
                                            # [FIX] Verifier entegrasyonu: sadece similarity eşiği yerine
                                            # _verify_translation ile kalite + glossary bilinciyle kontrol
                                            if _VERIFIER_AVAILABLE:
                                                try:
                                                    from tr_lang_detector import turkish_score as _tr_sc
                                                except ImportError:
                                                    def _tr_sc(t): return 0.0
                                                _vr = _verify_translation(
                                                    original_text_ai,
                                                    retry_res,
                                                    lang_score=_tr_sc(retry_res),
                                                    known_terms=prefs.get('_fandom_terms_set') if prefs else None,
                                                )
                                                retry_success = _vr.is_valid or len(retry_words) <= 1
                                                if not retry_success:
                                                    print(f"{Fore.YELLOW}     [Verifier] Retry {attempt} geçersiz: {_vr.reason} (skor={_vr.score:.2f}){Style.RESET_ALL}")
                                            else:
                                                # Verifier yok → eski eşik mantığı
                                                retry_success = (retry_sim <= 0.85 or len(retry_words) <= 1)
                                            
                                            if retry_success:
                                                print(f"{Fore.GREEN}     [Basarili!] Retry {attempt}: {retry_res[:40]}...{Style.RESET_ALL}")
                                                res = retry_res
                                                translation_cache[_nck(original_text_ai)] = res
                                                retry_succeeded = True
                                                _report.add_retry(original_text_ai, _retry_reason, succeeded=True, result_text=res)
                                                break
                                            else:
                                                print(f"{Fore.RED}     [Retry {attempt}] Hala İngilizce (Sim={retry_sim:.2f}){Style.RESET_ALL}")
                                                if retry_sim < similarity:
                                                    res = retry_res
                                                    similarity = retry_sim
                                    except Exception as retry_err:
                                        print(f"{Fore.RED}     [Hata] Retry {attempt} başarısız: {retry_err}{Style.RESET_ALL}")
                                
                                if not retry_succeeded:
                                    _report.add_retry(original_text_ai, _retry_reason, succeeded=False)
                                    # [FIX KRİTİK] Satır satır fallback modu
                                    # 3 retry da başarısız → satırı TEK BAŞINA gönder
                                    print(f"{Fore.YELLOW}     [!] Tüm retry'lar başarısız → SATIR SATIR MOD deniyor: '{original_text_ai[:40]}'{Style.RESET_ALL}")
                                    try:
                                        time.sleep(3)
                                        single_result = translator.translate_batch([original_text_ai])
                                        if single_result and single_result[0] and len(single_result[0].strip()) >= 2:
                                            single_res = single_result[0]
                                            s2_norm = single_res.strip().lower()
                                            s2_strip = _strip_for_sim(single_res)
                                            s_strip   = _strip_for_sim(original_text_ai) or s_norm
                                            if not s2_strip:
                                                s2_strip = single_res.strip().lower()
                                            if _string_similarity(s_strip, s2_strip) <= 0.85:
                                                # Gerçekten çevrilmiş!
                                                res = single_res
                                                # ── [FIX] <br /> HTML tag temizleyici ────────────────────────────────
                                                # AI bazen \N yerine HTML <br /> tag'i uretir → ASS'de ham yazı cikiyor
                                                # <br />, <br/>, <BR />, <BR> varyantlarını temizle veya \N'e dönüştür
                                                res = re.sub(r'(?i)(<br\s*/?>\s*)+', r'\\N', res)  # tüm br varyantları → \N
                                                # ─────────────────────────────────────────────────────────────────────
                                                # [FIX 1] ASS newline placeholder'larını restore et (__NL__ → \N vs.)
                                                # Bu adım auto_split'ten ÖNCE olmalı — \N varsa bölme atlanır.
                                                # restore_ass_newlines() artık kendi içinde \N\N dedup yapıyor.
                                                res = restore_ass_newlines(res)
                                                # [FIX EKLENTI] Tüm kaynaklardan gelen çift \N son güvence olarak sil
                                                res = re.sub(r'(\\N){2,}', r'\\N', res)
                                                translation_cache[_nck(original_text_ai)] = res
                                                retry_succeeded = True
                                                print(f"{Fore.GREEN}     [Satır Satır OK] {res[:40]}...{Style.RESET_ALL}")
                                            else:
                                                print(f"{Fore.RED}     [Satır Satır] Hala İngilizce — API rotasyonu deneniyor...{Style.RESET_ALL}")
                                                res = item.get('original_text', original_text_ai)
                                        else:
                                            print(f"{Fore.RED}     [Satır Satır] Boş/başarısız — API rotasyonu deneniyor...{Style.RESET_ALL}")
                                            res = item.get('original_text', original_text_ai)
                                    except Exception as sf_err:
                                        print(f"{Fore.RED}     [Satır Satır Hata]: {sf_err} — API rotasyonu deneniyor...{Style.RESET_ALL}")
                                        res = item.get('original_text', original_text_ai)

                                    # ── [YENİ] API KEY ROTASYON FALLBACK ─────────────────────────────
                                    # Satır satır da çevrilemeyen satır için farklı bir key dene.
                                    # Başarılı olursa kabul et, ardından ESKİ KEY'E geri dön.
                                    if not retry_succeeded and hasattr(translator, 'key_manager') and translator.key_manager:
                                        _km = translator.key_manager
                                        # Mevcut key'i kaydet (geri dönmek için)
                                        _current_idx_before = _km.current_index
                                        _original_key = getattr(translator, 'selected_key', None)
                                        # Farklı key al
                                        _alt_key = _km.rotate_key()
                                        _tried_alt = _alt_key and _alt_key != _original_key
                                        if _tried_alt:
                                            print(f"{Fore.CYAN}     [KEY ROT] Farklı key deneniyor: {_alt_key[:20]}...{Style.RESET_ALL}")
                                            try:
                                                time.sleep(3)
                                                # simple_mode'da selected_key'i geçici değiştir
                                                if translator.simple_mode:
                                                    translator.selected_key = _alt_key
                                                _rot_result = translator.translate_batch([original_text_ai])
                                                if _rot_result and _rot_result[0] and len(_rot_result[0].strip()) >= 2:
                                                    _rot_res = _rot_result[0]
                                                    _rot_strip = _strip_for_sim(_rot_res)
                                                    _src_strip  = _strip_for_sim(original_text_ai) or original_text_ai.lower()
                                                    if not _rot_strip:
                                                        _rot_strip = _rot_res.strip().lower()
                                                    if _string_similarity(_src_strip, _rot_strip) <= 0.85:
                                                        # Farklı key başardı!
                                                        res = _rot_res
                                                        translation_cache[_nck(original_text_ai)] = res
                                                        retry_succeeded = True
                                                        print(f"{Fore.GREEN}     [KEY ROT OK] Farklı key başardı: {res[:40]}...{Style.RESET_ALL}")
                                                    else:
                                                        print(f"{Fore.RED}     [KEY ROT] Farklı key de başaramadı — orijinal korunuyor{Style.RESET_ALL}")
                                                        res = item.get('original_text', original_text_ai)
                                                else:
                                                    print(f"{Fore.RED}     [KEY ROT] Boş sonuç — orijinal korunuyor{Style.RESET_ALL}")
                                                    res = item.get('original_text', original_text_ai)
                                            except Exception as _rot_err:
                                                print(f"{Fore.RED}     [KEY ROT Hata]: {_rot_err} — orijinal korunuyor{Style.RESET_ALL}")
                                                res = item.get('original_text', original_text_ai)
                                            finally:
                                                # ESKİ KEY'E GERİ DÖN (başarılı da olsa başarısız da olsa)
                                                if translator.simple_mode and _original_key:
                                                    translator.selected_key = _original_key
                                                    print(f"{Fore.CYAN}     [KEY ROT] Eski key'e geri dönüldü: {_original_key[:20]}...{Style.RESET_ALL}")
                                        else:
                                            print(f"{Fore.YELLOW}     [KEY ROT] Başka key yok veya tek key kullanılıyor — orijinal korunuyor{Style.RESET_ALL}")
                                            res = item.get('original_text', original_text_ai)
                                    elif not retry_succeeded:
                                        # key_manager yok (Antigravity/Ollama) → direkt orijinali koru
                                        res = item.get('original_text', original_text_ai)
                                    # ─────────────────────────────────────────────────────────────────
                            else:
                                # Başarılı çeviri — Cache'e yaz (boş değilse, normalize key ile)
                                if res and len(res.strip()) >= 2:
                                    translation_cache[_nck(original_text_ai)] = res
                            
                            # [FIX KRİTİK] Son güvenlik: sonuç hâlâ boşsa orijinal metni yaz
                            if not res or len(res.strip()) < 2:
                                print(f"{Fore.RED}     [!] Son güvenlik: boş sonuç → orijinal metin kullanılıyor{Style.RESET_ALL}")
                                item_obj = chunk[original_idx]
                                res = item_obj.get('original_text', original_text_ai)
                            
                            # [FIX KRİTİK] item güncelleme — should_retry değerinden BAĞIMSIZ
                            # Retry başarısız olsa bile en son elde edilen sonucu dosyaya yaz
                            # (İngilizce kalmasındansa en azından kısmen çevrilmiş hali daha iyi)
                            item = chunk[original_idx]
                            res = " ".join(res.split())
                            # ── [FIX] <br /> HTML tag temizleyici ────────────────────────────────
                            # AI bazen \N yerine HTML <br /> tag'i uretir → ASS'de ham yazı cikiyor
                            # Tek regex: tüm <br> varyantları + art arda gelenler → tek \N
                            res = re.sub(r'(?i)(<br\s*/?>[\s]*)+', r'\\N', res)
                            # ─────────────────────────────────────────────────────────────────────
                            # [FIX 1] ASS newline placeholder'larını restore et (__NL__ → \N vs.)
                            # Bu adım auto_split'ten ÖNCE olmalı — \N varsa bölme atlanır.
                            # restore_ass_newlines() artık kendi içinde \N\N dedup yapıyor.
                            res = restore_ass_newlines(res)
                            # [FIX EKLENTI] Tüm kaynaklardan gelen çift \N son güvence olarak sil
                            res = re.sub(r'(\\N){2,}', r'\\N', res)
                            # [FIX] Konumlandırma taglı satırları: kısaysa bölme, uzunsa geniş bölme
                            current_tags = tags_map.get(original_idx, [])
                            current_tag_map = tag_maps.get(original_idx, {})
                            _POS_PAT = r'\\(pos|move|org|clip|iclip|an[1-9])'
                            has_pos_tag = (
                                any(re.search(_POS_PAT, t) for t in current_tags) or
                                any(re.search(_POS_PAT, tag) for tag in current_tag_map.values())
                            )
                            if "\\N" not in res:
                                if prefs.get('_no_auto_split'):  # [Fix] WrapStyle=2 bypass
                                    pass
                                elif has_pos_tag and len(res) < 60:
                                    pass  # Kısa konumlu metin: bölme, konumu koru
                                elif has_pos_tag:
                                    res = auto_split_line(res, max_len=65, max_lines=2)
                                else:
                                    res = auto_split_line(res, max_len=65, max_lines=2)
                            # [FIX] Placeholder sistemi: tag'ler orijinal konumlarına
                            if current_tag_map:
                                final_res = restore_tags_from_placeholders(res, current_tag_map)
                            else:
                                final_res = restore_tags(res, current_tags)
                            
                            # [NEW] Restore Vectors (if any)
                            current_vectors = item.get("vectors", [])
                            if current_vectors:
                                print(f"Restoring {len(current_vectors)} vectors...")
                                def restore_vec_match(m):
                                    idx = int(m.group(1))
                                    if 0 <= idx < len(current_vectors):
                                        return " " + current_vectors[idx] + " "
                                    return m.group(0)
                                
                                final_res = re.sub(r'\s*__VEC\s*(\d+)\s*__\s*', restore_vec_match, final_res)

                            item["parts"][9] = final_res
                            item["text"] = final_res
                            # [FIX KRİTİK] pysubs2 ev.text doğrudan güncelle
                            _pysubs2_ev_ref = item.get('_pysubs2_ev')
                            if _pysubs2_ev_ref is not None:
                                _pysubs2_ev_ref.text = final_res
                            # [FIX] Rescue geçişい bu satırı atlasın (zaten çevrildi)
                            item['_batch_translated'] = True
                            stats_translated += 1

                            # ── CPS Tabanlı Otomatik Kısaltma (Ayarlar menüsünden açılıp kapatılabilir) ──
                            # Varsayılan: KAPALI (cps_shorten=False). Her satırda ekstra API isteği atar.
                            # Açmak için: Ayarlar menüsünde 'P. CPS Kısaltma' seçeneğini kullan.
                            if prefs.get('cps_shorten', False) and _VALIDATOR_AVAILABLE and not item.get('is_sign'):
                                try:
                                    from subtitle_validator import calculate_cps, strip_ass_tags, CPS_CRITICAL_MAX
                                    _parts = item.get('parts', [])
                                    _dur_ms = 0
                                    if len(_parts) > 2:
                                        from subtitle_validator import _ass_time_to_ms as _cps_t2ms
                                        _dur_ms = _cps_t2ms(_parts[2]) - _cps_t2ms(_parts[1])
                                    if _dur_ms > 100:  # Geçerli süre var mı
                                        _plain = strip_ass_tags(final_res.replace('\\N', ' ').replace('__NL__', ' '))
                                        _cps = calculate_cps(_plain, _dur_ms)
                                        if _cps > CPS_CRITICAL_MAX:  # >27 CPS → kritik
                                            _max_chars = int((_dur_ms / 1000.0) * (CPS_CRITICAL_MAX - 2))
                                            _max_chars = max(_max_chars, 15)
                                            print(f"{Fore.YELLOW}   [CPS] Kritik: {_cps:.1f} CPS (max {CPS_CRITICAL_MAX}) — kısaltma deneniyor (max {_max_chars} karakter){Style.RESET_ALL}")
                                            try:
                                                # [FIX v2] Dedicated shorten_line() metodu:
                                                # translate_single_line/batch formatindan tamamen bagimsiz,
                                                # direkt 'Shorten to X chars' meta-instruction gonderir.
                                                _sh_raw = translator.shorten_line(_plain, _max_chars)
                                                if _sh_raw and _sh_raw.strip():
                                                    _sh_text = _sh_raw.strip()

                                                    _sh_cps = calculate_cps(_sh_text, _dur_ms)
                                                    if _sh_cps <= CPS_CRITICAL_MAX and len(_sh_text) > 3:
                                                        # Basarili kisaltma -- tag'leri restore et
                                                        _sh_final = restore_tags_from_placeholders(_sh_text, current_tag_map) if current_tag_map else restore_tags(_sh_text, current_tags)
                                                        item["parts"][9] = _sh_final
                                                        item["text"] = _sh_final
                                                        if _pysubs2_ev_ref is not None:
                                                            _pysubs2_ev_ref.text = _sh_final
                                                        print(f"{Fore.GREEN}   [CPS] Kisaltildi: {_cps:.1f}->{_sh_cps:.1f} CPS | '{_sh_text[:50]}'{Style.RESET_ALL}")
                                                        _report.add_quality_flag("cps_shortened", _plain[:60], f"{_cps:.1f}->{_sh_cps:.1f}")
                                                        item['_cps_shortened'] = True  # [STATS] GUI stats sayaci icin

                                                    else:
                                                        print(f"{Fore.CYAN}   [CPS] Kisaltma yetersiz ({_sh_cps:.1f} CPS) -- orijinal korunuyor{Style.RESET_ALL}")
                                            except Exception:
                                                pass  # Kisaltma basarisiz --> orijinal korunuyor
                                except Exception:
                                    pass
                            # ───────────────────────────────────────────────────────────────────────

                            # ── [Asama 2] Renk kodu korunum kontrolu ─────────
                            if _VALIDATOR_AVAILABLE:
                                try:
                                    from subtitle_validator import validate_color_preservation as _vcp
                                    _orig_raw = item.get('original_text', '')
                                    if _orig_raw and '&H' in _orig_raw:
                                        _cr = _vcp(_orig_raw, final_res)
                                        if not _cr['ok'] and _cr['missing']:
                                            _report.add_quality_flag(
                                                'color_lost',
                                                item.get('original_text', '')[:60],
                                                f"Kayip: {_cr['missing'][:2]}"
                                            )
                                            _report.add_color_lost()  # [P2] Kalite skoru cezasi
                                except Exception:
                                    pass
                            # ──────────────────────────────────────────────────

                        
                        # [NEW] Eksik satır uyarısı (batch sonucu kısa geldiyse)
                        if len(results) < len(indices_to_translate):
                            missing = len(indices_to_translate) - len(results)
                            print(f"{Fore.RED}   [!] UYARI: {missing} satır batch sonucunda eksik! Bu satırlar orijinal haliyle kalacak.{Style.RESET_ALL}")
                            
                    except Exception as e:
                        print(f"Batch Error: {e}")
                        traceback.print_exc()
                
                # 3. İlerleme ve Kayıt
                pbar.update(len(chunk))
                save_translation_cache(translation_cache)
                    
            pbar.close()
            _bt_count = sum(1 for e in structured_events if e.get('_batch_translated'))
            # (Debug bilgisi - session sonunda loglara yansir)
            if _bt_count == 0 and stats_translated > 0:
                print(f"{Fore.YELLOW}   [!] UYARI: _batch_translated=0 ama stats_translated={stats_translated} — kontrol et!{Style.RESET_ALL}")

            # [FIX] Dedup sonrası doğru istatistik:
            # Toplam beklenen = unique çeviriler (dedup kopyaları dahil değil)
            # _dedup_saved zaten şu an scope içinde tanımlı
            _expected = len(to_process_events)  # unique event sayısı (dedup sonrası)
            if stats_translated < _expected:
                missed = _expected - stats_translated
                print(f"{Fore.YELLOW}   [!] {missed} satır çevrilemedi veya orijinal haliyle kaydedildi.{Style.RESET_ALL}")
                try:
                    from notif_bus import push_notif as _pn
                    _pn(f'⚠️ {missed} satır çevrilemedi — orijinal metin korundu', 'warning', 6000)
                except Exception: pass
            save_translation_cache(translation_cache) # Son kayıt

            # ============================================================
            # DEDUP BROADCAST — Çevrilmiş metni tüm kopyalara yay
            # ============================================================
            # Her dedup grubundaki ilk event başarıyla çevrildi.
            # Aynı temiz metne sahip diğer event'lere (kopyalara) çeviriyi uygula.
            # Her kopyanın kendi {\pos}, {\move}, {\color} tag'leri korunur — sadece metin değişir.
            if _dedup_saved > 0:
                _broadcast_count = 0
                for _dk, _group in _dedup_map.items():
                    if len(_group) <= 1:
                        continue  # Tekil satır, broadcast gerekmez

                    # Temsilci event (çeviriye gönderilenin güncel metnini al)
                    _rep = _group[0]
                    # Tag'leri ve placeholder'ları sıyırarak sadece saf çevrilmiş metni al
                    _translated_raw = _rep.get("text", "")
                    _translated_clean = BRACKET_PATTERN.sub('', _translated_raw).strip()
                    # Placeholder temizliği (restore edilmemişleri de temizle)
                    _translated_clean = re.sub(r'__T\d+__', '', _translated_clean).strip()

                    # Kopyalara uygula
                    for _dup in _group[1:]:
                        _dup_tag_map = _dup.get("tag_map", {})
                        _dup_tags   = _dup.get("tags", [])

                        if _dup_tag_map:
                            # Kopyaya özgü tag'lerle birleştir (\pos, \an, \move vs.)
                            _final = restore_tags_from_placeholders(_translated_clean, _dup_tag_map)
                        elif _dup_tags:
                            _final = restore_tags(_translated_clean, _dup_tags)
                        else:
                            _final = _translated_clean

                        _dup["parts"][9] = _final
                        _dup["text"]     = _final
                        # [FIX] ev.text doğrudan güncelle
                        _dup_ev_ref = _dup.get('_pysubs2_ev')
                        if _dup_ev_ref is not None:
                            _dup_ev_ref.text = _final
                        _broadcast_count += 1

                if _broadcast_count > 0:
                    print(f"{Fore.GREEN}   [DEDUP] {_broadcast_count} kopya satira ceviri yayildi{Style.RESET_ALL}")
                    try:
                        from notif_bus import push_notif as _pn
                        _pn(f'DEDUP Broadcast: {_broadcast_count} kopya satira ceviri yayildi', 'positive')
                    except Exception: pass
            # ============================================================

            # ============================================================
            # ANIMASYON FRAME BROADCAST — Collapse edilen karelere yay
            # ============================================================
            # to_process_events icindeki collapsed (birlestirilmis) eventlerin
            # cevirisi tamamlandi. Simdi bu cevirili metni structured_events
            # icindeki orijinal animasyon karelerine yayiyoruz.
            #
            # Neden to_process_events? Ceviri orada yapildi, metin orada guncellendi.
            # structured_events hala orijinal metni tutuyor (collapsed eventi icerir).
            if _collapse_enabled:
                BRACKET_P_BC = re.compile(r'\{[^}]*\}')
                _frame_broadcast_count = 0
                for _ce in to_process_events:
                    if _ce.get('collapsed_count', 0) <= 1:
                        continue
                    # Cevirili metni al
                    _tr_full = _ce.get('text', '')
                    _tr_clean = BRACKET_P_BC.sub('', _tr_full).strip()
                    _tr_clean = re.sub(r'__T\d+__', '', _tr_clean).strip()
                    if not _tr_clean:
                        continue
                    # Orijinal grup karelerine yay
                    for _frame in _ce.get('_collapsed_group', []):
                        _f_tag_map = _frame.get('tag_map', {})
                        _f_tags    = _frame.get('tags', [])
                        if _f_tag_map:
                            _f_final = restore_tags_from_placeholders(_tr_clean, _f_tag_map)
                        elif _f_tags:
                            _f_final = restore_tags(_tr_clean, _f_tags)
                        else:
                            _f_final = _tr_clean
                        _frame['text'] = _f_final
                        if _frame.get('parts') and len(_frame['parts']) >= 10:
                            _frame['parts'][9] = _f_final
                        # [FIX1] _pysubs2_ev referansi ile DOGRUDAN guncelle
                        # Tag-heavy veya is_junk nedeniyle to_process_events'e
                        # girmeyen frame'ler icin de yayilim garantilendi.
                        _frame_ev_ref = _frame.get('_pysubs2_ev')
                        if _frame_ev_ref is not None:
                            # Frame'in kendi orijinal tag bloklarini koru
                            # Sadece metin kismini guncelle
                            _orig_frame_text = _frame_ev_ref.text or ''
                            _frame_tag_block = re.search(r'^((?:\{[^}]*\})+)', _orig_frame_text)
                            if _frame_tag_block and _f_final and not _f_final.startswith('{'):
                                _f_final_with_tags = _frame_tag_block.group(1) + _f_final
                            else:
                                _f_final_with_tags = _f_final
                            _frame_ev_ref.text = _f_final_with_tags
                        _frame_broadcast_count += 1
                if _frame_broadcast_count > 0:
                    print(f"{Fore.GREEN}   [FrameCollapse] {_frame_broadcast_count} animasyon karesine ceviri yayildi{Style.RESET_ALL}")
            # ============================================================

            # ============================================================
            # DIALOG KURTARMA GECISI (Rescue Pass)
            # ============================================================
            # Bazi dialog satirlari batch hizalama hatasi nedeniyle
            # Ingilizce kalabilir. Bu gecis onlari tek tek yeniden cevirerek
            # kurtarir. Sadece Default/DefaultItalics stilli, Ingilizce kalan,
            # ve kasitli atlanmamis satirlara uygulanir.
            _rescue_enabled = prefs.get('rescue_pass', True)
            if _rescue_enabled and translator:
                _TR_CHARS = set('\u011f\u015f\u00e7\u00f6\u00fc\u0131\u0130\u011e\u015e\u00c7\u00d6\u00dc')
                # Strict Ingilizce stop word listesi
                # 'her'=Turkce'de 'every', 'all'/'our'/'well' ambiguous -> KALDIRILDI
                _ENG_STOPWORDS = {
                    'the','and','for','are','but','not','you','can','was','will',
                    'would','could','should','what','when','where','they','have','been',
                    'that','this','with','from','just','even','like','right',
                    'sure','wait','want','need','into','still','then','than','about',
                    'some','after','very','now','your','his','their',
                    # Belirsiz olmayan Ingilizce kelimeler (Turkce'de bulunmaz):
                    'think','said','know','going','doing','saying','finding',
                    'look','looks','looked','find','found','make','made',
                    'let','get','got','put','take','took','keep','kept',
                    'come','came','give','gave','told','show','showed',
                    "i'm","i've","you're","he's","she's","it's","don't","can't",
                    "won't","isn't","aren't","i'll","we'll","i'd","you'd",
                    "he'd","she'd","they'd","we'd"
                }
                # Min 2 stop word: 'the' tek basina false positive olabilir
                # Ama contract formlar ("i'm","can't") tek basina yeterli
                _ENG_MIN_HITS = 2
                # Tek contractla da kabul et ('i\'m' gibi)
                _ENG_CONTRACTS = {"i'm","i've","you're","he's","she's","it's","don't","can't",
                                  "won't","isn't","aren't","i'll","we'll","i'd","you'd"}
                _rescue_count = 0
                _rescue_candidates = []

                for _rev in structured_events:
                    if _rev.get('skip_translation'):
                        continue
                    # [FIX] Batch'te zaten başarıyla çevrilmiş → rescue atla
                    if _rev.get('_batch_translated'):
                        # [FIX] Batch "baktım" demesi yetmez — gerçekten Türkçe mi kontrol et.
                        # 3 retry başarısız → res=original_english → _batch_translated=True ama hâlâ İngilizce!
                        _bt_text = re.sub(r'\{[^}]*\}', '', _rev.get('text', '')).strip()
                        if any(c in _bt_text for c in _TR_CHARS):
                            continue  # Gerçekten Türkçe → rescue'ya gerek yok
                        # Türkçe değil → batch başarısız → rescue devam etsin
                    _rst = _rev.get('style', '')
                    _rst_lower = _rst.lower()
                    # Dialog VEYA Signs — her ikisi rescue'ya girebilir
                    _is_dialog = (
                        'default' in _rst_lower or
                        'main' in _rst_lower or
                        'italic' in _rst_lower
                    )
                    _is_sign_line = 'sign' in _rst_lower
                    _is_song_line = is_song_style_name(_rst)

                    # [FIX] Song-stil satırları:
                    # - song_en_phase2 reason'lı → Phase 2 SongPass halleder, rescue dokunmasın
                    # - Romaji/Japonca şarkı → rescue dışı (koruma)
                    # - İNGİLİZCE şarkı sözü (phase2 değil) → rescue içi
                    if _is_song_line and _rev.get('reason') == 'song_en_phase2':
                        continue  # Phase 2 SongPass halleder

                    _is_rescuable = (_is_dialog or _is_sign_line or _is_song_line)
                    if not _is_rescuable:
                        continue
                    _cur_text = re.sub(r'\{[^}]*\}', '', _rev.get('text', '')).strip()
                    if not _cur_text or len(_cur_text) < 3:
                        continue
                    # Türkçe özel karakter varsa zaten çevrilmiş
                    if any(c in _TR_CHARS for c in _cur_text):
                        continue
                    # En az _ENG_MIN_HITS İngilizce stop word VEYA 1+ contract formu olmalı
                    _w = set(re.sub(r"[^\w']", ' ', _cur_text.lower()).split())
                    _hits = _w & _ENG_STOPWORDS
                    _contracts = _w & _ENG_CONTRACTS
                    # Signs için daha sıkı eşik
                    if _is_sign_line and not _is_dialog:
                        _sign_min_hits = 3
                        if len(_hits) < _sign_min_hits and not _contracts:
                            continue
                        if len(_cur_text) < 12:
                            continue
                    else:
                        if len(_hits) < _ENG_MIN_HITS and not _contracts:
                            continue
                    # [FIX] Şarkı stili → romaji mi kontrol et
                    # Romaji/Japonca şarkı sözü → rescue dışı bırak (bilerek korunan)
                    if _is_song_line and not _is_dialog:
                        try:
                            _clean_for_romaji = re.sub(r'__(?:T\d+|NL|SL|HS)__', '', _cur_text).strip()
                            if _clean_for_romaji:
                                _rfp = prefs or {}
                                if _rfp.get('content_detect', True) and _CONTENT_DETECTOR_OK:
                                    _cd_act2, _, _ = _cd_classify_event(_clean_for_romaji, '')
                                    _is_romaji_rescue = _cd_act2 in ('skip_romaji', 'skip_karaoke_jp', 'skip_japanese')
                                else:
                                    _is_romaji_rescue = is_romaji_text(_clean_for_romaji)
                                if _is_romaji_rescue:
                                    continue  # Romaji şarkı → koru, çevirme
                        except Exception:
                            pass
                    _rescue_candidates.append((_rev, _hits))



                if _rescue_candidates:
                    print(f"{Fore.YELLOW}   [Rescue] {len(_rescue_candidates)} satir hala Ingilizce \u2192 kurtarma...{Style.RESET_ALL}")
                    try:
                        from notif_bus import push_notif as _pn
                        _pn(f'Rescue Pass: {len(_rescue_candidates)} satir hala Ingilizce - kurtarma basliyor', 'warning')
                    except Exception: pass
                    import time as _time_rescue

                    # ── [FIX] Rescue DEDUP: Aynı metni sadece 1 kez çevir ──────────
                    # Aynı İngilizce metne sahip tüm event'leri grupla
                    _rescue_dedup: dict[str, list] = {}
                    for _rev, _orig_hits in _rescue_candidates:
                        _rdk = re.sub(r'\{[^}]*\}', '', _rev.get('text', '')).strip()
                        _rdk = _rdk.replace('\\N', ' ').replace('__NL__', ' ').strip().lower()
                        if _rdk not in _rescue_dedup:
                            _rescue_dedup[_rdk] = []
                        _rescue_dedup[_rdk].append((_rev, _orig_hits))

                    # Sadece unique metinleri çevir, sonucu tüm kopyalara yay
                    _rescue_dedup_list = [group[0] for group in _rescue_dedup.values()]
                    _rescue_skipped = len(_rescue_candidates) - len(_rescue_dedup_list)
                    if _rescue_skipped > 0:
                        print(f"{Fore.GREEN}   [Rescue-DEDUP] {_rescue_skipped} kopya satir birlestirildi "
                              f"({len(_rescue_dedup_list)} unique metin cevrilecek){Style.RESET_ALL}")
                    # ────────────────────────────────────────────────────────────────

                    for _rev, _orig_hits in _rescue_dedup_list:
                        _cur_text_r = re.sub(r'\{[^}]*\}', '', _rev.get('text', '')).strip()
                        _cur_clean_r = _cur_text_r.replace('\\N', ' ').replace('__NL__', ' ').strip()
                        _orig_tags   = _rev.get('tags', [])
                        _orig_tagmap = _rev.get('tag_map', {})
                        try:
                            _rres = translator.translate_single_line(_cur_clean_r, retries=3)
                            if _rres and _rres.strip().lower() != _cur_clean_r.strip().lower():
                                _rw = set(re.sub(r"[^\w']", ' ', _rres.lower()).split())
                                _still = _rw & _ENG_STOPWORDS
                                if len(_still) < len(_orig_hits):
                                    _final_r = (restore_tags_from_placeholders(_rres, _orig_tagmap) if _orig_tagmap
                                                else restore_tags(_rres, _orig_tags) if _orig_tags
                                                else _rres)
                                    _rev['text'] = _final_r
                                    if _rev.get('parts') and len(_rev['parts']) >= 10:
                                        _rev['parts'][9] = _final_r
                                    # [FIX] ev.text doğrudan güncelle
                                    _rescue_ev_ref = _rev.get('_pysubs2_ev')
                                    if _rescue_ev_ref is not None:
                                        _rescue_ev_ref.text = _final_r
                                    # [FIX] Rescue sonucunu cache'e yaz — bir daha rescue'ya düşmesin
                                    try:
                                        translation_cache[_cur_clean_r] = _final_r
                                    except Exception:
                                        pass
                                    _rescue_count += 1
                                    print(f"{Fore.GREEN}     [Rescue OK] '{_cur_clean_r[:35]}' \u2192 '{_rres[:35]}'{Style.RESET_ALL}")
                                    # ── [FIX] Rescue DEDUP Broadcast: Kopyalara yay ──
                                    _rdk_key = _cur_clean_r.strip().lower()
                                    _rdup_group = _rescue_dedup.get(_rdk_key, [])
                                    _rbc = 0
                                    for _rdup_ev, _ in _rdup_group[1:]:  # Temsilciyi atla (zaten güncellendi)
                                        _rdup_tagmap = _rdup_ev.get('tag_map', {})
                                        _rdup_tags   = _rdup_ev.get('tags', [])
                                        _rdup_final  = (restore_tags_from_placeholders(_rres, _rdup_tagmap)
                                                        if _rdup_tagmap else
                                                        restore_tags(_rres, _rdup_tags) if _rdup_tags
                                                        else _rres)
                                        _rdup_ev['text'] = _rdup_final
                                        if _rdup_ev.get('parts') and len(_rdup_ev['parts']) >= 10:
                                            _rdup_ev['parts'][9] = _rdup_final
                                        _rdup_ev_ref = _rdup_ev.get('_pysubs2_ev')
                                        if _rdup_ev_ref is not None:
                                            _rdup_ev_ref.text = _rdup_final
                                        _rbc += 1
                                    if _rbc > 0:
                                        _rescue_count += _rbc
                                    # ─────────────────────────────────────────────────
                                else:
                                    print(f"{Fore.CYAN}     [Rescue] Hala EN: '{_cur_clean_r[:40]}'{Style.RESET_ALL}")
                            else:
                                print(f"{Fore.CYAN}     [Rescue] Degismedi: '{_cur_clean_r[:35]}'{Style.RESET_ALL}")
                        except Exception as _re:
                            print(f"{Fore.RED}     [Rescue] Hata: {_re}{Style.RESET_ALL}")
                        _time_rescue.sleep(1)

                    if _rescue_count > 0:
                        print(f"{Fore.GREEN}   [Rescue] {_rescue_count}/{len(_rescue_candidates)} satir kurtarildi!{Style.RESET_ALL}")
                        try:
                            from notif_bus import push_notif as _pn
                            _pn(f'🚨 Rescue: {_rescue_count}/{len(_rescue_candidates)} satır kurtarildi!', 'positive', 5000)
                        except Exception: pass
                else:
                    print(f"{Fore.GREEN}   [Rescue] ✓ Tum satirlar cevrilmis — kurtarmaya gerek yok.{Style.RESET_ALL}")
            # ============================================================

        # ======================================================
        # PHASE 2 — Şarkı Sözü Çevirisi (İngilizce OP/ED)
        # Ana çeviri bitti, şimdi İngilizce şarkı eventlerini
        # ayrı, şiirsel bir prompt ile çeviriyoruz.
        # ======================================================
        if prefs.get('translate') and prefs.get('use_song_lyrics_pass', prefs.get('translate_song_lyrics', True)):
            _song_media_ctx = {
                'title':   prefs.get('media_title', '') or prefs.get('series_title', ''),
                'season':  str(prefs.get('season_number', '') or prefs.get('season', '')),
                'episode': str(prefs.get('episode_number', '') or prefs.get('episode', '')),
                'use_style_suffix_detection':    prefs.get('use_style_suffix_detection', True),
                'use_karaoke_collapse':          prefs.get('use_karaoke_collapse', True),
                'ignore_song_style_for_romaji':  prefs.get('ignore_song_style_for_romaji', False),
            }
            print(f"{Fore.CYAN}   [♫ SongPass] Şarkı sözü geçişi başlıyor...{Style.RESET_ALL}")
            try:
                from notif_bus import push_notif as _pn
                _pn('♫ OP/ED şarkı sözü geçişi başlıyor...', 'info', 3000)
            except Exception: pass
            _song_count = translate_song_lyrics_pass(
                structured_events, translator, _song_media_ctx
            )
            if _song_count > 0:
                print(f"{Fore.MAGENTA}   [♫ SongPass] {_song_count} şarkı sözü satırı işlendi{Style.RESET_ALL}")
                try:
                    from notif_bus import push_notif as _pn
                    _pn(f'♫ {_song_count} şarkı sözü satırı çevrildi ✅', 'positive', 5000)
                except Exception: pass
            else:
                print(f"{Fore.BLUE}   [♫ SongPass] Şarkı sözü event'i bulunamadı (Romaji/JP satırları veya şarkı stili yok){Style.RESET_ALL}")
                try:
                    from notif_bus import push_notif as _pn
                    _pn('♫ Şarkı sözü bulunamadı (Romaji/JP stil)', 'warning', 4000)
                except Exception: pass
        elif not prefs.get('use_song_lyrics_pass', True):
            print(f"{Fore.YELLOW}   [♫ Motor] Şarkı sözü geçişi KAPALI — normal çeviri kullanıldı{Style.RESET_ALL}")
        # ======================================================


        # ======================================================
        # [pysubs2] Güvenli kaydetme — event listesi korunur
        # ======================================================
        if _using_pysubs2 and _ass_reader is not None:
            # pysubs2: structured_events'teki güncel parts[9]'ları
            # SSAEvent.text'e uygula, ardından pysubs2 ile kaydet.
            _subs_ev_list = list(_ass_reader._subs)
            _se_idx = 0  # structured_events index'i
            for _psi, _ps_item in enumerate(_pysubs2_parts_list):
                if _ps_item.get('is_comment_event', False):
                    # Akilli Comment kontrolu: atlanmasi gereken mi, yoksa cevrilen mi?
                    _c_ev2  = _ps_item.get('_ev')
                    _actor2 = (_c_ev2.name   if _c_ev2 else '').strip()
                    _eff2   = (_c_ev2.effect  if _c_ev2 else '').strip()
                    _ctxt2  = re.sub(r'\{[^}]*\}', '', (_c_ev2.text if _c_ev2 else '')).replace('\\N', ' ').strip()
                    _was_skipped = (
                        bool(_actor2) or bool(_eff2) or
                        bool(re.match(r'^[ml]\s+[-\d]', _ctxt2)) or
                        len(_ctxt2) < 3 or
                        not re.search(r'[a-zA-Z]{3,}', _ctxt2)
                    )
                    if _was_skipped:
                        continue  # Bu Comment structured_events'te yok, atla
                    # Atlanmamis Comment → structured_events'te var, devam et

                if _se_idx >= len(structured_events):
                    break
                _se = structured_events[_se_idx]
                _se_idx += 1
                _sp = _se.get('parts', [])

                # Timing offset
                if time_offset != 0.0:
                    try:
                        if len(_sp) >= 3:
                            _st = parse_ass_time(_sp[1]) + time_offset
                            _et = parse_ass_time(_sp[2]) + time_offset
                            _sp[1] = format_ass_time(max(0, _st))
                            _sp[2] = format_ass_time(max(0, _et))
                            _psi_ev = _ps_item.get('_ev')
                            if _psi_ev:
                                _psi_ev.start = max(0, int(_st * 1000))
                                _psi_ev.end   = max(0, int(_et * 1000))
                    except Exception: pass
                # [FIX KRİTİK] ev.text BURADA YAZILMIYOR — çeviri sırasında
                # _pysubs2_ev_ref.text = final_res ile doğrudan güncellendi.



            # ── [Asama 3] Language header → 'tr' yaz ─────────────────────────
            if prefs.get('translate') and prefs.get('write_language_header', True):
                try:
                    from ass_file_reader import write_language_header as _wlh
                    _tgt_lang = prefs.get('target_language_code', 'tr')
                    if _wlh(_ass_reader, _tgt_lang):
                        print(f"{Fore.CYAN}   [ScriptInfo] Language: {_tgt_lang} yazildi{Style.RESET_ALL}")
                except Exception:
                    pass
            # ──────────────────────────────────────────────────────────────────

            # ── [FİNAL TEMİZLİK] — KAYDETMEDEN ÖNCE HER EVENT'E UYGULANAN FULL PASS ──
            # Yakalananlar:
            #   <br />, <br/>, <br>, <BR /> (tüm varyantlar) → \N
            #   {<br />} veya {\<br />} gibi bozulmuş tag içi br'ler → temizle
            #   __NL__ / __SL__ kaçak placeholder'ları → \N
            #   Baştaki / sondaki \N → sil (anlamsız boş satır)
            #   \N\N veya 3+ satır → auto_split_line ile max 2 satır
            _BR_ANY_RE  = re.compile(r'(?i)<br\s*/?>', re.IGNORECASE)
            _NL_PH_RE   = re.compile(r'__(NL|SL)__', re.IGNORECASE)
            _NN_RE      = re.compile(r'(\\N){2,}')
            _ASS_TAG_RE = re.compile(r'\{[^}]*\}')

            for _ev in _ass_reader._subs:
                if not (hasattr(_ev, 'text') and _ev.text):
                    continue
                _t = _ev.text

                # ── [GARBAGE DETECT DEVRE DIŞI] ──────────────────────────────────
                # KALDIRILDI: Yanlış pozitif tespitler geçerli event'leri siliyordu.
                # ──────────────────────────────────────────────────────────────────

                # 1) {<br />} gibi tag icine sikisik br → tag'i sil
                _t = re.sub(r'\{[^}]*<br[^}]*\}', '', _t, flags=re.IGNORECASE)

                # 2) Kalan <br> varyantlari → \N  [BUG FIX: r'\N' degil r'\\N' kullan]
                #    re.sub repl'de r'\\N' = literal backslash+N = ASS hard newline
                if '<br' in _t.lower():
                    _t = _BR_ANY_RE.sub(r'\\N', _t)

                # 3) Kacak placeholder'lar → \N
                if '__NL__' in _t or '__SL__' in _t:
                    _t = _NL_PH_RE.sub(r'\\N', _t)

                # 4) Satir basindaki \N → sil
                while _t.startswith('\\N'):
                    _t = _t[2:].lstrip()

                # 5) Satir sonundaki \N → sil
                while _t.endswith('\\N'):
                    _t = _t[:-2].rstrip()

                # 6) Coklu \N → max 2 satir (auto_split_line tek otorite)
                _nn_count = _t.count('\\N')
                if _nn_count >= 1:
                    # Tag'leri ayir, metni birlestir, yeniden bol
                    _tags_saved = _ASS_TAG_RE.findall(_t)
                    _tag_positions = [(m.start(), m.group()) for m in _ASS_TAG_RE.finditer(_t)]
                    _clean = _ASS_TAG_RE.sub('', _t)
                    _combined = ' '.join(p.strip() for p in _clean.split('\\N') if p.strip())
                    _split_result = auto_split_line(_combined, max_len=65, max_lines=2)
                    # Tag'leri orijinal konumlarina gore geri ekle
                    # Basit strateji: pozisyon tag'leri basa, stil tag'leri oldugu yerde
                    _pos_tags = [tg for tg in _tags_saved if re.search(r'\\(pos|move|org|an|clip)', tg)]
                    _style_tags_str = ''.join(tg for tg in _tags_saved if tg not in _pos_tags)
                    if _pos_tags:
                        _t = ''.join(_pos_tags) + _split_result
                    else:
                        _t = _split_result
                    # Stil tag'leri (italic/bold) — _split_result icinde zaten yoksa sona ekle
                    if _style_tags_str and _style_tags_str not in _t:
                        _t = _t + _style_tags_str

                _ev.text = _t
            # ─────────────────────────────────────────────────────────────────────

            # pysubs2 ile kaydet
            _ass_reader._subs.save(output_path, encoding='utf-8-sig')
        else:
            # Fallback: eski satır-birleştirme yöntemi
            new_lines = []
            new_lines.extend(header)
            new_lines.extend(styles)
            new_lines.append(events[0])  # [Events]
            if format_line_string:
                new_lines.append(format_line_string)
            for item in structured_events:
                parts = item["parts"]
                if time_offset != 0.0:
                    try:
                        st = parse_ass_time(parts[1]) + time_offset
                        et = parse_ass_time(parts[2]) + time_offset
                        parts[1] = format_ass_time(max(0, st))
                        parts[2] = format_ass_time(max(0, et))
                    except Exception: pass
                new_lines.append(",".join(parts))
            with open(output_path, 'w', encoding='utf_8_sig') as f:
                for line in new_lines:
                    f.write(line + "\n")

        print(f"{Fore.GREEN}   [OK] Altyazı kaydedildi: {os.path.basename(output_path)}{Style.RESET_ALL}")
        try:
            from notif_bus import push_notif as _pn
            _pn(f'✅ Kaydedildi: {os.path.basename(output_path)}', 'positive', 4000)
        except Exception: pass

        # ── [QA Rescue Pass] Post-çeviri kurtarma + HTML rapor ───────────────
        if prefs.get('qa_rescue_pass', True):
            try:
                from ass_qa_checker import run_qa_rescue_pass
                _qa_subs = _ass_reader._subs if hasattr(_ass_reader, '_subs') else None
                if _qa_subs is not None:
                    _qa_rpt  = get_report()
                    _qa_anime = prefs.get('media_title', '') or prefs.get('series_title', '')
                    _qa_res  = run_qa_rescue_pass(
                        pysubs2_subs = _qa_subs,
                        en_file_path = filepath,   # filepath = islenen ASS dosyasi
                        translator   = translator,
                        prefs        = prefs,
                        output_path  = output_path,
                        report       = _qa_rpt,
                        anime_title  = _qa_anime,
                        verbose      = True,
                    )
                    if _qa_res.get('rescued', 0) > 0:
                        print(f"{Fore.GREEN}   [QA-Rescue] {_qa_res['rescued']} satır kurtarıldı, "
                              f"{_qa_res.get('remaining',0)} hâlâ İngilizce{Style.RESET_ALL}")
                        try:
                            from notif_bus import push_notif as _pn
                            _rem = _qa_res.get('remaining', 0)
                            _pn(f'🚨 QA-Rescue: {_qa_res["rescued"]} satır kurtarıldı'
                                + (f' — {_rem} hala İng.' if _rem else ' ✔️'), 'positive', 6000)
                        except Exception: pass
            except Exception as _qa_err:
                print(f"{Fore.YELLOW}   [QA-Rescue] Atlandı: {_qa_err}{Style.RESET_ALL}")
        # ─────────────────────────────────────────────────────────────────────

        # ── [Aşama 1] CPS/CPL Doğrulama Özeti ────────────────────────────

        if _VALIDATOR_AVAILABLE and prefs.get('validate_cps_cpl', True):
            try:
                _val_results = _validate_all(structured_events)
                _val_summary = _summarize_validation(_val_results)
                _crit = _val_summary.get('criticals', 0)
                _warn = _val_summary.get('warnings', 0)
                _scroll = _val_summary.get('scroll_credits', 0)
                _avg_cps = _val_summary.get('avg_cps', 0)
                _max_cps = _val_summary.get('max_cps', 0)
                _max_cpl = _val_summary.get('max_cpl', 0)
                if _crit > 0 or _warn > 0:
                    print(f"{Fore.YELLOW}   [Validator] CPS/CPL: {_warn} uyarı, {_crit} kritik "
                          f"| Avg CPS={_avg_cps}, Max CPS={_max_cps}, Max CPL={_max_cpl}{Style.RESET_ALL}")
                    # Kritik olanları rapora quality_flag olarak ekle
                    _rpt_now = get_report()
                    if _rpt_now:
                        for _vr in _val_summary.get('details_warn', [])[:20]:
                            if _vr.cps_critical:
                                _rpt_now.add_quality_flag(
                                    'cps_critical',
                                    _vr.plain_text[:80],
                                    f"CPS={_vr.cps:.1f} ({_vr.duration_ms}ms)"
                                )
                                _rpt_now.add_cps_violation()  # [P2] Kalite skoru cezasi
                            elif _vr.cpl_warning and not _vr.cps_warning:
                                _rpt_now.add_quality_flag(
                                    'cpl_long',
                                    _vr.plain_text[:80],
                                    f"CPL={_vr.max_cpl} karakter"
                                )
                else:
                    print(f"{Fore.GREEN}   [Validator] CPS/CPL OK — "
                          f"Avg={_avg_cps} CPS, Max={_max_cpl} CPL{Style.RESET_ALL}")
                if _scroll:
                    print(f"{Fore.CYAN}   [Validator] {_scroll} banner/scroll efekti satırı atlandı.{Style.RESET_ALL}")
            except Exception as _ve:
                pass  # Doğrulama opsiyonel — hata pipeline'ı durdurmasın
        # ────────────────────────────────────────────────────────────────

        # ── [Asama 3] Timing Ortusme Tespiti ─────────────────────────────
        if _VALIDATOR_AVAILABLE and prefs.get('check_timing_overlaps', True):
            try:
                from subtitle_validator import find_timing_overlaps, summarize_overlaps
                _ov = find_timing_overlaps(structured_events)
                _ov_sum = summarize_overlaps(_ov)
                _ov_crit = _ov_sum.get('critical', 0)
                _ov_total = _ov_sum.get('total', 0)
                if _ov_crit > 0:
                    print(f"{Fore.RED}   [Timing] {_ov_crit} kritik ortusme (100ms+) tespit edildi!{Style.RESET_ALL}")
                    _rpt_ov = get_report()
                    if _rpt_ov:
                        for _o in _ov_sum.get('details', [])[:10]:
                            if _o.get('overlap_ms', 0) > 100:
                                _rpt_ov.add_quality_flag(
                                    'timing_overlap',
                                    _o.get('text_a', '')[:60],
                                    f"Ortusme: {_o['overlap_ms']}ms — sonraki: {_o.get('text_b','')[:30]}"
                                )
                                _rpt_ov.add_timing_overlap()  # [P2] Kalite skoru cezasi
                elif _ov_total > 0:
                    print(f"{Fore.YELLOW}   [Timing] {_ov_total} hafif dokunma/ortusme (< 100ms){Style.RESET_ALL}")
                else:
                    print(f"{Fore.GREEN}   [Timing] Timing OK — ortusme yok{Style.RESET_ALL}")
            except Exception:
                pass
        # ────────────────────────────────────────────────────────────────

        # ── Kalite Raporu Finaliz et ────────────────────────────────
        if prefs.get('generate_html_report', True):
            try:
                _rpt = get_report()
                if _rpt:
                    _mode = getattr(translator, "_mode_used", "EN") if translator else "EN"
                    _series = prefs.get("media_title", "") or prefs.get("series_title", "")
                    _dur = __import__("time").time() - _report_start_time
                    _rpt.finalize(output_path, duration_sec=_dur, mode=_mode, series_title=_series)
                    _rpath = _rpt.save()
                    if _rpath:
                        print(f"{Fore.CYAN}   [Rapor] HTML raporu oluşturuldu: {os.path.basename(_rpath)}{Style.RESET_ALL}")
            except Exception as _re:
                pass
        # ───────────────────────────────────────────────────────────

        # ── BÖLÜM BAĞLAMINI KAYDET (Cross-Episode) ───────────────────────────
        # Bu bölümün son satırlarını bir sonraki bölüm için sakla.
        if prefs.get('use_episode_context', True):
            try:
                from episode_context import save_episode_context
                _ec_series  = prefs.get("media_title", "") or prefs.get("series_title", "")
                _ec_season  = prefs.get("season")
                _ec_episode = prefs.get("episode")

                # [FIX #3] Filename fallback: series/season/episode None ise filename'den parse et
                if not _ec_series and filepath:
                    import re as _re_ec
                    _fname_ec = os.path.basename(filepath)
                    _sm_ec = _re_ec.search(r'(.+?)\s*[-_]?\s*[Ss](\d{1,2})[Ee](\d{1,3})', _fname_ec)
                    if _sm_ec:
                        _ec_series  = _sm_ec.group(1).strip().strip('-').strip()
                        _ec_season  = int(_sm_ec.group(2))
                        _ec_episode = int(_sm_ec.group(3))
                        print(f"{Fore.CYAN}   [EpCtx Save] Filename'den parse: '{_ec_series}' S{_ec_season}E{_ec_episode}{Style.RESET_ALL}")

                if _ec_series and translator:
                    _ec_pairs = translator.get_context_window()
                    if _ec_pairs:
                        save_episode_context(_ec_series, _ec_pairs, season=_ec_season, episode=_ec_episode)
            except Exception as _ece2:
                pass
        # ─────────────────────────────────────────────────────────────────────

        # EKSTRA FORMATLAR (SRT / VTT)
        file_base = os.path.splitext(output_path)[0]
        
        needed_formats = prefs.get('sub_format', 'ASS')
        if needed_formats == 'ALL' or needed_formats == 'SRT':
            save_as_srt(structured_events, file_base + ".srt")
            
        if needed_formats == 'ALL' or needed_formats == 'VTT':
            save_as_vtt(structured_events, file_base + ".vtt")
        
        # ── [GUI Stats] _last_run_stats.json yaz ─────────────────────────────
        # manual_gui.py _on_done bu dosyayi okur ve kullaniciya gosterir.
        try:
            _stats_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_last_run_stats.json")
            _cache_hits  = stats_translated - sum(1 for e in structured_events if not e.get('skip_translation') and not e.get('_from_cache', False)) if hasattr(structured_events[0] if structured_events else {}, 'get') else 0
            # Daha guvenilir: translation_cache metadata yerine prefs'ten
            _fuzzy_hits  = getattr(translation_cache, '_fuzzy_hit_count', 0) if translation_cache else 0
            _cps_fixed   = sum(1 for e in structured_events if e.get('_cps_shortened', False))
            _song_lines  = sum(1 for e in structured_events if e.get('type') == 'song' or is_song_style_name(e.get('style', '')))
            _stats_data  = {
                "translated":    stats_translated,
                "skipped":       stats_skipped,
                "total":         len(structured_events),
                "fuzzy_hits":    _fuzzy_hits,
                "cps_shortened": _cps_fixed,
                "song_lines":    _song_lines,
                "output_file":   os.path.basename(output_path),
                "duration_sec":  round(__import__("time").time() - _report_start_time, 1),
                "force_mode":    bool(prefs.get('force_translate', False)),  # [STATS] cache devre disi mi?
            }
            import json as _json_stats
            import tempfile as _tmp_stats
            _sp_dir = os.path.dirname(_stats_path)
            with _tmp_stats.NamedTemporaryFile(mode='w', encoding='utf-8', suffix='.tmp',
                                               dir=_sp_dir, delete=False) as _sf:
                _json_stats.dump(_stats_data, _sf, ensure_ascii=False, indent=2)
                _sf_tmp = _sf.name
            os.replace(_sf_tmp, _stats_path)
        except Exception:
            pass
        # ─────────────────────────────────────────────────────────────────────

        # ── Adaptif Öğrenici: Bu dosyadan öğrenilen pattern'leri kaydet ──────
        # Her dosya çevirisi bittikten sonra _learned_skip_patterns.json güncellenir.
        # Böylece sistem her geçen dosyayla daha zeki hale gelir.
        try:
            _learner_save()
        except Exception as _le:
            print(f"   [Learner] Pattern kaydetme hatası (kritik değil): {_le}")
        # ─────────────────────────────────────────────────────────────────────

        # Başarılı
        # ── Fail-Safe Kontrol ─────────────────────────────────────────────────
        # prefs['fail_safe_translation'] = True ise ve hiç satır çevrilmedi ise
        # (tüm satırlar API hatası/timeout nedeniyle orijinal kaldı) —
        # SubtitleTranslationError fırlatılır. Bu exception otomatik indirici.py'nin
        # ana döngüsünde yakalanarak tüm batch anında durdurulur.
        if prefs.get('fail_safe_translation', False) and prefs.get('translate', True):
            _to_translate_count = len([e for e in structured_events if not e.get('skip_translation')])
            if _to_translate_count > 0 and stats_translated == 0:
                _err_msg = (
                    f"[FAIL-SAFE] Altyazı çevirisi tamamen başarısız! "
                    f"{_to_translate_count} satır çevrilmesi gerekiyordu, "
                    f"hiçbiri çevrilmedi. "
                    f"Tüm batch durduruluyor. Dosya: {os.path.basename(filepath)}"
                )
                print(f"{Fore.RED}   {_err_msg}{Style.RESET_ALL}")
                try:
                    from notif_bus import push_notif as _pn
                    _pn(_err_msg, 'error')
                except Exception:
                    pass
                raise SubtitleTranslationError(_err_msg)
        # ─────────────────────────────────────────────────────────────────────

        return {
            "success": True,
            "translated": stats_translated,
            "skipped": stats_skipped
        }
            
    except SubtitleTranslationError:
        raise  # Fail-safe hatasını yukarıya aktar — suppress etme!
    except Exception as e:
        full_trace = traceback.format_exc()
        print(f"{Fore.RED}   [!] İşlem hatası: {e}{Style.RESET_ALL}")
        print(f"{Fore.RED}{full_trace}{Style.RESET_ALL}")
        return {
            "success": False,
            "error": str(e)
        }

# -------------------------------------------------------------------------
# SOCIAL MEDIA HELPER FUNCTIONS (Subtitle Slicing & Censorship)
# -------------------------------------------------------------------------

BAD_WORDS = [
    "siktir", "amk", "aq", "amına", "yarak", "oç", "piç", "kahpe", "yavşak", 
    "sikik", "götveren", "götü", "memesi", "taşşak", "fuck", "shit", "bitch", 
    "bastard", "dick", "pussy", "anal", "oral", "porno", "sex", "seks", "31",
    "yarrak", "amcık", "tten", "gtten", "siktim", "sokayım"
]

def censor_text(text):
    """Metin içindeki küfürleri sansürler (*)."""
    text_lower = text.lower()
    
    # Basit kelime bazlı sansür
    for bad in BAD_WORDS:
        if bad in text_lower:
            # Kelimenin orijinal halini bulup eşleşen kısmı * yap
            # Regex ile Case-Insensitive replace
            pattern = re.compile(re.escape(bad), re.IGNORECASE)
            text = pattern.sub(lambda m: '*' * len(m.group()), text)
            
    return text

def extract_segment_subtitle(source_path, start_sec, end_sec, output_path, target_res_x=None, target_res_y=None):
    """
    Belirli bir zaman aralığındaki altyazıları kesip çıkarır.
    Zamanları 0:00:00'a göre öteler (Shift).
    Küfürleri sansürler.
    PlayRes değerlerini hedef çözünürlüğe göre günceller (Layout Fix).
    
    Args:
        source_path: Orijinal ASS dosyası
        start_sec: Kesitin videodaki başlangıç saniyesi
        end_sec: Kesitin videodaki bitiş saniyesi
        output_path: Çıktı ASS dosyasının yolu
        target_res_x: Hedef video genişliği (örn: 1080)
        target_res_y: Hedef video yüksekliği (örn: 1920)
    """
    if not os.path.exists(source_path): return False
    
    try:
        with open(source_path, 'r', encoding='utf_8_sig') as f:
            lines = f.readlines()
            
        header = []
        events = []
        styles = []
        
        # Parse logic
        format_idx = -1
        in_events = False
        in_styles = False
        style_format_indices = {} # map "Fontsize" -> index
        
        for line in lines:
            line_s = line.strip()
            
            if line_s == "[V4+ Styles]":
                in_styles = True
                in_events = False
                header.append(line)
                continue
                
            if line_s == "[Events]":
                in_events = True
                in_styles = False
                header.append(line)
                continue
            
            if in_styles:
                if line_s.startswith("Format:"):
                    # Format: Name, Fontname, Fontsize, PrimaryColour, ...
                    parts = line_s[7:].split(',')
                    parts = [p.strip() for p in parts]
                    for idx, p in enumerate(parts):
                        style_format_indices[p] = idx
                    header.append(line)
                    continue
                
                if line_s.startswith("Style:"):
                    # Style: Default,Arial,20,&H00FFFFFF,...
                    # Font normalization for social media clips
                    try:
                        prefix = "Style:"
                        content_part = line[len(prefix):]
                        style_parts = content_part.split(',')
                        
                        if "Fontsize" in style_format_indices:
                            fs_idx = style_format_indices["Fontsize"]
                            if fs_idx < len(style_parts):
                                old_size = float(style_parts[fs_idx])
                                # Normalize: ensure minimum readable size for TV viewing
                                # If too small (< 80), increase to 80
                                # Otherwise keep original size
                                if old_size < 80:
                                    new_size = 80
                                else:
                                    new_size = int(old_size)
                                
                                style_parts[fs_idx] = str(new_size)
                                
                                new_line = prefix + ",".join(style_parts)
                                header.append(new_line)
                                continue
                    except:
                        pass # Keep original if parsing fails
                    
                    header.append(line)
                    continue
                    
            if in_events:
                if line_s.startswith("Format:"):
                    header.append(line)
                    # "Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text"
                    # Default ASS Format
                    continue
                if line_s.startswith("Dialogue:"):
                    events.append(line)
            else:
                if not in_styles: # Header kısmı (Styles ve Events dışı)
                    # [FIX] Override PlayRes
                    if target_res_x and line_s.lower().startswith("playresx:"):
                        header.append(f"PlayResX: {target_res_x}\n")
                        continue
                    if target_res_y and line_s.lower().startswith("playresy:"):
                        header.append(f"PlayResY: {target_res_y}\n")
                        continue
                        
                    header.append(line)
        
        # [FIX] Ensure PlayRes exists if it wasn't there
        if target_res_x and not any(x.lower().startswith("playresx") for x in header):
            header.insert(1, f"PlayResX: {target_res_x}\n")
        if target_res_y and not any(x.lower().startswith("playresy") for x in header):
            header.insert(2, f"PlayResY: {target_res_y}\n")
        
        # Processing
        new_events = []
        
        def time_to_sec(t_str):
            # h:mm:ss.ms
            parts = t_str.split(':')
            h = int(parts[0])
            m = int(parts[1])
            s = float(parts[2])
            return h * 3600 + m * 60 + s
            
        def sec_to_time(sec):
            # h:mm:ss.ms (2 dijit ms for ASS)
            h = int(sec // 3600)
            rem = sec % 3600
            m = int(rem // 60)
            s = rem % 60
            # 0:00:05.15
            return f"{h}:{m:02d}:{s:05.2f}"
        
        segment_duration = end_sec - start_sec
        
        found_count = 0
        
        for evt in events:
            # Dialogue: 0,0:00:11.81,0:00:15.47,Default,,0,0,0,,Text
            parts = evt.split(',', 9)
            if len(parts) > 9:
                s_str = parts[1]
                e_str = parts[2]
                text = parts[9]
                
                try:
                    s_orig = time_to_sec(s_str)
                    e_orig = time_to_sec(e_str)
                    
                    # Kesişim Kontrolü
                    # Altyazı, bizim segment (start_sec -> end_sec) içinde mi?
                    # Veya bir kısmı giriyor mu? 
                    
                    # Basit Mantık: Altyazının ortası segment içindeyse al.
                    # Veya: Altyazı tamamen segment içindeyse.
                    
                    # Bizim durumumuz: Video kesilecek. Altyazıyı da videonun "yeni 0. saniyesine" göre ayarlamalıyız.
                    # Eğer altyazı 50. saniyede başlıyorsa ve biz 40-60 arasını kesiyorsak,
                    # Yeni altyazı 10. saniyede başlamalı (50 - 40).
                    
                    if e_orig < start_sec: continue # Segmentten önce bitmiş
                    if s_orig > end_sec: continue   # Segmentten sonra başlamış
                    
                    # Shift
                    new_s = max(0, s_orig - start_sec)
                    new_e = min(segment_duration, e_orig - start_sec)
                    
                    if new_e <= new_s: continue
                    
                    # Sansür
                    clean_text = censor_text(text)
                    
                    # Update Line
                    parts[1] = sec_to_time(new_s)
                    parts[2] = sec_to_time(new_e)
                    parts[9] = clean_text # New line
                    
                    new_line = ",".join(parts)
                    new_events.append(new_line)
                    found_count += 1
                    
                except: continue

        # Write Output
        with open(output_path, 'w', encoding='utf_8_sig') as f:
            f.writelines(header)
            f.writelines(new_events)
            
        return found_count > 0
        
    except Exception as e:
        print(f"Sub Slice Error: {e}")
        return False

